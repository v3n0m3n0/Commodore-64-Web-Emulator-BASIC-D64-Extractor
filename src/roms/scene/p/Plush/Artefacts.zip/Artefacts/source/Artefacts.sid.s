
.include "cpu.inc"
.include "sid.inc"
.include "zp.inc"

.include "music.s"


.SEGMENT "HEADER"

.charmap '#', $00

.byte "PSID"                            ; magicWord
.byte $00,$02                           ; version
.byte $00,$7c                           ; dataOffset
.byte >loadAddr,<loadAddr               ; loadAddr
.byte >initAddr,<initAddr               ; initAddr
.byte >playAddr,<playAddr               ; playAddr
.byte $00,$01                           ; songs
.byte $00,$01                           ; startSong
.byte $00,$00,$00,$00                   ; speed
.byte "Artefacts#######################"; name
.byte "Alexander Rotzsch (Fanta)#######"; author
.byte "2006 Plush######################"; copyright
.byte $00,$24                           ; flags
.byte $00                               ; startPage
.byte $00                               ; relocPage
.byte $00,$00                           ; reserved


.SEGMENT "DATA"

loadAddr:

initAddr:
SUB_INITMUSIC
rts

playAddr:
SUB_PLAYMUSIC
rts

DAT_MUSIC
