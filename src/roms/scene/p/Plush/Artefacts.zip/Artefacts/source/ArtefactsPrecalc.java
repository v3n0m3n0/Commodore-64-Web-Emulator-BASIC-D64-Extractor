import java.io.*;
import java.lang.Math;

public class ArtefactsPrecalc
{
    static void CalcSine()
    {
        try
        {
            FileOutputStream fw = new FileOutputStream("sincostable.bin");
            for ( int i = 0; i < 128; i++ )
            {
                // this sine curve is tweaked a little to keep the polynomial in bounds
                byte value = (byte) ((254.0 * Math.sin(Math.PI * 2.0 * (float) i / 256.0)) + 0.5);
                value = (byte) (value+1);
                fw.write(value);
            }
            
            fw.close();
        }       
       
    	catch (IOException e)
    	{
    		System.out.println("IO Exception.");
    	}       
    }
    
    static void CalcSphereMap()
    {
        try
        {
            FileOutputStream fw = new FileOutputStream("spheremappingtable.bin");

            final double d = 1024.0; // eye's distance to screen
            final double r = 32.0; // radius
            
            double xscreen;
            for (xscreen = -31.5; xscreen <= -0.5; xscreen += 1.0 )
            {
                double x = Math.abs( ((r+d) * xscreen ) /d );
                double y = Math.sqrt( r*r - x*x );
                double alpha = Math.atan(y/x) * 64.0 / Math.PI;
                byte value = (byte) alpha;

                fw.write(value);
            }
            for (; xscreen > -31.5; xscreen -= 1.0 )
            {
                double x = Math.abs( ((r+d) * xscreen ) /d );
                double y = Math.sqrt( r*r - x*x );
                double alpha = Math.atan(y/x) * 64.0 / Math.PI;
                byte value = (byte) (2.0*r-alpha);

                fw.write(value);
            }

            fw.close();            
        }
        
    	catch (IOException e)
    	{
    		System.out.println("IO Exception.");
    	}        
    }

    static void CalcPerspective()
    {
        try
        {
            FileOutputStream fx0 = new FileOutputStream("perspectivexaddtable.bin");
            FileOutputStream fx1 = new FileOutputStream("perspectivexoffstable.bin");
            FileOutputStream fy  = new FileOutputStream("perspectiveytable.bin");
            
            FileOutputStream fyx = new FileOutputStream("yrotxtable.bin");
            FileOutputStream fyy = new FileOutputStream("yrotytable.bin");

            final double perspective_offset = 4; // offset to reduce pixel salad around the horizon

            final double x2d = 37.0;
            final double z3d = 27.0 + perspective_offset;
            final double d = z3d - 1.0; // eye's distance to screen, chosen so that
                                  // perspytable[0] = 0 and perspytable[1] = 1 (least possible texture perspective downsizing)
            double prev_y3d = 0;
            double prev_xadd = 0;
                 
            byte [] perspectivey = new byte[27-1];
            for (double y2d = 27.0 + perspective_offset; y2d >= 1.0 + perspective_offset; y2d -= 1.0 )
            {
                double y3d = (z3d * d / y2d) - d;
                
                byte value = (byte) (y3d - prev_y3d);
                value &= 0x3f;
                prev_y3d = y3d;
                if (y2d != 27.0 + perspective_offset) // the first byte is 0 and is actually not needed
                {
                    perspectivey[26 - (int) (y2d-perspective_offset)] = value;
                }

                double x3d = x2d * (y3d + d) / d;
                x3d = x3d / 2.0;
                double xadd = x3d * 2.0/74.0;

                value = (byte) ((xadd-prev_xadd) * 256.0);
                fx0.write(value);

                value = (byte) (-x3d);
                fx1.write(value);
                
                prev_xadd = xadd;
            }
            
            for (int i = 24; i >= 0; i--)
            {
                fy.write(perspectivey[i]);
            }
            fx0.close();
            fx1.close();
            fy.close();
            
            
            final double radius = 0x1f;
            final double yoffset = 0x28;

            for (int i = 0; i < 128; i++)
            {
                double angle = Math.PI * 2.0 * i / 256.0;
                double x_3d = radius * -Math.sin(angle);
                double y_3d = radius * -Math.cos(angle) + yoffset;
                
                double x_2d = 2.0 * x_3d * d / (y_3d + d) + 37;
                double y_2d = z3d * d / (y_3d + d) - perspective_offset;

                fyx.write((byte) x_2d);
                fyy.write((byte) y_2d);
            }            
            fyx.close();
            fyy.close();
        }
        
    	catch (IOException e)
    	{
    		System.out.println("IO Exception.");
    	}
    }

    static void CalcArctan()
    {
        try
        {
            FileOutputStream fw = new FileOutputStream("arctantable.bin");
            final double f = 127.0 / (256.0*Math.atan(255.0/256.0));
            for (int i = 0; i < 256; i++)
            {
                byte value = (byte) ((f * 256.0 * Math.atan(i/256.0)) + 0.5);
                fw.write(value);
            }

            fw.close();
        }

    	catch (IOException e)
    	{
    		System.out.println("IO Exception.");
    	}       
    }

    static void CalcNoteFreqs()
    {
        final double factor = Math.pow(2.0, 1.0/12.0);
        double note_pal = 880 * factor / 64.0 * 16777216.0 / 985250.0;
        double note_ntsc = 880 * factor / 64.0 * 16777216.0 / 1022730.0;
        
        byte[] freqs_pal = new byte[12];
        byte[] freqs_ntsc = new byte[12];
        for (int i = 0; i < 12; i++)
        {
            freqs_pal[i] = (byte) (note_pal+0.5);
            note_pal /= factor;
            
            freqs_ntsc[i] = (byte) (note_ntsc+0.5);
            note_ntsc /= factor;            
        }
            
        try
        {
            FileOutputStream fp = new FileOutputStream("notefreqs_pal.bin");
            FileOutputStream fn = new FileOutputStream("notefreqs_ntsc.bin");
            
            for (int i = 11; i >= 0; i--)
            {
                fp.write(freqs_pal[i]);
                fn.write(freqs_ntsc[i]);
            }
            
            fp.close();
            fn.close();
        }

    	catch (IOException e)
    	{
    		System.out.println("IO Exception.");
    	}       
    }


    public static void main(String[] s)
    {
        CalcSine();
        CalcSphereMap();
        CalcPerspective();
        CalcArctan();
        CalcNoteFreqs();
    }
}