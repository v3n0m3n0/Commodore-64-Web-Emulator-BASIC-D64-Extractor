import java.io.*;

public class C64BinaryCompressionOptimizer
{
    int readHexNumber(StreamTokenizer tokens)
    {
        try
        {
            return Integer.parseInt(tokens.sval,16);
        }
        catch (NumberFormatException e)
        {
            System.out.println("Unknown format of or broken map file.");
            System.exit(-1);
        }
        
        return -1;
    }
    
    int readNextHexNumber(StreamTokenizer tokens)
    {
        int token;
        try
        {
            while ((token = tokens.nextToken()) != StreamTokenizer.TT_EOF)
            {
                if (token == StreamTokenizer.TT_WORD)
                {
                    return readHexNumber(tokens);
                }
            }
        }
        catch (IOException e)
        {
            System.out.println( "IO error while parsing the map file." );
            System.exit(-1);
        }        
        
        return -1;
    }

    String hexString(int theNumber)
    {
        String theString = Integer.toHexString(theNumber);
        int numZeros = 4-theString.length();
        String returnString = "0x";
        for (int i = 0; i < numZeros; i++)
            returnString += '0';
        return returnString + theString;  
    }

    String hexString8Bits(int theNumber)
    {
        String theString = Integer.toHexString(theNumber);
        int numZeros = 2-theString.length();
        String returnString = "0x";
        for (int i = 0; i < numZeros; i++)
            returnString += '0';
        return returnString + theString;  
    }

    void getSegmentAddresses(String mapFileName)
    {
        // parse map file for CODE and DATA segments addresses
        FileInputStream mapStream = null;
        try
        {
            mapStream = new FileInputStream(mapFileName);
        }
        catch (IOException e)
        {
            System.out.println( mapFileName + " couldn't be opened." );
            System.exit(-1);
        }
        
        BufferedReader mapReader = new BufferedReader(new InputStreamReader(mapStream));
        StreamTokenizer mapTokens = new StreamTokenizer(mapReader);
        
        mapTokens.resetSyntax();
        mapTokens.wordChars('0','9');
        mapTokens.wordChars('a','z');
        mapTokens.wordChars('A','Z');

        int token;
        try
        {
            while ((token = mapTokens.nextToken()) != StreamTokenizer.TT_EOF)
            {
                if (token == StreamTokenizer.TT_WORD)
                {
                    if (mapTokens.sval.equals("CODE"))
                    {
                        while ((token = mapTokens.nextToken()) != StreamTokenizer.TT_EOF)
                        {
                            if (token == StreamTokenizer.TT_WORD)
                            {
                                if (!mapTokens.sval.equals("Offs"))
                                {
                                    _codeStart = readHexNumber(mapTokens);
                                    _codeEnd = readNextHexNumber(mapTokens);
                                }
                                break;
                            }
                        }
                    }

                    if (mapTokens.sval.equals("DATA"))
                    {
                        while ((token = mapTokens.nextToken()) != StreamTokenizer.TT_EOF)
                        {
                            if (token == StreamTokenizer.TT_WORD)
                            {
                                if (!mapTokens.sval.equals("Offs"))
                                {
                                    _dataStart = readHexNumber(mapTokens);
                                    _dataEnd = readNextHexNumber(mapTokens);
                                }
                                break;
                            }
                        }
                    }

                }
            }
 
            _codeStart += 2; // loading address
            System.out.println("CODE segment at " + hexString(_codeStart) + "-" + hexString(_codeEnd) + "," );
            System.out.println("DATA segment at " + hexString(_dataStart) + "-" + hexString(_dataEnd) + "." );
        }
        catch (IOException e)
        {
            System.out.println( "IO error while parsing " + mapFileName + "." );
            System.exit(-1);
        }
    }
    
    void separateCode(String inFileName)
    {
        FileInputStream inFile = null;
        try
        {
            inFile = new FileInputStream(inFileName);
        }
        catch (IOException e)
        {
            System.out.println( inFileName + " couldn't be opened." );
            System.exit(-1);
        }
        
        try
        {
            int loadAddr = inFile.read() | (inFile.read() << 8);
            if (loadAddr != _codeStart)
            {
                System.out.println( "Code segment not at start of file." );
                System.exit(-1);
            }

            _opCodes = new byte[65536];
            _args = new byte[65536];
            _data = new byte[65536];

            _numOpCodes = 0;
            _numArgs = 0;
            _numData = 0;

            _statOpCodes = new int[256];
            _statArgs = new int[256];
            for (int i = 0; i < 256; i++)
            {
                _statOpCodes[i] = 0;
                _statArgs[i] = 0;
            }

            int value;
            int codeCount = _codeEnd - _codeStart;
            boolean started = true;
            while ((value = inFile.read()) != -1)
            {
                if (codeCount > 0)
                {                    
                    if (started == true)
                    {
                        _args[_numArgs] = (byte) value;
                        _numArgs++;
                        started = false;
                    }
                    else
                    {
                        _opCodes[_numOpCodes] = (byte) value;
                        _numOpCodes++;
                    }
                    codeCount--;

                    _statOpCodes[value]++;
                    
                    if (_opCodeLengths[value] > 0)
                    {
                        int opCode = value;
                        
                        value = inFile.read();
                        if (value == -1)
                        {
                            break;
                        }
                        _args[_numArgs] = (byte) value;
                        _numArgs++;
                        codeCount--;

                        _statArgs[value]++;
                                                
                        if (_opCodeLengths[opCode] > 1)
                        {
                            value = inFile.read();
                            if (value == -1)
                            {
                                break;
                            }

                            _args[_numArgs] = (byte) value;
                            _numArgs++;
                            codeCount--;

                            _statArgs[value]++;
                        }
                    }
                }
                else
                {
                    _data[_numData] = (byte) value;
                    _numData++;
                }
            }
            inFile.close();            

            for (int i = 0; i < 256; i++)
            {
                if (_statOpCodes[i] == 0)
                {
                    _firstUnusedOpCode = (byte) i;
                    break;
                }
            }            
        }
        catch (IOException e)
        {
            System.out.println( "IO error while reading " + inFileName + "." );
            System.exit(-1);
        }
    }

    void writeOutputFiles(String opCodesArgsOutFileName, String dataOutFileName)
    {
        FileOutputStream opCodesArgsOutFile = null;
        try
        {
            opCodesArgsOutFile = new FileOutputStream(opCodesArgsOutFileName);
        }
        catch (IOException e)
        {
            System.out.println(opCodesArgsOutFileName + " couldn't be opened.");
            System.exit(-1);
        }
        
        try
        {
            for (int i = 0; i < _numOpCodes; i++)
            {
                opCodesArgsOutFile.write(_opCodes[i]);
            }
            
            opCodesArgsOutFile.write(_firstUnusedOpCode);
            
            for (int i = 0; i < _numArgs; i++)
            {
                opCodesArgsOutFile.write( _args[i]);
            }
            
            opCodesArgsOutFile.close();
        }
        catch (IOException e)
        {
            System.out.println("IO error while writing " + opCodesArgsOutFileName + ".");
            System.exit(-1);
        }

        FileOutputStream dataOutFile = null;
        try
        {
            dataOutFile = new FileOutputStream(dataOutFileName);
        }
        catch (IOException e)
        {
            System.out.println(dataOutFileName + " couldn't be opened.");
            System.exit(-1);
        }
        
        try
        {
            for (int i = 0; i < _numData; i++)
            {
                dataOutFile.write(_data[i]);
            }

            dataOutFile.close();
        }
        catch (IOException e)
        {
            System.out.println( "IO error while writing " + dataOutFileName + "." );
            System.exit(-1);
        }        
    }

    void writeC64AssemblyDefinitions(String opCodesArgsOutFileName, String dataOutFileName, String defsFileName)
    {
        FileOutputStream defsFile = null;
        try
        {
            defsFile = new FileOutputStream(defsFileName);
        }
        catch (IOException e)
        {
            System.out.println( defsFileName + " couldn't be created." );
            System.exit(-1);
        }
                
        Writer defsWriter = new BufferedWriter(new OutputStreamWriter(defsFile));
        try
        {
            defsWriter.write("; This file was generated automatically, please do not edit.\n\n");
            defsWriter.write(".define OPT_OPCODESARGSFILE \"" + opCodesArgsOutFileName + "\"\n");
            defsWriter.write(".define OPT_DATAFILE \"" + dataOutFileName + "\"\n\n");
            defsWriter.write(".define OPT_DEST " + _codeStart + "\n");
            defsWriter.write(".define OPT_ARGS " + (_numOpCodes+1) + "\n");
            defsWriter.write(".define OPT_LOAD_ADDRESS " + _dataStart + "\n");
            defsWriter.write(".define OPT_EXEC_ADDRESS " + (_dataEnd+1) + "\n\n");
            defsWriter.write(".define OPT_TERMINATOR " + _firstUnusedOpCode + "\n\n");
            
            defsWriter.write(".define OPCODELENGTHS opcodelengths: .byte ");
            for (int i = 0; i < 64; i++)
            {
                defsWriter.write("%");
                for (int j = 3; j >= 0; j--)
                {
                    int index = i*4+j;
                    int val = _opCodeLengths[index];
                    defsWriter.write((val & 1) != 0 ? "1" : "0" );
                    defsWriter.write((val & 2) != 0 ? "1" : "0" );
                }
                if (i < 63)
                {
                    defsWriter.write(",");
                }
                if ((i & 0x07) == 7)
                {
                    defsWriter.write(" ");                    
                }
            }

            defsWriter.close();
        }
        catch (IOException e)
        {
            System.out.println( "Error while writing to " + defsFileName + "." );
            System.exit(-1);
        }
    }

    void writeStatsFile(String statsFileName)
    {
        FileOutputStream statsFile = null;
        try
        {
            statsFile = new FileOutputStream(statsFileName);
        }
        catch (IOException e)
        {
            System.out.println( statsFileName + " couldn't be created." );
            System.exit(-1);
        }
                
        Writer statsWriter = new BufferedWriter(new OutputStreamWriter(statsFile));
        try
        {
            statsWriter.write("Op-code table length: " + _numOpCodes + ",\n");
            statsWriter.write("Args table length: " + _numArgs + ",\n");
            statsWriter.write("Data length: " + _numData + ".\n");
                                    
            int opCodesUsed = 0;
            int argsUsed = 0;
            for (int i = 0; i < 256; i++)
            {
                if (_statOpCodes[i] > 0)
                {
                    opCodesUsed++;
                }
                if (_statArgs[i] > 0)
                {
                    argsUsed++;
                }
            }
            statsWriter.write("Number of op-codes used: " + opCodesUsed + ",\n");
            statsWriter.write("Number of args used: " + argsUsed + ".\n\n");

            float percent = 0;
            for (int i = 0; i < 256; i++)
            {
                if (_statOpCodes[i] > 0)
                {
                    statsWriter.write("Op-code " + hexString8Bits(i) + ": " + _statOpCodes[i] + " occurance" + (_statOpCodes[i] == 1 ? "" : "s") +
                    "\t(" + (((double) _statOpCodes[i]) * 100.0 / _numOpCodes) + "%)\n" );
                }
            }            
    
            for (int i = 0; i < 256; i++)
            {
                if (_statArgs[i] > 0)
                {
                    statsWriter.write("Argument " + hexString8Bits(i) + ": " + _statArgs[i] + " occurance" + (_statArgs[i] == 1 ? "" : "s") +
                    "\t(" + (((double) _statArgs[i]) * 100.0 / _numArgs) + "%)\n" );
                }
            }            
    
            statsWriter.close();
        }
        catch (IOException e)
        {
            System.out.println( "Error while writing to " + statsFileName + "." );
            System.exit(-1);
        }
    }

    C64BinaryCompressionOptimizer(String inFileName, String mapFileName, String opCodesArgsOutFileName, String dataOutFileName, String statsFileName)
    {
        getSegmentAddresses(mapFileName);
        separateCode(inFileName);
        writeOutputFiles(opCodesArgsOutFileName, dataOutFileName);
        writeC64AssemblyDefinitions(opCodesArgsOutFileName, dataOutFileName, "pack_opt_defs.inc");
        if (statsFileName != null)
        {
            writeStatsFile(statsFileName);
        }
    }

    public static void main(String[] params)
    {
        if (params.length < 4)
        {
            System.out.println("Usage:\njava C64BinaryCompressionOptimizer infile mapfile opcodesargsoutfile dataoutfile [statsfile].");
        }
        else
        {
            if (params.length > 4)
                new C64BinaryCompressionOptimizer(params[0], params[1], params[2], params[3], params[4]);
            else
                new C64BinaryCompressionOptimizer(params[0], params[1], params[2], params[3], null);
        }
    }
    
    private int _codeStart = -1;
    private int _codeEnd = -1;
    private int _dataStart = -1;
    private int _dataEnd = -1;
    
    private byte[] _opCodes = null;
    private int _numOpCodes = 0;
    private byte[] _args = null;
    private int _numArgs = 0;
    private byte[] _data = null;
    private int _numData = 0;    
    
    private int[] _statOpCodes = null;
    private int[] _statArgs = null;
    
    private byte _firstUnusedOpCode = 0;
    
    private static final int[] _opCodeLengths = 
    {
        0, // 00, brk
        1, // 01, ora (zp,x)
        0, // 02, jam
        1, // 03, slo (zp,x)
        0, // 04, nop
        1, // 05, ora zp
        1, // 06, asl zp
        1, // 07, slo zp
        0, // 08, php
        1, // 09, ora #imm
        0, // 0a, asl
        1, // 0b, anc #imm
        2, // 0c, nop abs
        2, // 0d, ora abs
        2, // 0e, asl abs
        2, // 0f, slo abs
        
        1, // 10, bpl rel
        1, // 11, ora (zp),y
        0, // 12, jam
        1, // 13, slo (zp),y
        1, // 14, nop zp,x
        1, // 15, ora zp,x
        1, // 16, asl zp,x
        1, // 17, slo zp,x
        0, // 18, clc
        2, // 19, ora abs,y
        0, // 1a, nop
        2, // 1b, slo abs,y
        2, // 1c, nop abs,x
        2, // 1d, ora abs,x
        2, // 1e, asl abs,x
        2, // 1f, slo abs,x
        
        2, // 20, jsr abs
        1, // 21, and (zp,x)
        0, // 22, jam
        1, // 23, rla (zp,x)
        1, // 24, bit zp
        1, // 25, and zp
        1, // 26, rol zp
        1, // 27, rla zp
        0, // 28, plp
        1, // 29, and #imm
        0, // 2a, rol
        1, // 2b, anc #imm
        2, // 2c, bit abs
        2, // 2d, and abs
        2, // 2e, rol abs
        2, // 2f, rla abs

        1, // 30, bmi rel
        1, // 31, and (zp),y
        0, // 32, jam
        1, // 33, rla (zp),y
        1, // 34, nop zp,x
        1, // 35, and zp,x
        1, // 36, rol zp,x
        1, // 37, rla zp,x
        0, // 38, sec
        2, // 39, and abs,y
        0, // 3a, nop
        1, // 3b, rla abs,y
        2, // 3c, nop abs,x
        2, // 3d, and abs,x
        2, // 3e, rol abs,x
        2, // 3f, rla abs,x

        0, // 40, rti
        1, // 41, eor (zp,x)
        0, // 42, jam
        1, // 43, sre (zp,x)
        1, // 44, nop zp
        1, // 45, eor zp
        1, // 46, lsr zp
        1, // 47, sre zp
        0, // 48, pha
        1, // 49, eor #imm
        0, // 4a, lsr
        1, // 4b, asl #imm
        2, // 4c, jmp abs
        2, // 4d, eor abs
        2, // 4e, lsr abs
        2, // 4f, sre abs

        1, // 50, bvs rel
        1, // 51, eor (zp),y
        0, // 52, jam
        1, // 53, sre (zp),y
        1, // 54, nop zp,x
        1, // 55, eor zp,x
        1, // 56, lsr zp,x
        1, // 57, sre zp,x
        0, // 58, cli
        2, // 59, eor abs,y
        0, // 5a, nop
        2, // 5b, sre abs,y
        2, // 5c, nop abs,x
        2, // 5d, eor abs,x
        2, // 5e, lsr abs,x
        2, // 5f, sre abs,x

        0, // 60, rts
        1, // 61, adc (zp,x)
        0, // 62, jam
        1, // 63, rra (zp,x)
        1, // 64, nop zp
        1, // 65, adc zp
        1, // 66, ror zp
        1, // 67, rra zp
        0, // 68, pla
        1, // 69, adc #imm
        0, // 6a, ror
        1, // 6b, arr #imm
        2, // 6c, jmp (abs)
        2, // 6d, adc abs
        2, // 6e, ror abs
        2, // 6f, rra abs

        1, // 70, bvs rel
        1, // 71, adc (zp),y
        0, // 72, jam
        1, // 73, rra (zp),y
        1, // 74, nop zp,x
        1, // 75, adc zp,x
        1, // 76, ror zp,x
        1, // 77, rra zp,x
        0, // 78, sei
        2, // 79, adc abs,y
        0, // 7a, nop
        2, // 7b, rra abs,y
        2, // 7c, nop abs,x
        2, // 7d, adc abs,x
        2, // 7e, ror abs,x
        2, // 7f, rra abs,x

        1, // 80, nop #imm
        1, // 81, sta (zp,x)
        1, // 82, nop #imm
        1, // 83, sax (zp,x)
        1, // 84, sty zp
        1, // 85, sta zp
        1, // 86, stx zp
        1, // 87, sax zp
        0, // 88, dey
        1, // 89, nop #imm
        0, // 8a, txa
        1, // 8b, xaa #imm
        2, // 8c, sty abs
        2, // 8d, sta abs
        2, // 8e, stx abs
        2, // 8f, sax abs

        1, // 90, bcc rel
        1, // 91, sta (zp),y
        0, // 92, jam
        1, // 93, ahx (zp),y
        1, // 94, sty zp,x
        1, // 95, sta zp,x
        1, // 96, stx zp,y
        1, // 97, sax zp,y
        0, // 98, tya
        2, // 99, sta abs,y
        0, // 9a, txs
        2, // 9b, tas abs,y
        2, // 9c, shf abs,x
        2, // 9d, sta abs,x
        2, // 9e, shx abs,y
        2, // 9f, ahx abs,y

        1, // a0, ldy #imm
        1, // a1, lda (zp,x)
        1, // a2, ldx #imm
        1, // a3, lax (zp,x)
        1, // a4, ldy zp
        1, // a5, lda zp
        1, // a6, ldx zp
        1, // a7, lax zp
        0, // a8, tay
        1, // a9, lda #imm
        0, // aa, tax
        1, // ab, lax #imm
        2, // ac, ldy abs
        2, // ad, lda abs
        2, // ae, ldx abs
        2, // af, lax abs

        1, // b0, bcs rel
        1, // b1, lda (zp),y
        0, // b2, jam
        1, // b3, lax (zp),y
        1, // b4, ldy zp,x
        1, // b5, lda zp,x
        1, // b6, ldx zp,y
        1, // b7, lax zp,y
        0, // b8, clv
        2, // b9, lda abs,y
        0, // ba, tsx
        2, // bb, las abs,y
        2, // bc, ldy abs,x
        2, // bd, lda abs,x
        2, // be, ldx abs,y
        2, // bf, lax abs,y

        1, // c0, cpy #imm
        1, // c1, cmp (zp,x)
        1, // c2, nop #imm
        1, // c3, dcp (zp,x)
        1, // c4, cpy zp
        1, // c5, cmp zp
        1, // c6, dec zp
        1, // c7, dcp zp
        0, // c8, iny
        1, // c9, cmp #imm
        0, // ca, dex
        1, // cb, sbx #imm
        2, // cc, cpy abs
        2, // cd, cmp abs
        2, // ce, dec abs
        2, // cf, dcp abs

        1, // d0, bne rel
        1, // d1, cmp (zp),y
        0, // d2, jam
        1, // d3, dcp (zp),y
        1, // d4, nop zp,x
        1, // d5, cmp zp,x
        1, // d6, dec zp,x
        1, // d7, dcp zp,x
        0, // d8, cld
        2, // d9, cmp abs,y
        0, // da, nop
        2, // db, dcp abs,y
        2, // dc, nop abs,x
        2, // dd, cmp abs,x
        2, // de, dec abs,x
        2, // df, dcp abs,x

        1, // e0, cpx #imm
        1, // e1, sbc (zp,x)
        1, // e2, nop #imm
        1, // e3, isc (zp,x)
        1, // e4, cpx zp
        1, // e5, sbc zp
        1, // e6, inc zp
        1, // e7, isc zp
        0, // e8, inx
        1, // e9, sbc #imm
        0, // ea, nop
        1, // eb, sbc #imm
        2, // ec, cpx abs
        2, // ed, sbc abs
        2, // ee, inc abs
        2, // ef, isc abs

        1, // f0, beq rel
        1, // f1, sbc (zp),y
        0, // f2, jam
        1, // f3, isc (zp),y
        1, // f4, nop zp,x
        1, // f5, sbc zp,x
        1, // f6, inc zp,x
        1, // f7, isc zp,x
        0, // f8, sed
        2, // f9, sbc abs,y
        0, // fa, nop
        2, // fb, isc abs,y
        2, // fc, nop abs,x
        2, // fd, sbc abs,x
        2, // fe, inc abs,x
        2, // ff, isc abs,x
    };    
}
