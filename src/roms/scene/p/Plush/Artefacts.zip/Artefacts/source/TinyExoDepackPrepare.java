import java.io.*;

public class TinyExoDepackPrepare
{
    TinyExoDepackPrepare(String packedFileName, String outFileName)
    {
        FileInputStream packedFile = null;
        try
        {
            packedFile = new FileInputStream(packedFileName);
        }
        catch (IOException e)
        {
            System.out.println( packedFileName + " couldn't be opened." );
            System.exit(-1);
        }
        
        byte[] packedFileData = new byte[65536];
        int i = 0;
        try
        {
            int value;
            while ((value = packedFile.read()) != -1)
            {
                packedFileData[i] = (byte) value;
                i++;
            }
            packedFile.close();
        }
        catch (IOException e)
        {
            System.out.println( "Error while reading " + packedFileName + "." );
            System.exit(-1);
        }

        byte[] packedFileDataReversed = new byte[i];
        for (int j = 0; j < i; j++)
        {
            packedFileDataReversed[j] = packedFileData[i-j-1];
        }
        
        FileOutputStream outFile = null;
        try
        {
            outFile = new FileOutputStream(outFileName);
        }
        catch (IOException e)
        {
            System.out.println( "Error while creating " + outFileName + "." );
            System.exit(-1);
        }
        
        try
        {
            for (int j = 0; j < i-3; j++)
            {
                outFile.write(packedFileDataReversed[j]);
            }
            outFile.close();
        }
        catch (IOException e)
        {
            System.out.println( "Error while writing to " + outFileName + "." );
            System.exit(-1);
        }
        
        String defsFileName = "exo-4k-defs.inc";
        FileOutputStream defsFile = null;
        try
        {
            defsFile = new FileOutputStream(defsFileName);
        }
        catch (IOException e)
        {
            System.out.println( defsFileName + " couldn't be created." );
            System.exit(-1);
        }
                
        Writer defsWriter = new BufferedWriter(new OutputStreamWriter(defsFile));
        try
        {
            defsWriter.write("; This file was generated automatically, please do not edit.\n\n");
            defsWriter.write(".include \"pack_opt_defs.inc\"\n\n");
            
            defsWriter.write(".define bitbuf_val " + (((int) packedFileDataReversed[i-3]) & 0xff) + "\n");
            defsWriter.write(".define dest_addr " + (((((int) packedFileDataReversed[i-1]) << 8) | (((int) packedFileDataReversed[i-2]) & 0xff)) & 0xffff) + "\n");
            defsWriter.write(".define exec_addr OPT_EXEC_ADDRESS\n\n");
            defsWriter.write(".define data_file \"" + outFileName + "\"");
            
            defsWriter.close();
        }
        catch (IOException e)
        {
            System.out.println( "Error while writing to " + defsFileName + "." );
            System.exit(-1);
        }
    }

    public static void main(String[] params)
    {
        if (params.length < 2)
        {
            System.out.println("Usage:\njava TinyExoDepackPrepare infile outfile.");
        }
        else
        {
            new TinyExoDepackPrepare(params[0], params[1]);
        }
    }
}
