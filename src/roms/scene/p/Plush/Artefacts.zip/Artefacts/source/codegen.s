
.macro SUB_CODEGENERATOR

                ; put a piece of unrolled code
                ; in: x: index of last byte of the code fragment+1
                ;     y: number of bytes to copy

                ; falls through to addtopointer to leave the
                ; destination pointer with the next chunk's address

putcodepiece:   tya
                pha
putcodesource = *+$02
:               lda codefragments,x
                cmp #CODEMODIFIER0
                bcc :+
                sta *+$04
                lda POINTER+$00
:               sta (POINTER+$00),y
                dex
                dey
                bpl :--
                pla
                SKIPWORD

                ; fall through

                ; add 40 to the first 16-bit pointer
                ; out: a - lo-byte of the result
add40topointer: lda #$28
                ; add an 8-bit value to the first 16-bit pointer
                ; in:  a - value to add
                ; out: a - lo-byte of the result
addtopointer:   ldy #POINTER+$00
                SKIPWORD
zpadd74:        lda #$4a

                ; add an 8-bit value to the 16-bit pointer with pointer index y
                ; in:  a - value to add
                ;      y - offset to the pointer
                ; out: a - lo-byte of the result
                ;      y - y+$02
zpadd8to16bits: clc
                adc $00,y
zpput16bits:    sta $00,y
                iny
                pha
                lda #$00
                adc $00,y
                sta $00,y
                iny
                pla
                rts

.endmacro; SUB_CODEGENERATOR