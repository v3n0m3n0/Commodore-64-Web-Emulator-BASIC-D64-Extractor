;
; Tiny Exomizer-Decruncher especially for 4K-Intros and such V1.2
;
; by Wolfram Sang (Ninja/The Dreams) in 2004 based on the original
; decruncher which is copyright (c) 2002, 2003 by Magnus Lind.
;
; Modified by Gunnar Ruthenberg (Krill/Plush) in 2005.
;
; This depacker can only operate on files crunched with the compatibility
; mode (option -c), there is no extra literal handling.
;
; -------------------------------------------------------------------
;
; This software is provided 'as-is', without any express or implied warranty.
; In no event will the authors be held liable for any damages arising from
; the use of this software.
;
; Permission is granted to anyone to use this software for any purpose,
; including commercial applications, and to alter it and redistribute it
; freely, subject to the following restrictions:
;
;   1. The origin of this software must not be misrepresented; you must not
;   claim that you wrote the original software. If you use this software in a
;   product, an acknowledgment in the product documentation would be
;   appreciated but is not required.
;
;   2. Altered source versions must be plainly marked as such, and must not
;   be misrepresented as being the original software.
;
;   3. This notice may not be removed or altered from any distribution.
;
;   4. The names of this software and/or it's copyright holders may not be
;   used to endorse or promote products derived from this software without
;   specific prior written permission.
;
;
; -------------------------------------------------------------------
;
; This source can be assembled with the ca65 toolchain.
; The original version was compileable with AS1.41 available from the releases-page
; of http://www.the-dreams.de. Porting to other assemblers should be easy.
; The above page is also the place for the latest version of this source.
; For a description of the decruncher in general, see the original
; EXODECRUNCH.S from Magnus Lind.
;
; Here is how to use this one:
;  1) Check that the unpacked file's load address does not point into this decruncher.
;  2) Crunch your file using the "level" and "-c" options of exomizer.
;  3) Reverse the byte order of the packed file.
;  4) Remove the last three bytes from that file but keep them in mind.
;     The third-to-last byte is the "bitbuf_val". The last two are the "dest_addr".
;  5) In the file "exo-4k-defs.inc", define bitbuf_val and dest_addr according to
;     the bytes you removed before, also define exec_addr, and data_file with
;     the name of the reversed packed file.
;  6) Assemble and link.
;
; The resulting file is up to 157 bytes smaller than with using the standard decruncher.
; Note that it must be started with RUN because of ZP-settings. After
; decrunching IRQs are disabled. $01 is not touched (except for full_ram
; option).
; For further suggestions or comments, contact me: ninja@the-dreams.de,
; or Krill@Plush.de.
;
; Version history:
;  1.1 - first public release
;  1.2 - 3 bytes shorter
;  x.x - Krill's mods - 3 bytes longer + short_copy option (n bytes shorter)

; -------------------------------------------------------------------
; compile options

spoil_end     = 1           ; if $33 bytes after your decrunched file
                            ; should not be spoiled, +2 bytes
full_ram      = 0           ; disables ROMs and I/O, +3 bytes
illegals_ok   = 1           ; no illegal opcodes, +1 byte
short_copy    = 1           ; when there are no sequence lengths >= 256, +16 bytes

; -------------------------------------------------------------------
; initialization for the assembler
             .if illegals_ok
              .setcpu "6502X"
             .else
              .setcpu "6502"
             .endif
              .feature pc_assignment
              .include "exo-4k-defs.inc"

; -------------------------------------------------------------------
; zero page addresses used. square brackets show the status after
; decrunching.
; -------------------------------------------------------------------

; these can be changed easily

zp_bits_lo    = $61
zp_bits_hi    = $66            ; [undefined, but likely 0]

zp_bit_cnt    = $62            ; [$ff]

; change these only if you really know what you're doing!

zp_len_lo     = $4a            ; $4A = LSR A [undefined]

zp_src_lo     = $78            ; $78 = SEI
zp_src_hi     = zp_src_lo + 1  ; [undefined]

zp_dest_lo    = $39            ; = BASIC Line Number, will be set by RUN
zp_dest_hi    = zp_dest_lo + 1 ; [start address of uncrunched file]

byte_lo       = $2d            ; = end of BASIC-prog
byte_hi       = byte_lo + 1    ; [start address of crunched file]

tabl_bi_pnt   = $b2         ; ptr to tape buffer    (= $033d - $0371)
tabl_lo_pnt   = $75         ; CHRGET-code           (= $02d1 - $0305)
tabl_hi_pnt   = $91         ; STOP-flag + tape temp (= $0100 - $0134)
                            ;  not 100%
; $d1 (ptr to cur_line) might be another idea, but prints on screen...

; -------------------------------------------------------------------
; code starts here

.segment "STARTUP"

              .org $07ff
              
              .word *+$02; loading address

              .word $080d, dest_addr
              .byte $9e,"206"
tabl_off:
              .byte 48+1,32+1,16+1          ; also part of SYS-line!
              .byte 0

              ldy #0
             .if full_ram
              sei
              inc $01
             .endif

; -------------------------------------------------------------------
; calculate tables (i think it might be possible to gain some bytes here,
; but i don't want to delay the release. suggestions are welcome...)

nextone:      ldx #$01      ; inx? well, AR-reset doesn't clear $030d
              tya
              and #$0f
              beq shortcut
              txa
              lsr a; a = 0, c = 1
rolle:
              rol a
              rol zp_bits_hi
              dec zp_bits_lo
              bpl rolle                   ; c = 0

              adc (tabl_lo_pnt),y
              tax
              lda zp_bits_hi
              adc (tabl_hi_pnt),y
shortcut:
              iny
              sta (tabl_hi_pnt),y
              txa
              sta (tabl_lo_pnt),y

             .if illegals_ok
              ldx #4
             .else
              lda #4
             .endif
              jsr get_bits
              sta (tabl_bi_pnt),y
              cpy #$34
              bcc nextone
              
             .if spoil_end
              bcs copy_next
             .else
              ldy #0
              beq next1
             .endif

; -------------------------------------------------------------------
; get bits

get_bits:
             .if illegals_ok
              stx zp_bit_cnt
             .else
              sta zp_bit_cnt
             .endif

              ldx #0
              stx zp_bits_lo
              stx zp_bits_hi
bitbuf  = * + 1
              lda #<bitbuf_val
              asl a
bits_next:
              ror a
              bne ok
get_byte:
              lda byte_lo
              bne byte_skip_hi
              dec byte_hi
byte_skip_hi:
              dec byte_lo
              lda (byte_lo,x)
              bcc literal_entry
              ror a
ok:
              rol zp_bits_lo
              rol zp_bits_hi
              dec zp_bit_cnt
              bpl bits_next

              sta bitbuf
              ldx zp_bits_hi
              lda zp_bits_lo
              rts

tabl_bit:
              .byte 2,4,4

; -------------------------------------------------------------------
; main copy loop

.if short_copy = 0
copy_next_hi:
              dex
              dec zp_dest_hi
              dec zp_src_hi
.endif
copy_next:
              dey
              lda (zp_src_lo),y
             .if (full_ram) || (zp_src_lo<>$78)
literal_entry = *
             .else
literal_entry = * - 1                     ; disables IRQs
             .endif
              sta (zp_dest_lo),y
copy_start:
              tya
              bne copy_next
.if short_copy = 0
              txa
              bne copy_next_hi
.endif  
              ; fall through
              
; -------------------------------------------------------------------
; decruncher entry point, needs calculated tables
; y must be #0 when entering

next1:
             .if illegals_ok
.if short_copy             
              ldx #$01
.else
              inx
.endif
             .else
              lda #1
             .endif
              iny
              jsr get_bits
              beq next1
              dey
              beq literal_start

; -------------------------------------------------------------------
; calculate length of sequence (zp_len)

             .if illegals_ok
              lax (tabl_bi_pnt),y
             .else
              lda (tabl_bi_pnt),y
             .endif
              jsr get_bits

              cpy #$11
exec_offset = $ffff; exec_addr - (*+2) - unfortunately, this won't work with ca65
             .if exec_offset>127
              bcs start_decrunched
             .else
              bcs exec_addr
             .endif

              adc (tabl_lo_pnt),y
              sta zp_len_lo
.if short_copy = 0
              txa
              adc (tabl_hi_pnt),y
              pha
; -------------------------------------------------------------------
; here we decide what offset table to use

              bne nots123
              ldy zp_len_lo
.else
              tay
.endif
              cpy #$04
              bcc size123
nots123:
              ldy #$03
size123:
             .if illegals_ok
              ldx tabl_bit - 1,y
             .else
              lda tabl_bit - 1,y
             .endif
              jsr get_bits
              adc tabl_off - 1,y
              tay
; -------------------------------------------------------------------
; prepare zp_dest

              lda zp_len_lo
literal_start = * - 1; lsr a
              sbc zp_dest_lo
              eor #$ff
              sta zp_dest_lo
              bcc noborrow
              dec zp_dest_hi
noborrow:
              cpy #1
              bcc get_byte
; -------------------------------------------------------------------
; calculate absolute offset (zp_src)

             .if illegals_ok
              lax (tabl_bi_pnt),y
             .else
              lda (tabl_bi_pnt),y
             .endif
              jsr get_bits
              adc (tabl_lo_pnt),y
              bcc skipcarry
              inx
              clc
skipcarry:
              adc zp_dest_lo
              sta zp_src_lo
              txa
              adc (tabl_hi_pnt),y
              adc zp_dest_hi
              sta zp_src_hi
; -------------------------------------------------------------------
; prepare for copy loop

              ldy zp_len_lo
.if short_copy = 0
              pla
              tax
.endif
              bcc copy_start

; -------------------------------------------------------------------

             .if exec_offset>127
start_decrunched:
              jmp exec_addr
             .endif
; -------------------------------------------------------------------
; end of decruncher
; -------------------------------------------------------------------

              .incbin data_file
