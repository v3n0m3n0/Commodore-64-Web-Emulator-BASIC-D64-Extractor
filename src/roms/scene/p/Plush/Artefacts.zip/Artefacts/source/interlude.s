
.define TEXTLINE 21
.define STARTCOLUMN 3

.macro SUB_INTERLUDE

startinterlude: inc INTERLUDECOUNT
.ifndef NTSC_VERSION
                sec
                sbc #$08
.endif
                sta INTERLUDETIMER
                jsr waitvblank
               ;ldx #$00; COLOUR_BLACK
                stx VIC2_CTRL1
                lda COLOURSCHEME
                clc
                adc #colourset1-coloursets
                sta CURRCOLOURSET
                jsr setbrightest
                lda #OPC_BIT_ABS
                sta chunky4switch; disable chunky mode
                lda #<(((((interludescreen&$3fff)>>6) | ((font&$3fff)>>10)) | $01) ^ (((chunky4screen0b ^ chunky4screen1b) & $3fff) >> 6))
                sta CURRCHUNKY4ADDR
                lda #DISPLAY_ENABLE | LINES_25 | SCROLLY_3
                sta VIC2_CTRL1
clearline:      lda #' '
                ldx #$27
:               sta interludescreen+(TEXTLINE*$28)+STARTCOLUMN,x
                dex
                bpl :-
                rts

stopinterlude:  cpx TRACKPOS+$0e
                bcs stopinterlude
                tya
                adc COLOURSCHEME
                sta CURRCOLOURSET
                lda #>chunky4screen0b
                jsr clearscreen
                stx VIC2_CTRL1
                jsr setbrightest
                lda #OPC_STA_ABS
                sta chunky4switch
                lda #<(((chunky4screen1b&$3fff)>>6) | ((chunky4charset&$3fff)>>10)) | $01
                sta CURRCHUNKY4ADDR
                lda #DISPLAY_ENABLE | LINES_25 | SCROLLY_3
                sta VIC2_CTRL1
.ifdef NTSC_VERSION
                lda #framespertick*$10*6/5
.else
                lda #framespertick*$10-1
.endif
                sta interludespeed
                rts
                
.endmacro; SUB_INTERLUDE

.macro SUB_INTERLUDEIRQHANDLER

                ldx INTERLUDECOUNT
                ldy INTERLCHARPOS
                lda strings,x
                beq nextline
                bmi nointerludeupd
                sta interludescreen+(TEXTLINE*$28)+STARTCOLUMN,y
                inc INTERLCHARPOS
                dec INTERLUDETIMER
.ifdef NTSC_VERSION
                bne nextchar
.else                
                bpl nextchar
.endif
nextline:       sta INTERLCHARPOS
                dec INTERLUDETIMER
.ifdef NTSC_VERSION
                bne nointerludeupd
.else                
                bpl nointerludeupd
.endif
                lda INTERLUDETIMER
                clc
interludespeed = *+$01
.ifdef NTSC_VERSION
                adc #framespertick*$08*6/5
.else
                adc #framespertick*$08-1
.endif
                sta INTERLUDETIMER
                jsr clearline
nextchar:       inc INTERLUDECOUNT
nointerludeupd:

.endmacro; SUB_INTERLUDEIRQHANDLER

.segment "INTERLUDESCREEN"
interludescreen: