.macro IRQ_HANDLER
				; irq handler
irqhandler:     pha
				; read timer value and compensate for variance
				lda CIA1_TA_LO
				eor #%00000111
			    sta *+$04
compensatebegn: .byte OPC_BPL, OPC_LDA_IMM
				lda #OPC_LDA_IMM
				lda #OPC_LDA_IMM
				lda #OPC_LDA_IMM
				lda OPC_CLC
compensateend:
                .ASSERT (>compensateend) = (>compensatebegn), error, "raster flicker compensation page boundary crossing"

				lda VIC2_RASTERLINE
				clc
				adc #$08
				sta VIC2_RASTERLINE
                lda CURRCHUNKY4ADDR
                sta VIC2_ADDR
				inc VIC2_IRR
				lda VIC2_CTRL1
				eor #SCROLLY_4
				dec CHUNKY4COUNT
				php
.ifdef NTSC_VERSION
				nop
.endif
chunky4switch:  sta VIC2_CTRL1
				eor #SCROLLY_4
                sta VIC2_CTRL1
                lda CURRCHUNKY4ADDR
                eor #<(((chunky4screen0b ^ chunky4screen1b) & $3fff) >> 6)
                sta VIC2_ADDR
				plp
                bne irqend

                txa
                pha
                tya
                pha
                lda VIC2_RASTERLINE
                cmp #$e0
                bcs vblank
.ifdef NTSC_VERSION
                ldy #$1e
.else
                ldy #$1c
.endif
:               dey
                bne :-
                ldx CURRCOLOURSET
                ldy #$01
:               lda coloursets+$07,x
                sta VIC2_BORDERCOLOUR+$02,y
                inx
                dey
                bpl :-
                lda coloursets+$04,x; bottom background colour
                ldy #$0e
:               dey
                bne :-
                sta VIC2_BGCOLOUR
.ifdef NTSC_VERSION
nocoloursplit:  lda #$0e
.else
nocoloursplit:  lda #$0d
.endif
                sta CHUNKY4COUNT
                
                pla
                tay
                pla
                tax
irqend:         pla
                rti

vblank:         SUB_PLAYMUSIC; music.s
                SUB_INTERLUDEIRQHANDLER; interlude.s               

.ifdef NTSC_VERSION                
                lda #$80*5/6+1
.else
                lda #$80
.endif
                ldy #FRAMECOUNTER
                jsr zpadd8to16bits

				lda #$36
                sta VIC2_RASTERLINE
                inc VIC2_IRR

                ldx CURRCOLOURSET
                ldy #$03
:               lda coloursets+$01,x
                sta VIC2_BORDERCOLOUR,y
                inx
                dey
                bpl :-

    			lda #$0c
                sta CHUNKY4COUNT
                pla
                tay
                pla
                tax
                pla
                rti
                
.endmacro; IRQ_HANLDER
