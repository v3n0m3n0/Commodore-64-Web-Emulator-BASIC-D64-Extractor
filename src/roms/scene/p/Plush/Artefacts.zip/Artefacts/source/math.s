
.define POLYPH $71
.define GIVAYF $b391
.define POLYX  $e059
.define GETADR $b7f7

.macro SUB_INITMATH

                lda #<tablespolynom
calctables:     sta POLYNOMPOINTER
polynomialcnt = *+$01
                ldy polynomiallengths
calctable:      dey
                sty POLYNOMXVALUE
                lda #$00         ; hi-byte
                jsr GIVAYF       ; integer to float, set x
                lda POLYNOMPOINTER
                ldy #>tablespolynom
                jsr POLYX        ; compute polynomial at x
                jsr GETADR       ; float to integer
                ldy POLYNOMXVALUE
tabledest = *+$02
                sta tables+$00,y
                bne calctable
                inc polynomialcnt; advance to next counter byte
                inc tabledest
                lda #$05
               ;clc
                adc POLYPH
                cmp #<polynomiallengths
                bne calctables   ; jmp

.endmacro; SUB_INITMATH

.macro SUB_MATH
                ; generate x-perspective table
                ; in:  a - hi(tableaddress)
                ;      x - and mask
calcperspxtabl: stx POINTER+$01
                stx POINTER+$03
                sty POINTER+$04
                lda #$25
                sta POINTER+$02
                lda #$1a
                sta POINTER+$05
                lda #$00
                sta POINTER+$00
                sta BUFFER+$00
                sta BUFFER+$01
                sta BUFFER+$02
calcskyperspx:  ldy BUFFER+$02
                lda perspectivexaddlotable,y
                ldx perspectivexoffstable,y
                ldy #BUFFER+$00
                jsr zpadd8to16bits
                lda #$00
                tay
:               clc
                adc BUFFER+$00
                pha
                txa
                and POINTER+$04
                sta (POINTER+$00),y; left pixel
                adc BUFFER+$01
                tax
                pla
                clc
                adc BUFFER+$00
                pha
                txa
                and POINTER+$04
                sta (POINTER+$02),y; right pixel
                adc BUFFER+$01
                tax
                pla
                iny
                cpy #$25
                bne :-
                lda #$4a
                jsr addtopointer
                jsr zpadd74
                inc BUFFER+$02
                dec POINTER+$05
                bne calcskyperspx
                rts

                ; build 16-bit slope table with 8-bit slope
                ; in: a - lo(slope)
                ;     x - hi(slope)
                ;     y - starting position in table
                ;     POINTER+$00 - lo(lotableaddress)
                ;     POINTER+$01 - hi(lotableaddress)
                ;     POINTER+$02 - lo(hitableaddress)
                ;     POINTER+$03 - hi(hitableaddress)
buildslopetb16: sta BUFFER+$00
                lda #$00
                tax
buildslopetbex: sta (POINTER+$00),y
                clc
                adc BUFFER+$00
                pha
                txa
                sta (POINTER+$02),y
                adc #$00
                tax
                pla
                iny
                bpl buildslopetbex

                ; fall through

				; get pseudo-random number
				; won't trash x, y
				; out: a - number in the range [$00..$ff]
.ifdef NTSC_VERSION
getrandom:      eor Artefacts+$0655
.else
getrandom:      eor Artefacts+$0653
.endif
                inc getrandom+$01
                rts

                ; sine function
                ; puts a scaled sine period to sincostable
                ; in:  x - amplitude * 2
                ; out: x = $ff
                ; trashes sincostable+$0100, a, x, y
getsine:        stx BUFFER+$04
                ldx #$7f
getsineloop:    ldy BUFFER+$04
                lda sincostableraw,x
                jsr mulu_8_8_16
                iny
                bpl :+
               ;sec
                adc #$00
:               sta sincostable+$00,x
                eor #%11111111
                sta sincostable+$80,x
                dex
                bpl getsineloop
                rts

                ; signed integer square routine
                ; 8.0^2 = 16.0
                ; in:  a - argument
                ;      c - must be cleared
                ; out: a - hi(result)
                ;      y - lo(result)
                ;      c - set
sqrs_8_16:      bpl :+
                eor #$ff
                adc #$01
:               tay

                ; fall through

                ; unsigned multiplication routine
                ; 8 bits * 8 bits = 16 bits
                ; in:  a - factor 0
                ;      y - factor 1
                ; out: a - hi(product)
                ;      y - lo(product)
                ;      c - set
                ; trashes a, y
mulu_8_8_16:    sta BUFFER+$00
                sty BUFFER+$01
                ldy #$01
                sty BUFFER+$02
                dey
                sty BUFFER+$03
                tya
:               lsr BUFFER+$00
                bcc :+
                pha
                tya
                clc
                adc BUFFER+$01
                tay
                pla
                adc BUFFER+$03
:               asl BUFFER+$01
                rol BUFFER+$03
                rol BUFFER+$02
                bcc :--
                rts

                ; unsigned fixed point division routine
                ; 8.0 / 8.0 = 8.8
                ; in:  a - dividend
                ;      x - divisor
                ; out: a - frac(quotient)
                ;      RESULT+$01 - abs (quotient)
divu_80_80_88:  stx BUFFER+$06
                sta DIVIDEND
                stx DIVISOR+$00
                ldy #$01
                sty RESULT+$00
                dey
                sty RESULT+$01
                sty DIVISOR+$01
                sty DIVISOR+$02
:               lsr DIVISOR+$00
                ror DIVISOR+$01
                ror DIVISOR+$02
                tya
                sec
                sbc DIVISOR+$02
                pha
                lda DIVIDEND
                sbc DIVISOR+$01
                tax
                lda #$00
                sbc DIVISOR+$00
                pla
                bcc :+
                stx DIVIDEND
                tay
:               rol RESULT+$00
                rol RESULT+$01                
                bcc :--
                lda RESULT+$00
                ldx BUFFER+$06
                rts

                ; unsigned integer square root routine (naive but mem-saving approach)
                ; 16.0^(1/2) = 8.0
                ; in:  a - hi(argument)
                ;      y - lo(argument)
                ; out: a - result
sqrtu_16_8:     tax
                lda #$00
                sta BUFFER+$00
                sta BUFFER+$01
                sta BUFFER+$02
                sta BUFFER+$03
                sta BUFFER+$04
:               lda BUFFER+$03
                adc BUFFER+$00
                sta BUFFER+$00
                inc BUFFER+$03
                lda BUFFER+$04
                adc BUFFER+$01
                sta BUFFER+$01
                inc BUFFER+$03
                bne :+
                inc BUFFER+$04
:               cpy BUFFER+$00
                txa
                sbc BUFFER+$01
                lda BUFFER+$02
                inc BUFFER+$02                                
                bcs :--
                
                ; addition for the artefact scene
                and #%00111111; the textures are 64x64 pixels                
                eor #>yrotskytexture                
                ldy POINTER+$11
                rts

                ; unsigned fixed point arcus tangent routine
                ; the result is -pi/2..pi/2 scaled to -$80..$7f
                ; arctan(8.0, 8.0) = 8.8
                ; in:  a - y coordinate
                ;      x - x coordinate
                ; out: a - result
atnu_80_80_88:  stx BUFFER+$00
	            cmp BUFFER+$00
	            beq arctan
	            php
	            bcc :+
	            sta BUFFER+$00
	            txa
	            ldx BUFFER+$00
:               jsr divu_80_80_88
	            bpl :+
	            eor #$ff
:               tax
	            lda arctantable,x
	            plp
                bcs :+
                eor #$ff
:               rts
arctan:         lda #$7f
                rts
                
.endmacro; SUB_MATH

.macro DAT_TABLES
perspectivexaddlotable:
    .incbin "perspectivexaddtable.bin"

perspectivexoffstable:
    .incbin "perspectivexoffstable.bin"

perspectiveytable:
    .incbin "perspectiveytable.bin"

.ifdef FAST_SQRT
bittable:       .byte $01,$02,$04,$08,$10,$20,$40,$80
.endif
.endmacro; DAT_TABLES

.macro DAT_SINCOSTABLERAW
sincostableraw = tables+$0200
.endmacro; DAT_SINCOSTABLERAW

.macro DAT_ARCTANTABLE
arctantable    = tables+$0000
.endmacro; DAT_ARCTANTABLE

.segment "SINCOSTABLE"
sincostable:
