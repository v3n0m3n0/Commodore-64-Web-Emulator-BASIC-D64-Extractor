

framespertick   = 7  ; duration per note
                     ; in frames

vibinstr        = -1;$03; vibrato is not used here to save memory
vibdelay        = $10; frames
vibspeed        = $30; per frame
vibamp          = $40; max $7f,
                     ; must be mutiple of vibspeed
vibscale        = $01

offbeatv        = 3  ; voice number
offbeat         = 2  ; frames

detunedv        = 3  ; voice number
detuneadd       = $1e  ; not used in this tune to save memory

filterv         = 1  ; 1: voice 1
                     ; 2: voice 2
                     ; 4: voice 3
filtertype      = $10; low pass

voice1on        = 1
voice2on        = 1
voice3on        = 1

.macro SUB_INITMUSIC
               ;ldy #$00
                tya
:               sta $02,y
                iny
                bne :-

                lda #track1-tracks
                sta TRACKPOS+$00
                lda #track2-tracks
                sta TRACKPOS+$07
                lda #track3-tracks
                sta TRACKPOS+$0e

.if offbeat > 0
                lda #offbeat
                sta DURATION+(7*(offbeatv-1))
.endif
.if detuneadd > 0
                lda #detuneadd
                sta DETUNE+(7*(detunedv-1))
.endif
                lda #$f0+filterv
                sta SID_FILTER_CONTROL_1; maximum resonance
                lda #filtertype+$0f; full vol
                sta SID_FILTER_CTRL2_VOL

.endmacro; SUB_INITMUSIC

.macro SUB_PLAYMUSIC
    .ifdef NTSC_VERSION
                dec NTSC_COUNT
                bpl :+
                lda #$05
                sta NTSC_COUNT
                jmp aftmusic
:
    .endif
                ; filter sweep,
                ; create a cyclic filter cutoff
                ; triangle pattern
                lda FILTVALLO
                ldx FILTSWEEP
                ldy FILTDIR
                beq :+
                clc
                adc filtspeedlo-$f0,x
                sta FILTVALLO
                sta SID_FILTER_CUTOFF_LO
                lda FILTVALHI
                adc filtspeedhi-$f0,x
                cmp filttop-$f0,x
                bcc :++
                dey
                beq :++
:               sec
                sbc filtspeedlo-$f0,x
                sta FILTVALLO
                sta SID_FILTER_CUTOFF_LO
                lda FILTVALHI
                sbc filtspeedhi-$f0,x
                cmp filtbott-$f0,x
                bcs :+
                iny
:               sta FILTVALHI
                sty FILTDIR
                sta SID_FILTER_CUTOFF_HI

                ldx #$0e; start with voice 3

                ; track driver
voiceloop:      dec DURATION,x
                bpl soundframe
                                                
                lda #framespertick-1
                sta DURATION,x
                dec DUR,x
                bpl soundframe
                ; new note

                lda NEXTDUR,x
                sta DUR,x        

                ldy SEQPOS,x
                bne getnote
                ; new sequence                

nextseq:        ldy TRACKPOS,x
                lda tracks-$01,y
                dec SEQCOUNT,x
                bpl seqagain
                
                iny
                lda tracks-$01,y
                bne notrkloop

                ; track looped
                lda tracks+$00,y
                tay
                iny
                lda tracks-$01,y

notrkloop:      bpl notranspos
                and #%01111111
                sta TRANSP,x; transpose
                iny
                lda tracks-$01,y

notranspos:     sty TRACKPOS,x
                pha
                lsr
                lsr
                lsr
                lsr
                sta SEQCOUNT,x                
                pla
seqagain:       and #%00001111
                tay
                lda sequences-$01,y; y >= $01
                sta SEQPOS,x

                ; sequence driver

noteloop:       ldy SEQPOS,x

                ; here, have code to run
                ; after each note

getnote:        lda seqdata,y
                beq nextseq

                inc SEQPOS,x
                tay
                bpl nocommand

                dey
                bpl modulate; noteoff

                cpy #$f0
                bcs setfsweep

                tya
                and #%01111111
                sta DUR,x; setdur
                sta NEXTDUR,x
                bcc noteloop; jmp

setfsweep:      lda filtbott-$f0,y
                sta FILTVALHI
                lda filtstartdir-$f0,y
                sta FILTDIR
                sty FILTSWEEP
                bne noteloop; jmp                
                lda filttop-$f0,y
                sta FILTVALHI
                bcs noteloop; jmp

                ; modulate the sound each frame
soundframe:     lda DUR,x
                ora DURATION,x
                bne modulate
                sta PULSEADDHI,x
                sta PULSELO,x
                sta VIBRATO,x
                sta VIBDIR,x                
                
                ldy SEQPOS,x
:               lda seqdata,y
                bpl :+
                asl
                beq gateoff
                iny
                bne :-; jmp
:               lda #$00
                sta SID_V1_SR,x

gateoff:        lda #$fe
                sta GATEMASK,x; gate off
                bne modulate; jmp                

nocommand:      cmp #$60
                bcc :+
                sta INSTR,x
                bcs noteloop; jmp

                ; strike new note
:               clc
                adc TRANSP,x
                sta NOTE,x
                lda #$ff
                sta GATEMASK,x; gate switch, $ff
                lda #vibdelay
                sta VIBCOUNT,x
                ldy INSTR,x
                lda adtable-$60,y
                sta SID_V1_AD,x
                lda srtable-$60,y
                sta SID_V1_SR,x
                lda pulshi-$60,y
                sta PULSEHI,x
                lda pulsadd-$60,y
                sta PULSEADDLO,x
                lda instruments-$60,y
wavetablejump:  sta INSTRBASE,x

modulate:       ldy INSTRBASE,x
                lda wavetable+$00,y
                bne nowaveend
                ; wavetable jump
                lda wavetable+$01,y
                bpl wavetablejump

nowaveend:      inc INSTRBASE,x
                and GATEMASK,x
.if voice1on = 0
                cpx #$00
                beq voiceoff
.endif
.if voice2on = 0
                cpx #$07
                beq voiceoff
.endif
.if voice3on = 0
                cpx #$0e
                beq voiceoff
.endif
                sta SID_V1_CONTROL,x
                
voiceoff:       lda wavefreq,y
                bmi drumfreq
                clc
                adc NOTE,x
                ldy #$00
                sty FREQHI
:               sta FREQLO
                iny
                sec
                sbc #$0c
                bpl :-
                sty VIBBUFFER0
                ldy FREQLO
                lda notefreqs,y
                ldy VIBBUFFER0
:               asl
                rol FREQHI
                dey
                bne :-

.if vibinstr >= 0
                pha
                sty VIBBUFFER0
                sty VIBBUFFER1                
                lda INSTR,x
                cmp #vibinstr+$60
                bne novibrato
                lda VIBCOUNT,x
                bne vibwait
                lda VIBRATO,x
                ldy VIBDIR,x
                beq :+
                clc
                adc #vibspeed
                cmp #vibamp
                bne :++
                dey
                beq :++
:               sec
                sbc #vibspeed
                cmp #-vibamp
                bne :+
                iny
:               sta VIBRATO,x
                sty VIBDIR,x
                sta VIBBUFFER0
                asl
                lda #$ff
                bcs :+
                lda #$00
:
.if vibscale = 1
                asl VIBBUFFER0
    .if vibamp > $40
                rol
    .endif
.else
                ldy #vibscale
:               asl VIBBUFFER0
                rol
                dey
                bne :-
.endif
                sta VIBBUFFER1
                SKIPWORD
vibwait:        dec VIBCOUNT,x
novibrato:      

                pla
.endif

.if detuneadd > 0
                clc
                adc DETUNE,x
    .if vibinstr >= 0
                php
                clc
                adc VIBBUFFER0
                sta SID_V1_FREQ_LO,x
                lda VIBBUFFER1
                adc FREQHI
                plp
    .else
                sta SID_V1_FREQ_LO,x
                lda FREQHI
                adc #$00
    .endif
.else
    .if vibinstr >=0
                clc
                adc VIBBUFFER0
                sta SID_V1_FREQ_LO,x
                lda VIBBUFFER1
                adc FREQHI
    .else
                sta SID_V1_FREQ_LO,x
                lda FREQHI
    .endif
.endif
                SKIPWORD
drumfreq:       eor #%10000000
                sta SID_V1_FREQ_HI,x

                ; pulse sweep
                lda PULSELO,x
                clc
                adc PULSEADDLO,x
                sta PULSELO,x
                sta SID_V1_PULSE_LO,x
                lda PULSEHI,x
                adc PULSEADDHI,x
                sta PULSEHI,x
                ldy INSTR,x
                sta SID_V1_PULSE_HI,x
                cmp pulshi-$60,y
                bcc :+
                eor #%00001111
                cmp pulshi-$60,y
                bne :++
:               lda PULSEADDLO,x
                eor #$ff
                sta PULSEADDLO,x
                lda PULSEADDHI,x
                eor #$ff
                sta PULSEADDHI,x

:               txa
                axs #$07
                bmi aftmusic
                jmp voiceloop
aftmusic:       
.endmacro; SUB_PLAYMUSIC

.macro DAT_MUSIC

                ; tune data

                ; base note frequencies
notefreqs:
.ifdef NTSC_VERSION
    .incbin "notefreqs_ntsc.bin"
.else
    .incbin "notefreqs_pal.bin"
.endif

                ; filter sweep settings
                ;      0   1   2   3   4
                ;       5   6   7   8
filtbott:       .byte $02,$02,$02,$08,$02
                .byte $02,$10,$02,$03
filttop:        .byte $a0,$0a,$40,$60,$02
                .byte $60,$60,$20,$03
filtspeedlo:    .byte $58,$40,$80,$00,$00
                .byte $00,$00,$10,$00
filtspeedhi:    .byte $00,$00,$00,$01,$00
                .byte $05,$01,$00,$00
filtstartdir:   .byte $00,$01,$01,$00,$00; 1: up, 0: down
                .byte $00,$01,$00;$00 dir doesn't matter with speed = $0000

                ; track data
                ; $01..$7f sequence number and count
                ;   $xy x: number of repetitions - 1
                ;       y: sequence number
                ; $80..$ff transpose up
                ;      $00 loop
                loop      = $00
                transpose = $80
tracks:
track1:         .byte $04
track1loop:     .byte transpose+$0c
                .byte $01
                .byte $37
                .byte transpose+$07
                .byte $37
                .byte transpose+$0c
                .byte $37
                .byte transpose+$07
                .byte $37
                .byte transpose+$0c
                .byte $37
                .byte transpose+$07
                .byte $37
                .byte transpose+$0f
                .byte $1b
                .byte transpose+$0a
                .byte $1b
                .byte transpose+$0d
                .byte $1b
                .byte transpose+$08
                .byte $1b
                
                .byte loop,track1loop-tracks

track2:         .byte $35
track2loop:     .byte transpose+$00
                .byte $32
                .byte transpose+$07
                .byte $32
                .byte transpose+$00
                .byte $32
                .byte transpose+$07
                .byte $32

                .byte transpose+$00
                .byte $32
                .byte transpose+$07
                .byte $32
                .byte transpose+$00
                .byte $32
                .byte transpose+$07
                .byte $32
                .byte transpose+$00
                .byte $32
                .byte transpose+$07
                .byte $32
                
                .byte transpose+$03
                .byte $7c
                .byte transpose+$0a
                .byte $7c
                .byte transpose+$01
                .byte $7c
                .byte transpose+$08
                .byte $7c

                .byte loop,track2loop-tracks

track3:         .byte $35
track3loop:     .byte transpose+$00
                .byte $06
                .byte $35
                .byte transpose+$07
enterdrone:     .byte $25
planetsceneend: .byte $05,transpose+$00
                .byte $35
                .byte transpose+$07
                .byte $25,$08
                
entersurface:   .byte transpose+$0c
                .byte $19
                .byte transpose+$07
                .byte $19
                
                .byte transpose+$0c
                .byte $03
surfacescenend: .byte $03

enterartefact:  .byte transpose+$0f
                .byte $0a
                .byte transpose+$0a
                .byte $0a
                .byte transpose+$0d
                .byte $0a
                .byte transpose+$14
                .byte $0a
                
                .byte loop,track3loop-tracks

sequences:      ; sequence indices
                .byte seq1-seqdata
                .byte seq2-seqdata
                .byte seq3-seqdata
                .byte seq4-seqdata
                .byte seq5-seqdata
                .byte seq6-seqdata
                .byte seq7-seqdata
                .byte seq8-seqdata
                .byte seq9-seqdata
                .byte seqa-seqdata
                .byte seqb-seqdata
                .byte seqc-seqdata

seqdata:        ; $01..$5f: note
                ; $61..$7f: set instrument
                ;   >= $80: control command
                ;      $80: note off
                ;      $81+n: increase duration
                ;      $f1+n: set filter sweep
                ; $00: sequence end

                in0  = $60; oct. bass
                in1  = $61; flute
                in2  = $62; flute echo
                in3  = $63; lead + vib
                in4  = $64; noise
                in5  = $65; echo
                in6  = $66; bass
                in7  = $67; bass + noise
                in8  = $68; space
                in9  = $69; drum
                ina  = $6a; snare

                nof  = $80; dont play a note
                          ; and let the previous
                          ; one fade out
                             
                dur  = $81;+n: set duration of
                             ; following notes
                             ; to n ticks
                             ; if used with noteoff
                             ; this one must appear
                             ; before noteoff

                fsweep  = $f1;+n: sets filter sweep n
                
                fs0 = fsweep+$00
                fs1 = fsweep+$01
                fs2 = fsweep+$02
                fs3 = fsweep+$03
                fs4 = fsweep+$04
                fs5 = fsweep+$05
                fs6 = fsweep+$06
                fs7 = fsweep+$07
                fs8 = fsweep+$08

                endmark = $00

seq1:           .byte fs4,in0,dur+$3f
                .byte gx0
                .byte fs8
                .byte dx1
                .byte fs1
                .byte gx0
                .byte fs7,dur+$0f
                .byte dx1
                .byte nof
                .byte nof
                .byte fs2
                .byte dx1
                .byte in6
                .byte dur+$00
                .byte fs3
                .byte endmark

seq2:           .byte dur+$00
                .byte in1,gx3,in2,gx3
                .byte in1,dx4,in2,dx4
                .byte in1,ax3,in2,ax3
                .byte in1,b3,in2,b3
                .byte in1,gx4,in2,gx4
                .byte in1,dx5,in2,dx5
                .byte in1,ax4,in2,ax4
                .byte in1,b4,in2,b4
                .byte endmark

seq3:           .byte in3,dur+$07
                .byte gx2,nof
                .byte gx3,nof
                .byte fx3,nof
                .byte f3,nof
                .byte dx3,nof
                .byte dx4,nof
                .byte cx4,nof
                .byte c4,nof
                .byte endmark

seq4:           .byte fs0,in4,dur+$3f
                .byte gx2
                .byte endmark

seq5:           .byte in5,dur+$01
                .byte gx3,dx4,ax3,b3,gx4,dx5,ax4,b4
                .byte endmark

seq6:           .byte dur+$00
                .byte gx3
                .byte endmark

seq7:           .byte dur+$00
                .byte gx1,nof
                .byte gx1,gx1,nof
                .byte gx1,gx1,nof
                .byte gx1,gx1,nof
                .byte gx1,gx1,nof
                .byte fx2,gx2
                .byte endmark

seq8:           .byte in5,dur+$01
                .byte gx3,dx4,ax3,b3,gx4,dx5,ax4
                .byte dur+$00
                .byte ax4
                .byte endmark

seq9:           .byte in8
                .byte dur+$0b,gx3
                .byte dur+$03,fx3
                .byte dur+$07,gx3,b3
                .byte endmark

seqa:           .byte in8,dur+$0f
                .byte gx3,fx3,e3,dx3
                .byte endmark

seqb:           .byte fs3,in7
                .byte dur+$01,gx0
                .byte dur+$00,nof
                .byte dur+$01,gx0
                .byte dur+$00,nof
                .byte dur+$01,gx0,nof
                .byte fs5,in9,dur+$01
                .byte cx3
                .byte fs5,ina,dur+$03
                .byte cx3                
                .byte fs6,in7
                .byte dur+$01,gx0
                .byte dur+$00,nof
                .byte dur+$01,gx0
                .byte dur+$00,nof
                .byte dur+$01,gx0,nof
                .byte fs5,in9
                .byte cx1
                .byte fs5,ina,dur+$00
                .byte cx3
                .byte fs5,dur+$02
                .byte cx3
                .byte endmark

seqc:           .byte in1,dur+$00
                .byte gx3,dx4,ax3,b3
                .byte gx4,dx5,ax4,b4
                .byte endmark

                ; wave table
                ; $00 jump
                ; else waveform ($10-$f0)
                ;     +wavereset($08)
                ;     +ringmod($04)
                ;     +sync($02)
                ;     +gate($01)
               
                jump = $00
        
wavetable:
octavebass:     .byte $09
:               .byte $41
                .byte $41
                .byte $41
                .byte $41
                .byte $41
                .byte $41
                .byte $41
                .byte $41
                .byte jump
                .byte :- -wavetable

flute:
bass:           .byte $09
                .byte $41
:               .byte $40
                .byte jump
                .byte :- -wavetable

fluteecho:      .byte $09
:               .byte $11
                .byte jump
                .byte :- -wavetable

leadvib:
echo:           .byte $09 
:               .byte $41 
                .byte jump
                .byte :- -wavetable

bassnoise:      .byte $09 
                .byte $81 
                .byte jump
                .byte $01 

noise:          .byte $09 
:               .byte $81 
                .byte $81 
                .byte jump
                .byte :- -wavetable

space:          .byte $09
                .byte $41
:               .byte $20
                .byte $26
                .byte $26
                .byte $16
                .byte $16
                .byte $10
                .byte $10
                .byte $10
                .byte $10
                .byte $10
                .byte $10
                .byte $10
                .byte $10
                .byte $08
                .byte $08
                .byte $08
                .byte $08
                .byte $08
                .byte $08
                .byte $08
                .byte jump
                .byte :- -wavetable

drum:           .byte $09
                .byte $81
                .byte $41
                .byte $41
                .byte $41
                .byte $11
:               .byte $10
                .byte jump
                .byte :- -wavetable

snare:          .byte $09
                .byte $81
                .byte $41
                .byte $40
:               .byte $80
                .byte jump
                .byte :- -wavetable

                ; wave frequency
                ; table
                ; $00..$7f: transpose up
                ; $80..$ff: hard freqs $00..$7f
                ;   (written to freq hibyte)
wavefreq:       .byte $00
                .byte $00
                .byte $00
                .byte $00
                .byte $00
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte   0
                .byte   0
                
                .byte $00
                .byte $0c
                .byte $00
                .byte   0
                .byte   0
                
                .byte $00
                .byte $00
                .byte   0
                .byte   0

                .byte $00
                .byte $00
                .byte   0
                .byte   0
                
                .byte $00
                .byte $d8
                .byte   0
                .byte   0
                
                .byte $00
                .byte $d8
                .byte $a0
                .byte   0
                .byte   0
                
                .byte $00
                .byte $00
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0d
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte $0c
                .byte   0
                .byte   0
                
                .byte $00
                .byte $d8
                .byte $8c
                .byte $88
                .byte $86
                .byte $84
                .byte $82
                .byte   0
                .byte   0
                
                .byte $00
                .byte $d8
                .byte $8c
                .byte $84
                .byte $d8

                ; instrument pointers into
                ; the wavetable
instruments:    .byte octavebass-wavetable; instr0
                .byte flute-wavetable     ; instr1
                .byte fluteecho-wavetable ; instr2
                .byte leadvib-wavetable   ; instr3
                .byte noise-wavetable     ; instr4
                .byte echo-wavetable      ; instr5
                .byte bass-wavetable      ; instr6
                .byte bassnoise-wavetable ; instr7
                .byte space-wavetable     ; instr8
                .byte drum-wavetable      ; instr9
                .byte snare-wavetable     ; instr10

                ; instrument adsr and pulse
                ; tables
                ; correspond with the
                ; instrument pointers table
                ;      0   1   2   3 ; instr
                ;       4   5   6   7
                ;      8   9   a
adtable:        .byte $00,$04,$00,$a9
                .byte $00,$00,$0f,$0f
                .byte $00,$0f,$0f
srtable:        .byte $ff,$49,$89,$7d
                .byte $4a,$49,$fa,$f9
                .byte $fd,$f9,$fa
pulshi:         .byte $08,$07,$08,$01
                .byte $08,$08,$03,$03
                .byte $02,$08,$08
pulsadd:        .byte $00,$44,$00,$f0
                .byte $00,$00,$50,$50
                .byte $60,$08,$08

.endmacro; DAT_MUSIC

                ; note definitions
                c0  = $01; lowest frequency
                cx0 = $02
                d0  = $03
                dx0 = $04
                e0  = $05
                f0  = $06
                fx0 = $07
                g0  = $08
                gx0 = $09
                a0  = $0a
                ax0 = $0b
                b0  = $0c

                c1  = $0d
                cx1 = $0e
                d1  = $0f
                dx1 = $10
                e1  = $11
                f1  = $12
                fx1 = $13
                g1  = $14
                gx1 = $15
                a1  = $16
                ax1 = $17
                b1  = $18
        
                c2  = $19
                cx2 = $1a
                d2  = $1b
                dx2 = $1c
                e2  = $1d
                f2  = $1e
                fx2 = $1f
                g2  = $20
                gx2 = $21
                a2  = $22
                ax2 = $23
                b2  = $24

                c3  = $25
                cx3 = $26
                d3  = $27
                dx3 = $28
                e3  = $29
                f3  = $2a
                fx3 = $2b
                g3  = $2c
                gx3 = $2d
                a3  = $2e
                ax3 = $2f
                b3  = $30
                
                c4  = $31
                cx4 = $32
                d4  = $33
                dx4 = $34
                e4  = $35
                f4  = $36
                fx4 = $37
                g4  = $38
                gx4 = $39
                a4  = $3a
                ax4 = $3b
                b4  = $3c
                
                c5  = $3d
                cx5 = $3e
                d5  = $3f
                dx5 = $40
                e5  = $41
                f5  = $42
                fx5 = $43
                g5  = $44
                gx5 = $45
                a5  = $46
                ax5 = $47
                b5  = $48

                c6  = $49
                cx6 = $4a
                d6  = $4b
                dx6 = $4c
                e6  = $4d
                f6  = $4e
                fx6 = $4f
                g6  = $50
                gx6 = $51
                a6  = $52
                ax6 = $53
                b6  = $54
               
                c7  = $55
                cx7 = $56
                d7  = $57
                dx7 = $58
                e7  = $59
                f7  = $5a
                fx7 = $5b
                g7  = $5c
                gx7 = $5d
                a7  = $5e
                ax7 = $5f; highest frequency
               ;b7  = $60; occupied by instrument 0
                
                h0  = b0
                h1  = b1
                h2  = b2
                h3  = b3
                h4  = b4
                h5  = b5
                h6  = b6
