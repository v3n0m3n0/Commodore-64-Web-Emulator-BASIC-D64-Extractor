
### GNU Octave script file to find the polynomial for a curve contained in the binary infile[s]
### to compress it - lossily,
### output to outfile,
### polynomial degree must be defined

## helper functions

# print a number to a textfile in CBMBASIC float format (8 bits biased exponent, 32 bits signed mantissa)
# returns float in cbmbasic precision
function cbmfloat = printcbmfloat(fileid, value, mantissa_size)

    if value == 0
        exponent = 0;
        mantissa = 0;
    else
        exponent = ceil(log2(abs(value)));
        mantissa = abs(value) / 2^(exponent-32);
        if (mantissa-floor(mantissa)) >= 0.5
            mantissa = mantissa + 1;
        endif
        
        mantissa = bitand(mantissa, 2^31-1);
        if value < 0
            mantissa = bitset(mantissa, 32);
        endif
    endif
    
    exp = exponent+128+8; # add 8 to the exponent so we can grab the values as hi-bytes
    
    mantissa = bitand(mantissa, bitxor(2^32-1, 2^(32-mantissa_size)-1));
    
    mant3 = bitand(bitshift(mantissa, -24), 255);
    mant2 = bitand(bitshift(mantissa, -16), 255);
    mant1 = bitand(bitshift(mantissa,  -8), 255);
    mant0 = bitand(mantissa               , 255);

    fprintf(fileid, ".byte $%.2x,", exp);
    fprintf(fileid, "$%.2x,", mant3);
    fprintf(fileid, "$%.2x,", mant2);
    fprintf(fileid, "$%.2x,", mant1);
    fprintf(fileid, "$%.2x" , mant0);
    fprintf(fileid, "; %.20f\n", value);

    cbmfloat = mant0;
    cbmfloat = bitor(bitshift(mant1,8),cbmfloat);
    cbmfloat = bitor(bitshift(mant2,16),cbmfloat);
    cbmfloat = bitor(bitshift(mant3,24),cbmfloat);    
    
    if bitand(cbmfloat,2^31) > 0
        cbmfloat = -cbmfloat * (2^(exp-128-8-32));
    else
        cbmfloat = bitor(cbmfloat, 2^31);
        cbmfloat = cbmfloat * (2^(exp-128-8-32));
    endif

    printf("%.20f -> %.20f\n", value, cbmfloat);
endfunction

# split a string by chr and return the substrings in an array
function strings = splitstring(string, chr)
    if index(string,"+") > 0
        pos = findstr(string,chr);
        strings = cellstr(substr(string, 1, pos(1)-1));
        for i = 1:length(pos)-1
            substring = cellstr(substr(string, pos(i)+1, pos(i+1)-pos(i)-1));
            strings = [strings, substring];
        endfor
        substring = cellstr(substr(string, pos(length(pos))+1, length(string)-pos(length(pos))));
        strings = [strings, substring];        
    else
        strings = cellstr(string);
    endif
endfunction

## main

# check number of arguments
if nargin < 3
    printf("Usage:\n");
    printf("octave %s [ infile[+infile]* degree mantissa-size^(degree+1) ]+ outfile\n", program_name);
    quit(-1);
endif

# assign arguments to variables
outfilename = argv(nargin);
polylength = 0;

subtablelengths = 1:0;
subtablenames = cellstr("");

# table lengths list
tablelengths = zeros(1,nargin-1);
numpoints = zeros(1,nargin-1);

# read the infiles into an array
x = 1:0;
y = 1:0;
v = 1:0;

s = 8; # number of intermediate points (see below)

for infilenum = 1:nargin-1
    arg = argv{infilenum};
    names = splitstring(arg,"+");
    
    tableoffset = 0;
    tablelength = 0;
    for infilename = 1:length(names)
        if isdigit(names(infilename))
            continue; # skip degree and mantissa size arguments
        endif
        
        infile = fopen(names(infilename), "rb", "ieee-le");
        if infile == -1
            printf("%s could not be opened for reading.\n", names(infilename));
            quit(-1);
        endif
        [z, incount] = fread(infile, [1, Inf], "uint8=>float64");
        fclose(infile);
        
        # reference table
        v = [v, z];
        
        # only add table start and end point, and some intermediate points as interpolation points
        # to have a better fitting for large tables and prevent from too much degeneration at higher degrees
        
        # start point
        x = [x, tableoffset];
        y = [y, z(1)];
    
        # some intermediate points
        h = incount / (s+1);
        for j = 1:s
            k = round(j*h);
            x = [x, tableoffset+k];
            y = [y, z(k)];
        endfor
    
        # end point
        x = [x, tableoffset+incount-1];
        y = [y, z(incount)];

        tableoffset = tableoffset + incount;
        tablelength = tablelength + incount;
        subtablelengths = [subtablelengths, incount];
        subtablenames = [subtablenames, names(infilename)];
    endfor

    tablelengths(infilenum) = tablelength;
    numpoints(infilenum) = (s+2) * length(names);
    polylength = polylength + tablelength;
endfor

# write polynomial co-efficients to outfile
outfile = fopen(outfilename, "wt");
if outfile == -1
    printf("%s could not be opened for writing.\n", outfilename);
    quit(-1);
endif

fprintf(outfile, "; Polynomial co-efficients to calculate table data according to ");
for i = 1:nargin-1
    if isdigit(argv(i))
        continue; # skip degree and mantissa size arguments
    endif
    
    if i > 1
        fprintf(outfile, ", ");
    endif
    
    fprintf(outfile, "%s", argv(i));
endfor
    
fprintf(outfile, "\n; This file was generated automatically, please do not edit.\n\n");

fprintf(outfile, "POLYNOMIALSLENGTH = %i\n\n", polylength);

j = 0;
for i = 1:length(subtablelengths)
    fprintf(outfile, "TABLE%iOFFSET = %i; %s\n", i-1, j, subtablenames(i));
    j = j + subtablelengths(i);
endfor

fprintf(outfile, "\n");

fprintf(outfile, ".macro DAT_POLYNOMIALS\n\n");

tableoffset = 1;
pointsoffset = 1;
for polynum = 1:nargin-1

    if isdigit(argv(polynum))
        continue; # skip degree and mantissa size arguments
    endif
    
    # find best-fitting polynomial
    
    n = str2num(char(argv(polynum+1)));
    p = polyfit(x(pointsoffset:pointsoffset+numpoints(polynum)-1),y(pointsoffset:pointsoffset+numpoints(polynum)-1),n);
    
    fprintf(outfile, "; %s\n", argv(polynum));

    fprintf(outfile, ".byte $%.2x; degree\n", n);
    for i = 1:n
        p(i) = printcbmfloat(outfile, p(i), str2num(char(argv(polynum+1+i))));
    endfor
    p(n+1) = printcbmfloat(outfile, p(n+1) + 0.5, str2num(char(argv(polynum+n+2))));

    fprintf(outfile, "\n");
        
    # dump the table generated by the polynomial, to spot intolerable degenerations
    for i = 0:tablelengths(polynum)-1
        f = 0;
        for j = 1:n+1
            f = f * i;
            f = f + p(j);
        endfor
        printf("%.3i %.2x %f %f\n", i, v(tableoffset+i), v(tableoffset+i), f);
    endfor
    
    tableoffset = tableoffset+tablelengths(polynum);
    pointsoffset = pointsoffset+numpoints(polynum);    
endfor

fprintf(outfile, "polynomiallengths: .byte ");
for i = 1:length(tablelengths)
    if tablelengths(i) <= 0
        continue;
    endif
    
    if (i > 1)
        fprintf(outfile, ",");    
    endif
    fprintf(outfile, "$%.2x", bitand(tablelengths(i),255));
endfor
fprintf(outfile, "\n\n");

fprintf(outfile, ".endmacro; DAT_POLYNOMIALS\n");

fclose(outfile);
