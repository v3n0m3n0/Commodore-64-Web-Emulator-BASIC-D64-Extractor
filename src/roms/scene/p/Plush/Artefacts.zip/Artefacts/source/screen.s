
; charset chunky4 mode -
; 3 colours with 4 shades plus background

; background colour (%00 bits): VIC2_BGCOLOUR     ($d021)  -  any of the 16 colours
; darkest colour    (%01 bits): VIC2_MULTICOLOUR0 ($d022)  -  any of the 16 colours
; middle colour     (%10 bits): VIC2_MULTICOLOUR1 ($d023)  -  any of the 16 colours
; brightest colour  (%11 bits): VIC2_MULTICOLOUR2 ($d800+) - only the low 8 colours

; chunky byte pixel bits:

; %xxxxyyyy   : x - left pixel bits
;             : y - right pixel bits

; %0000       : star
; %0011       : brightest colour  (%11)
; %0100..%0110: fade brightest colour -> medium colour     (%11 -> %10)
; %0111       : medium colour     (%10)
; %1000..%1010: fade medium colour    -> darkest colour    (%10 -> %01)
; %1011       : darkest colour    (%01)
; %1100..%1110: fade darkest colour   -> background colour (%01 -> %00)
; %1101       : mix pattern background/darkest colour
; %1111       : background colour (%00)

BRIGHTEST  = %0011
MEDIUM     = %0111
DARKEST    = %1011
BACKGROUND = %1111
STAR       = %0000

BACKGROUNDCHAR = (BACKGROUND << 4) | BACKGROUND
STARCHARACTER  = (STAR << 4) | BACKGROUND

.macro SUB_SETUPSCREENMODE

				; achieve an initial stable raster point using the half variance method				
				;ldx #$00			
				jsr waitvblank
                
                .ASSERT (>stabilizeend) = (>stabilizestart), error, "flicker compensation timer setup page boundary crossing"

.ifdef NTSC_VERSION
stabilizestart: ldx VIC2_RASTERLINE
                beq stabilizestart
                ldy #$0a
:				dey
				bne :-
				nop
				inx
				cpx VIC2_RASTERLINE
				beq :+
				bit $00
				clc
:				iny
				sty VIC2_IMR
                ldy #$09
:				dey
				bne :-
				nop
				inx
				cpx VIC2_RASTERLINE
				beq :+
				bit $00
:               ldy #$0a
:				dey
				bne :-
				nop
				clc
				inx
				cpx VIC2_RASTERLINE
				bne :+
stabilizeend = *+$01

				; raster is stable here, so now start a continuous timer with 65 ticks (one raster line on NTSC) each loop
:               lda #$40
    			sta CIA1_TA_LO
.else

stabilizestart: ldx VIC2_RASTERLINE
                beq stabilizestart
                ldy #$0a
:				dey
				bne :-
				inx
				cpx VIC2_RASTERLINE
				beq :+
				bit $00
				clc
:				iny
				sty VIC2_IMR
                ldy #$09
:				dey
				bne :-
				inx
				cpx VIC2_RASTERLINE
				beq :+
				bit $00
:               ldy #$0a
:				dey
				bne :-
				clc
				inx
				cpx VIC2_RASTERLINE
				bne :+
stabilizeend = *+$01

				; raster is stable here, so now start a continuous timer with 63 ticks (one raster line on PAL) each loop
:               lda #$3e
    			sta CIA1_TA_LO
.endif; NTSC_VERSION
    			lda #$00
				sta CIA1_TA_HI
				lda #FORCE_LOAD | TIMER_START
				sta CIA1_CRA
				lda #~CIA_INTERRUPT; disable timer interrupts
				sta CIA1_ICR

                ; set up chunky mode
                lda #MULTICOLOUR_MODE | COLUMNS_25
                sta VIC2_CTRL2
				; setup raster interrupts
				lda #<irqhandler
				sta IRQ_VECTORLO
				lda #>irqhandler
				sta IRQ_VECTORHI
                lda #$19
                sta CHUNKY4COUNT
.endmacro

.macro SUB_GENCSET
                ; generate dithered chars for the chunky mode
                ;lda #<chunky4charset; $00
                ;sta POINTER+$00
                lda #>chunky4charset
                sta POINTER+$01
chunkycharloop: ldx #$00
:               txa
                and #%00000011
:               ora #$00
                and #%00001111
                tay
                lda dithering,y
                clc
chunkyleftcol = *+$01
                adc #%00001111; add brightness bits (%1111, %1010, %0101, %0000)
                cmp #%00010000
                bcc nostars
                ; start at colour pattern %00001111 + [1..5], so for the first char ($00, star) go here
                lda stardithering,y; y = [0..3]
nostars:        asl
                asl
                asl
                asl
                ora dithering,x
               ;clc
chunkyrightcol = *+$01
                adc #%00001111; add brightness bits (%1111, %1010, %0101, %0000)
                ldy #$00
                sta (POINTER+$00),y
                ldy #$04
                sta (POINTER+$00),y
                inc POINTER+$00
                lda #%00000011
                and POINTER+$00
                bne :+
                tya
                jsr addtopointer
:               inx
                cpx #$10
                bne :---                ; 4 shades, right pixel

                lda chunkyrightcol
               ;sec
                sbc #%00000101; next colour, go darker
                sta chunkyrightcol
                bcs chunkycharloop      ; 4 brightness levels, right pixel

                lda #%00001111
                sta chunkyrightcol
                lda :-- + $01
                ;clc
                adc #$04
                sta :-- + $01
                and #%00001111
                bne chunkycharloop      ; 4 shades, left pixel

                lda chunkyleftcol
               ;clc
                sbc #%00000101-1; next colour, go darker
                sta chunkyleftcol
                bcs chunkycharloop      ; 4 brightness levels, left pixel
.endmacro; SUB_GENCSET

.macro SUB_SCREEN
                ; advance screen pointer (POINTER+$02) to the next line
inclinepointer: ldy #POINTER+$02
                ; advance arbitrary pointer used as a screen pointer to the next line
                ; in: y - zp-based pointer address
inclinepntrex:  lda $01,y
                eor #> (chunky4screen0b ^ chunky4screen1b)
                sta $01,y
                cmp #> (chunky4screen1b-$0400)
inctextlineptr: lda $00,y
                bcs :+
                adc #$28
                SKIPBYTE
:               clc
                jmp zpput16bits
                                
                ; clear one of the chunky screens
                ; trashes a, x, y
clearscreen:    jsr clearscreendo
                lda SCREENPOINTER+$01
                clc
                adc #> (chunky4screen1b - chunky4screen0b - $0400)
clearscreendo:  sta SCREENPOINTER+$01
                lda #BACKGROUNDCHAR
                ldx #>$0400
                ; fall through
                
                ; set a range of memory to a certain value
                ; in: a - value to set the memory to
                ;     x - number of pages
                ;     SCREENPOINTER+$01 - page to begin with
setmem:         ldy #$00
                sty POINTER+$00
                sty SCREENPOINTER+$00
:               sta (SCREENPOINTER+$00),y
                iny
                bne :-
                inc SCREENPOINTER+$01
                dex
                bne :-
                rts

                ; set the brightest colours
setbrightest:   ldy CURRCOLOURSET
                lda coloursets+$00,y
                ldx #$00
:               sta VIC2_COLOURRAM+$0000,x
                sta VIC2_COLOURRAM+$0100,x
                inx
                bne :-
                lda coloursets+$05,y
:               sta VIC2_COLOURRAM+$01e0,x
                sta VIC2_COLOURRAM+$02e0,x
                sta VIC2_COLOURRAM+$02e8,x
                inx
                bne :-
                rts

				; wait for vertical blank
				; trashes x
waitvblank:     bit VIC2_CTRL1
				bpl waitvblank
:				ldx VIC2_RASTERLINE
				bne :-
				rts
.endmacro

.macro DAT_DITHERING
dithering:      .byte %00000101; 6 pixels set
                .byte %00000001
                .byte %00000101
                .byte %00000100

                .byte %00000100; 4 pixels set
                .byte %00000001
                .byte %00000100
                .byte %00000001

                .byte %00000000; 2 pixels set
                .byte %00000001
                .byte %00000000
                .byte %00000100

                .byte %00000000; 0 pixels set
stardithering:  .byte %00000000
                .byte %00000000
                .byte %00000000

                .byte %00001000; star
.endmacro; DAT_DITHERING

.macro DAT_COLOURS
coloursets:     ; order: 
                ;        bottom video ram colour,
                ;        top multicolour 1
                ;        top multicolour 0,
                ;        top background colour,
                ;        border colour,
                ;        top video ram colour,
                ;        bottom background colour,
                ;        bottom multicolour 1,
                ;        bottom multicolour 0
colourset0:     .byte $08 | COLOUR_GREEN, COLOUR_YELLOW, COLOUR_CYAN, COLOUR_BLUE, COLOUR_BLUE, $08 | COLOUR_GREEN, COLOUR_BLUE, COLOUR_YELLOW, COLOUR_CYAN
colourset1 = *-$02
                .byte COLOUR_BLACK, COLOUR_BLACK, COLOUR_GREEN, COLOUR_YELLOW, COLOUR_BLACK
colourset2:     .byte $08 | COLOUR_WHITE, COLOUR_YELLOW, COLOUR_CYAN, COLOUR_LIGHTBLUE, COLOUR_PURPLE, $08 | COLOUR_GREEN, COLOUR_BLUE, COLOUR_ORANGE, COLOUR_BROWN

altcolours:     
                .byte $08 | COLOUR_YELLOW, COLOUR_CYAN, COLOUR_LIGHTBLUE, COLOUR_BLUE, COLOUR_BLACK, $08 | COLOUR_YELLOW, COLOUR_BLUE, COLOUR_CYAN, COLOUR_LIGHTBLUE
                .byte $08 | COLOUR_WHITE, COLOUR_BLACK, COLOUR_BLUE, COLOUR_YELLOW, COLOUR_BLACK
                .byte $08 | COLOUR_YELLOW, COLOUR_CYAN, COLOUR_LIGHTBLUE, COLOUR_BLUE, COLOUR_BLACK, $08 | COLOUR_YELLOW, COLOUR_BLUE, COLOUR_CYAN, COLOUR_LIGHTBLUE

.endmacro; DAT_COLOURS

.segment "FONT"
font:
.segment "CHUNKY4CHARSET"
chunky4charset:
.segment "CHUNKY4SCREEN0A"
chunky4screen0a:
.segment "CHUNKY4SCREEN1A"
chunky4screen1a:
.segment "CHUNKY4SCREEN0B"
chunky4screen0b:
.segment "CHUNKY4SCREEN1B"
chunky4screen1b: