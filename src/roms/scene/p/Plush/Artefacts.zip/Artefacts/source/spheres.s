
.define SPHEREMAXDIAMETER 64

.macro SUB_GENSPHERECODE

                ; generate planet scene unrolled sphere render code

                lda #<spherelineoffs+$80
                sta POINTER+$02
                lda #>spherelineoffs+$00
                sta POINTER+$01
                sta POINTER+$03
                ; build offset table for sphere unrolled code
                lda #$0c
                ldy #<spherelineoffs+$00; $00
                sty POINTER+$00
                jsr buildslopetb16
                ; build offset table for screen starting position
                lda #$28
                ldy #$40
                jsr buildslopetb16

                ;lda #<sphererendercode; $00
                ;sta POINTER+$00
                lda #>sphererendercode
                sta POINTER+$01
                
                ; put code for every sphere scan line width
                ldx #$02; scan line width and x-position oddness
genspherecode:  ; xreg & $01: even or odd x-position on screen
                ; xreg & $fe: width on screen                
                lda POINTER+$00
                sta spherecodeoffs+$00,x
                lda POINTER+$01
                sta spherecodeoffs+$80,x
                stx BUFFER+$00
                lsr BUFFER+$00; mask width
                asl BUFFER+$00
                lda #SPHEREMAXDIAMETER
                jsr divu_80_80_88
                lda #SPHEREMAXDIAMETER
                sec
                sbc BUFFER+$00
                lsr
                lsr
                tay
                txa
                pha
                and #%00000001
                beq :++
                bcc :+
                iny
:               lsr
:               sta BUFFER+$01; $00
                sta BUFFER+$02; $00
                sec
genspherexloop: sty CODEMODIFIER0
                ldy BUFFER+$02
                lda spheremappingtable,y
                sta CODEMODIFIER1
                bcc gensphrnotrite
                lda CODEMODIFIER0
                sta spherexleftoffs,x
                inx
                txa
                and #%00000010
                bne :+

gensphrnotrite: ldx BUFFER+$00
                dex
                bne gensphrnotleft
                ; line ends at an odd x-position
                ldx #sphereleftpxle-codefragments
                SKIPWORD
                ; line starts at an odd x-position
:               ldx #sphererightpxe-codefragments
                ldy #sphereleftpxle-sphereleftpixl
                jsr putcodepiece
                bne gensphrnextlin

                ; set the two pixels in a byte
gensphrnotleft: dec BUFFER+$00
                jsr inctxtroffset
                tay
                lda spheremappingtable,y
                sta CODEMODIFIER2
                ldx #sphere2pixelse-codefragments
                ldy #sphere2pixelse-sphere2pixels
                jsr putcodepiece
                
gensphrnextlin: jsr inctxtroffset
                ldy CODEMODIFIER0
                iny
                dec BUFFER+$00
                bne genspherexloop

                pla
                tax
                tya
                sta SPHEREXRIGHTOFFS,x
                inx
                cpx #(SPHEREMAXDIAMETER+$02) | $01; odd and even x-positions
                bne genspherecode

.endmacro; SUB_GENSPHERECODE

.macro SUB_SPHEREGENZOOMTABLE

                ; generate sphere zoom tables
genspherezoomt: lda #<spherezoomtable
                sta POINTER+$00
                lda #>spherezoomtable
                sta POINTER+$01
               ;ldx #$00
:               jsr getsine
               ;ldx #$ff
                inx; check first quarter period
:               lda BUFFER+$04; radius, set by getsine
                clc
                adc sincostable+$00,x; sine, y-position
                tay
                lda sincostable+$40,x; cosine, x-position
                asl
                sta (POINTER+$00),y
                lda BUFFER+$04; radius, set by getsine
               ;clc
                sbc sincostable+$00,x
                tay
                lda sincostable+$40,x
                asl
                sta (POINTER+$00),y
                inx
                cpx #$40
                bne :-
                lda #$80
                jsr addtopointer
                ldx BUFFER+$04; radius, set by getsine
                inx
                cpx #(SPHEREMAXDIAMETER/$02)+$01
                bne :--
                lda #$02
                sta spherezoomtable+$80; radius = 1, not covered by the algorithm
                sta spherezoomtable+$81
                
.endmacro; SUB_SPHEREGENZOOMTABLE

.macro SUB_DRAWTEXTURESPHERE
                ; draw a texture-mapped sphere
                ; in: a - x-position
                ;     x - radius
                ;     y - y-position
                ;     c - 0: planet, 1: drone (smaller texture, no texture wrap at equator)
                ;     BUFFER+$00 - texture address hi
drawtxtrsphere: stx POINTER+$00; radius
                sty POINTER+$01
                ldy #$00
                sty BUFFER+$01; line pos lo
                sty BUFFER+$02; line pos hi
                php
                cmp #$80
                ror
                sta BUFFER+$05; x position / 2
                bpl :+
                dey
:               sty BUFFER+$09
                lda #$00
                sta getlinewidth+$01
                adc #$00
                sta BUFFER+$03
                lda POINTER+$00
                lsr
                ror getlinewidth+$01
                adc #>spherezoomtable
                sta getlinewidth+$02

                ; calculate texture y-direction walk-through step
                lda #(SPHEREMAXDIAMETER >> 1) - 1
                plp
                bcc :+
                ; the drone texture is just 1 line high
                lda #$00
:               ldx POINTER+$00; radius
                jsr divu_80_80_88

                lda POINTER+$01; y position
                sec
                sbc POINTER+$00; radius
                sta POINTER+$04; screen y position
                lsr
                tax
                php

                lda SCREENPOINTER+$01
                sec
                sbc #>$0400
                plp
                bcs :+
                eor #>(chunky4screen0b ^ chunky4screen1b)
:               eor spherelineoffs+$c0,x
                sta POINTER+$03
                lda spherelineoffs+$40,x
                eor #$03
                clc
                adc BUFFER+$05; x position / 2
                sta POINTER+$02
                lda POINTER+$03
                adc BUFFER+$09
                sta POINTER+$03
                lda #$00
                sta BUFFER+$04
                sec
                sbc BUFFER+$05; x position / 2
                bmi :+
                sta BUFFER+$04
:               clc
                adc #$24
                sta BUFFER+$05

                lda POINTER+$00
                clc
                adc POINTER+$01
                cmp #$32
                bcc :+ 
                ; clip at bottom
                lda #$31
                sec
:               sbc POINTER+$04; screen y position
                sta BUFFER+$06; lines to draw
                
                lda SPHERETXTROFFS; texture scroll offset
                and #%01111111
                sta POINTER+$00; left pixels lo
                sta POINTER+$04; right pixels lo

                lda #$00
spherelineloop: clc
                adc BUFFER+$00
                sta POINTER+$01
                adc #$01
                sta POINTER+$05

                lda BUFFER+$03
getlinewidth:   ora a:$00; get linewidth
                tax

                ; clip left
                lda BUFFER+$04
                sec
                sbc spherexleftoffs,x
                tay
                bcs :+
                ldy #$00; no clipping
:               lda spherecodeoffs+$00,x
                clc
                adc spherelineoffs+$00,y
                sta spherejsrline+$01
                lda spherecodeoffs+$80,x
                adc spherelineoffs+$80,y
                sta spherejsrline+$02

                ; clip right
                lda SPHEREXRIGHTOFFS,x
                sec
                sbc BUFFER+$05
                tay
                bcs :+
                ldy #$01
:               lda spherecodeoffs+$01,x
                sec
                sbc spherelineoffs+$00,y
                sta POINTER+$06
                lda spherecodeoffs+$81,x
                sbc spherelineoffs+$80,y
                sta POINTER+$07

                ldy #$0c
                lda (POINTER+$06),Y
                tax
                lda #OPC_RTS
                sta (POINTER+$06),y
                lda (POINTER+$02),Y
spherejsrline:  jsr $00
                txa
                ldy #$0c
                sta (POINTER+$06),y

                ; advance screen pointer to the next line
                jsr inclinepointer

                ; increase line number
                jsr inctxtroffset
                and #%00011111; texture wrap at equator
                asl

                inc getlinewidth+$01
                dec BUFFER+$06
                bpl spherelineloop
                ; fall through

                ; add 16-bit value to texture offset
inctxtroffset:  lda RESULT+$00
                clc
                adc BUFFER+$01
                sta BUFFER+$01
                lda RESULT+$01
                adc BUFFER+$02
                sta BUFFER+$02
                rts
                
.endmacro; SUB_DRAWTEXTURESPHERE

.macro PLANETSCENE
                SUB_GENSPHERECODE
                SUB_TEXTUREGENDRONETEXTURE; texgen.s
                SUB_SPHEREGENZOOMTABLE

                clc
                lda #$20; size
                ldx #>(sphereplanettexture+$2000)
                ldy #>(sphereplanettexture+$4100)
                jsr texgen
                
                ldx #$01
                ldy #colourset0-coloursets
                jsr stopinterlude
                stx FRAMECOUNTER+$01

                lda #>chunky4screen0a

planetscnloop:  sta CHUNKY4BACKBUFF
                sta POINTER+$01
                jsr clearscreen

                ; draw stars
                lda #<(chunky4screen0b+$28+$03)
                sta POINTER+$00
                ldx getrandom+$01
:               lda Artefacts+$0653,x
:               tay
                sec
                sbc #$25
                bcs :-
                lda #STARCHARACTER
                sta (POINTER+$00),y
                ldy #POINTER
                jsr inclinepntrex
                inx
                cmp #<(chunky4screen0b+($19*$28)+$03)
                bne :--
                
                ; draw planet
                lda #>sphereplanettexture
                sta BUFFER+$00

                clc
                lda #$12; sphere's x-position
                ldx #SPHEREMAXDIAMETER >> 1; sphere's size on screen (radius)
                ldy #$24; sphere's y-position
                jsr drawtxtrsphere

                lda #>spheredronetexture
                sta BUFFER+$00                
                lda #enterdrone-tracks
                cmp TRACKPOS+$0e
                bcs nodrone
                ; draw drone

                lda FRAMECOUNTER+$01
               ;clc
                sbc #$dc-1
                pha
                tax
                lda #$01
                jsr divu_80_80_88
                lsr
                tax; sphere's radius
                bne :+
                inx
:
                pla
                lsr
                lsr
                pha
                lsr
                lsr
                eor #$ff
                clc
                adc #$30
                tay; sphere's y-position
                pla
                clc
                adc #$dc
                ; sphere's x-position
                sec
                jsr drawtxtrsphere

nodrone:        lda CURRCHUNKY4ADDR
                eor #< (((chunky4screen0b ^ chunky4screen0a) & $3fff) >> 6)
                sta CURRCHUNKY4ADDR
planetnextfram: 
                .ASSERT chunky4screen0b + chunky4screen1a = chunky4screen0a + chunky4screen1b, error, "CHUNKY4SCREEN0A + CHUNKY4SCREEN1B != CHUNKY4SCREEN0B + CHUNKY4SCREEN1A."

                inc SPHERETXTROFFS
                lda #>(chunky4screen0b + chunky4screen1a + $0400)
                sec
                sbc SCREENPOINTER+$01
                ldx #planetsceneend-tracks
                cpx TRACKPOS+$0e
                bcs planetscnloop
                
.endmacro; PLANETSCENE

.macro FRG_SPHERECODE

                ; put right pixel
sphererightpxl: ldy #CODEMODIFIER0; $00-$24
                lda (POINTER+$02),y
                and #%11110000
                ldy #CODEMODIFIER1; texture offset according to mapping, $00-$ff
                ora (POINTER+$04),y; 0000xxxx
                ldy #CODEMODIFIER0; $00-$24
                sta (POINTER+$02),y
sphererightpxe:

                ; put left pixel
sphereleftpixl: ldy #CODEMODIFIER0; $00-$24
                lda (POINTER+$02),y
                and #%00001111
                ldy #CODEMODIFIER1; texture offset according to mapping, $00-$ff
                ora (POINTER+$00),y; xxxx0000
                ldy #CODEMODIFIER0; $00-$24
                sta (POINTER+$02),y
sphereleftpxle:

                ; put two pixels, left and right
sphere2pixels:  ldy #CODEMODIFIER1; texture offset according to mapping, $00-$ff
                lda (POINTER+$00),y; xxxx0000
                ldy #CODEMODIFIER2; texture offset according to mapping, $00-$ff
                ora (POINTER+$04),y; 0000xxxx
                ldy #CODEMODIFIER0; $00-$24
                sta (POINTER+$02),y
sphere2pixelse:

.endmacro; FRG_SPHERECODE

.macro DAT_SPHEREMAPPINGTABLE
spheremappingtable = tables+$0100
.endmacro

.segment "SPHERERENDERCODE"
sphererendercode:
.segment "SPHEREZOOMTABLE"
spherezoomtable:
.segment "SPHEREDRONETEXTURE"
spheredronetexture:
.segment "SPHEREPLANETTEXTURE"
sphereplanettexture:
.segment "SPHERETXTRADDTABLE"
spheretxtraddtable:
.segment "SPHERECODEOFFS"
spherecodeoffs:
.segment "SPHEREXLEFTOFFS"
spherexleftoffs:
.segment "SPHERELINEOFFS"
spherelineoffs:
