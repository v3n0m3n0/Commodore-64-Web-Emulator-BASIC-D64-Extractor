
                ; texture generator producing a stripes pattern
                ; to produce a drone texture
.macro SUB_TEXTUREGENDRONETEXTURE

                ; generate drone texture
                ldx #$00
:               txa
                lsr
                lsr
                lsr
                lsr
                bcc :+
                lda #(DARKEST-$02) << 4
                SKIPWORD
:               lda #(BRIGHTEST+$01) << 4
                sta spheredronetexture+$0000,x
                lsr
                lsr
                lsr
                lsr
                sta spheredronetexture+$0100,x
                inx
                bne :--

.endmacro; SUB_TEXTUREGENDRONETEXTURE

.macro SUB_TEXTUREGENERATOR
                ; texture generator using perlin noise on recursive square subdivision
                ; to generate sky and ground textures
                ; texture size is fixed to 64 pixels
                ; in: x - last memory page to expand the texture to (iterates backward)
                ;     y - last memory page to generate the texture to

texgen64skygnd: lda #OVERFLOW; carry clear and overflow set
                pha
                plp
                ; fall through

                ; texture generator using perlin noise on recursive square subdivision
                ; texture size is fixed to 64 pixels
                ; in: c - clear: convert for a texture, set: convert for the voxelmap
                ;     v - (if c clear) clear: texture width is 128 pixels, set: texture width equals 64
                ;     x - last memory page to expand the texture to (iterates backward)
                ;     y - last memory page to generate the texture to
                
texgen64:       lda #$40
                ; fall through
                
                ; texture generator using perlin noise on recursive square subdivision
                ; in: c - clear: convert for a texture, set: convert for the voxelmap
                ;     v - (if c clear) clear: texture width is 128 pixels, set: texture width equals the size denoted in the accumulator
                ;     a - texture size
                ;     x - last memory page to expand the texture to (iterates backward)
                ;     y - last memory page to generate the texture to
texgen:         sta BUFFER+$05
                stx BUFFER+$06
                sty POINTER+$03
                tax
                php
                lda #%01111111
                bvc :+
                lsr
:               sta RECSUBWIDTHWRAP
                lda BUFFER+$06
                sec
                sbc BUFFER+$05
                sta SCREENPOINTER+$01
                lda #$00
                sta POINTER+$02
                jsr setmem; clear texture memory area
               ;lda #$00
:               pha; x-position
                tay
                lda BUFFER+$05; size
                jsr rsdpgensquare
                pla
                plp
                bvs texgenconvtxtr
                php
                clc
                adc BUFFER+$05; add size
                bpl :-
                plp
                
                ; convert texture or voxelmap for display
                ; in: c - clear: convert for a texture, set: convert for the voxelmap
                ;     v - (if c clear) clear: texture width is 128 pixels, set: texture width equals the size denoted in the accumulator
                ;     BUFFER+$05 - texture size
                ;     BUFFER+$06 - last memory page to generate the texture to (iterates backwarD)
                ;     POINTER+$03 - last memory page to convert the texture to (iterates backward)
texgenconvtxtr: lda BUFFER+$06
                sta POINTER+$01
               ;lda #$00
               ;sta POINTER+$00
               ;sta POINTER+$02
                ldy POINTER+$03
convertloop:    sty POINTER+$03
                sty POINTER+$05
                ldy RECSUBWIDTHWRAP
                sty POINTER+$04
                inc POINTER+$04
convpixelloop:  lda (POINTER+$00),y
                php; carry - clear: convert for a texture, set: convert for the voxelmap
                bcs voxelconvert
                
                lsr
                lsr
                lsr
                lsr
                cmp #BRIGHTEST
                bcs :+; clip colour value
                lda #BRIGHTEST
                bcc :+; jmp

voxelconvert:   lsr; value range is $00..$ff, but we want $00..$7f for the voxelmap
:               sta (POINTER+$02),y
                sta (POINTER+$04),y
                asl
                asl
                asl
                asl
                plp
                php
                bvc :+
                pha
                tya
                eor #$80
                tay
                pla
                sta (POINTER+$02),y
                sta (POINTER+$04),y
                tya
                eor #$80
                tay
                bcc :++; jmp

:               dec POINTER+$03
                dec POINTER+$05
                sta (POINTER+$02),y; will trash the memory page before the converted texture
                sta (POINTER+$04),y
                inc POINTER+$03
                inc POINTER+$05

:               plp
                dey
                bpl convpixelloop

                dec POINTER+$01
                ldy POINTER+$03
                dey ; the voxel map has continuous bytes (values 0..127) in ascending memory pages
                bcs :+
                bvs :+
                dey ; textures have lo- and hinibbled pixels in alternating memory pages

:               dec BUFFER+$05
                bpl convertloop
                rts

rsdpgensquare:  pha              ; size
                pha
                lda BUFFER+$06
                sec
                sbc BUFFER+$05
                sta POINTER+$04
                sta POINTER+$01
                jsr rsdpset3pixels
                pla
                lsr
                adc POINTER+$04
                sta POINTER+$01
                jsr rsdpset3pixels

                lda POINTER+$04  ; y-coordinate
                pha
                tya              ; x-coordinate
                pha
                tsx
                bne rsdpdorecurse; jmp

                ; recursive subroutine
rsdprecurse:    ; buffer parameters on the stack
                pha; size
                txa
                pha; y-coordinate
                tya
                pha; x-coordinate                
                stx POINTER+$01
                tsx
                
                lda STACK+$03,x; get size from the stack
                sta BUFFER+$01
                lda #$01
:               sec
                rol
                lsr BUFFER+$01
                bne :-
                pha; random value range

                ; average already-set pixels, top left and top right
                jsr rsdpavrgehoriz
                sta BUFFER+$01

                ; average already-set pixels, top left and bottom left
                ldy STACK+$01,x; get x-coordinate from the stack
                jsr rsdpavrgeverti
                sta BUFFER+$02

                ; average already-set pixels, bottom left and bottom right
                lda STACK+$02,x; get y-coordinate from the stack
                clc
                adc STACK+$03,x; add size                
                cmp BUFFER+$06
                bne :+
                lda POINTER+$04
:               sta POINTER+$01
                jsr rsdpavrgehoriz
                sta BUFFER+$03
                
                ; average already-set pixels, top right and bottom right
                lda STACK+$02,x; get y-coordinate from the stack
                sta POINTER+$01
                lda STACK+$01,x; get x-coordinate from the stack
                clc
                adc STACK+$03,x; get size from the stack
                asl
                lsr
                tay
                jsr rsdpavrgeverti
                sta BUFFER+$04

                lda STACK+$03,x; get size
                lsr
                clc
                adc STACK+$01,x; add x-coordinate
                tay
                lda (POINTER+$00),y
                bne :+
                ; average newly-set middle pixels
                lda BUFFER+$04
                ;clc
                adc BUFFER+$03
                ror
                adc BUFFER+$02
                ror
                adc BUFFER+$01
                ror
                ; put middle pixel
                sta (POINTER+$00),y
:               pla; remove random value range from the stack

                ; recursive steps
rsdpdorecurse:  lda STACK+$03,x; get size
                lsr            ; half the size for the next recursive step
                bne :+; break condition
                pla
                pla
                pla
                clc
                rts

                ; top left
:               pha
                ldy STACK+$01,x; x-coordinate
                lda STACK+$02,x; y-coordinate
                tax
                pla; size
                pha
                jsr rsdprecurse

                ; bottom left
                tsx
                pla            ; get size
                pha
                ldy STACK+$02,x; x-coordinate
                ;clc
                adc STACK+$03,x; y-coordinate
                tax
                pla; size
                pha
                jsr rsdprecurse

                ; top right
                tsx
                pla            ; get size
                pha            
                ;clc
                adc STACK+$02,x; add x-coordinate
                tay
                lda STACK+$03,x; y-coordinate
                tax
                pla; size
                pha
                jsr rsdprecurse

                ; bottom right                
                pla; size
                sta BUFFER+$00
                pla; x-coordinate
                ;clc
                adc BUFFER+$00 ; add size
                tay
                pla; y-coordinate
                ;clc
                adc BUFFER+$00 ; add size
                tax
                pla
                lsr; size
                jmp rsdprecurse

rsdpavrgehoriz: lda (POINTER+$00),y
                pha
                tya
                clc
                adc STACK+$03,x; get size from the stack
                and RECSUBWIDTHWRAP
                tay
                pla
                jsr rsdpaveragesub
                ; set new pixel on horizontal middle
                pha                
                lda STACK+$03,x; get size from the stack
                lsr
                clc
                adc STACK+$01,x; add x-position to half the size
                tay
                bcc rsdpsetpixel

rsdpavrgeverti: lda (POINTER+$00),y
                pha
                lda STACK+$03,x; get size from the stack
                clc
                adc POINTER+$01
                cmp BUFFER+$06
                bne :+
                lda POINTER+$04
:               sta POINTER+$01
                pla
                jsr rsdpaveragesub
                ; set new pixel at left vertical middle
                pha
                lda STACK+$03,x; get size from the stack
                lsr
                clc
                adc STACK+$02,x; add half the size to the line pointer hi-byte
                sta POINTER+$01
                pla
                pha
rsdpsetpixel:   lda (POINTER+$00),y
                cmp #$01
                pla                
                bcc :+; check whether pixel is already set
                rts
:               sta (POINTER+$00),y
                rts

rsdpaveragesub: adc (POINTER+$00),y
                ror
                ; add a random value to the average
                sta BUFFER+$00
                jsr getrandom
                and STACK+$00,x; random value range
                adc BUFFER+$00
                bcc :+
                lda #$ff; saturated
:               rts

rsdpset3pixels: tya
                tax
                jsr :+
                clc                
                adc #$10
                jsr :+
               ;clc
                adc #$20
:               tay
                jsr getrandom; a = [$00..$ff]
                jsr rsdpsetpixel-$01
                txa
                tay
                rts

.endmacro; SUB_TEXTUREGENERATOR