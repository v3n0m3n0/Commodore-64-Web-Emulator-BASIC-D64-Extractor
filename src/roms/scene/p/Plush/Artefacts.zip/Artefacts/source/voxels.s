
VOXELPREPSKY = voxelrendercode+(voxeldoublbpre-voxeldoublebpr)+($0c*(voxeldoublebfe-voxeldoublebuf))+($0d*(voxeldoublebfe-voxeldoublebuf))+(skyprepareend-skyprepare)+($18*(voxnskyselfmde-voxnskyselfmod))+(voxelpreparend-voxelprepare)+($1a*(voxnskyselfmde-voxnskyselfmod))+6 ; 6 because of 3 times inx:iny

SKYRENDERCODE = VOXELPREPSKY+(voxelprepskyend-voxelprepsky)
SKYPARAMSDEST0 = SKYRENDERCODE+(voxelskytexel0-voxelputsky)
SKYPARAMSDEST1 = SKYRENDERCODE+(voxelskytexel1-voxelputsky)
SKYPUTBYTE0 = SKYRENDERCODE+(voxelputskybyt-voxelputsky)
SKYPUTBYTE1 = SKYPUTBYTE0+(voxelputskyend-voxelputsky)

VOXELRENDERCODE = SKYRENDERCODE+(24*(voxelputskyend-voxelputsky))
VOXELPARAMSDEST0 = VOXELRENDERCODE+(voxelmaptexel0-voxelcalcscape)
VOXELPARAMSDEST1 = VOXELRENDERCODE+(voxelmaptexel1-voxelcalcscape)
VOXELPUTBYTE0 = VOXELRENDERCODE+($1a*(voxelcalcscend-voxelcalcscape))+(voxelputpreped-voxelputprep)+(voxelputbyte-voxelput2pixls)
VOXELPUTBYTE1 = VOXELPUTBYTE0+(voxelput2pxled-voxelput2pixls)


.macro SURFACESCENE

                lda interludespeed
                jsr startinterlude

                ; create voxelmap
                sec
                ldx #>(voxelmap+$3f00)
                ldy #>(voxelmap+$4000)
                jsr texgen64
                
                ; create sky texture
                ldx #>(voxelskytexture+$4000)
                ldy #>(voxelskytexture+$4000)
                jsr texgen64skygnd
                
                ; generate preparation code
                lda #<voxelrendercode
                sta POINTER+$00
                lda #>voxelrendercode
                sta POINTER+$01

                ; double buffering page flip
                lda #>SKYPUTBYTE0
                sta CODEMODIFIER1
                sta CODEMODIFIER3
                lda #<(chunky4screen0b+$03)
                sta POINTER+$03
                lda #<SKYPUTBYTE0
                sta CODEMODIFIER0
                lda #<SKYPUTBYTE1
                sta CODEMODIFIER2
                ldx #voxeldoublbpre-codefragments
                ldy #voxeldoublbpre-voxeldoublebpr
                jsr putcodepiece
                ldx #$0c
:               txs
                ldx #voxeldoublebfe-codefragments
                ldy #voxeldoublebfe-voxeldoublebuf
                jsr putcodepiece
                ldy #CODEMODIFIER0
                lda #(voxelputskyend-voxelputsky)*2
                jsr zpadd8to16bits
                lda #(voxelputskyend-voxelputsky)*2
                jsr zpadd8to16bits
                lda POINTER+$03
                clc
                adc #$28
                sta POINTER+$03
                bcc :+
                ldx #voxeldoublebwe-codefragments
                ldy #voxeldoublebwe-voxeldoublebwr
                jsr putcodepiece                
:               tsx
                dex
                bne :--

                lda #>VOXELPUTBYTE0
                sta CODEMODIFIER1
                sta CODEMODIFIER3                
                lda #<VOXELPUTBYTE0
                sta CODEMODIFIER0
                lda #<VOXELPUTBYTE1
                sta CODEMODIFIER2
                ldx #$0d
:               txs
                ldx #voxeldoublebfe-codefragments
                ldy #voxeldoublebfe-voxeldoublebuf
                jsr putcodepiece
                ldy #CODEMODIFIER0
                lda #(voxelput2pxled-voxelput2pixls)*2
                jsr zpadd8to16bits
                lda #(voxelput2pxled-voxelput2pixls)*2
                jsr zpadd8to16bits
                lda POINTER+$03
                clc
                adc #$28
                sta POINTER+$03
                bcc :+
                ldx #voxeldoublebwe-codefragments
                ldy #voxeldoublebwe-voxeldoublebwr
                jsr putcodepiece
:               tsx
                dex
                bne :--

                ; sky preparation                
                ldx #skyprepareend-codefragments
                ldy #skyprepareend-skyprepare
                jsr putcodepiece                

                lda #<(SKYPARAMSDEST0+$00)
                sta CODEMODIFIER0
                lda #<(SKYPARAMSDEST0+$01)
                sta CODEMODIFIER2
                lda #>(SKYPARAMSDEST0+$00)
                sta CODEMODIFIER1
                sta CODEMODIFIER3
                lda #<(SKYPARAMSDEST1+$00)
                sta CODEMODIFIER4
                lda #<(SKYPARAMSDEST1+$01)
                sta CODEMODIFIER6
                lda #>(SKYPARAMSDEST1+$00)
                sta CODEMODIFIER5
                sta CODEMODIFIER7
                lda #$01
                sta CODEMODIFIER8
                lda #>(voxelskytexture+(64*64*2*2))
                sta CODEMODIFIER9
                ldx #$18
:               txs
                ldx #voxnskyselfmde-codefragments
                ldy #voxnskyselfmde-voxnskyselfmod
                jsr putcodepiece
                ldy #CODEMODIFIER0
                lda #voxelputskyend-voxelputsky
                jsr zpadd8to16bits
                lda #voxelputskyend-voxelputsky
                jsr zpadd8to16bits
                lda #voxelputskyend-voxelputsky
                jsr zpadd8to16bits
                lda #voxelputskyend-voxelputsky
                jsr zpadd8to16bits
                tsx
                lda perspectiveytable-$02,x
                sta CODEMODIFIER8
                dex
                bne :-
      
                ; voxel preparation
                ldx #voxelpreparend-codefragments
                ldy #voxelpreparend-voxelprepare
                jsr putcodepiece                

                lda #<(VOXELPARAMSDEST0+$00)
                sta CODEMODIFIER0
                lda #<(VOXELPARAMSDEST0+$01)
                sta CODEMODIFIER2
                lda #>(VOXELPARAMSDEST0+$00)
                sta CODEMODIFIER1
                sta CODEMODIFIER3
                lda #<(VOXELPARAMSDEST1+$00)
                sta CODEMODIFIER4
                lda #<(VOXELPARAMSDEST1+$01)
                sta CODEMODIFIER6
                lda #>(VOXELPARAMSDEST1+$00)
                sta CODEMODIFIER5
                sta CODEMODIFIER7
                lda #$01
                sta CODEMODIFIER8
                lda #>(voxelmap+(128*64*2))
                sta CODEMODIFIER9
                ldx #$1a
:               txs
                ldx #voxnskyselfmde-codefragments
                ldy #voxnskyselfmde-voxnskyselfmod
                jsr putcodepiece
                ldy #CODEMODIFIER0
                lda #voxelcalcscend-voxelcalcscape
                jsr zpadd8to16bits
                lda #voxelcalcscend-voxelcalcscape
                jsr zpadd8to16bits
                lda #voxelcalcscend-voxelcalcscape
                jsr zpadd8to16bits
                lda #voxelcalcscend-voxelcalcscape
                jsr zpadd8to16bits
                tsx
                lda perspectiveytable-$02,x
                sta CODEMODIFIER8
                dex
                bne :-
                ; sky render code
                ldx #voxelprepskyend-codefragments
                ldy #voxelprepskyend-voxelprepsky
                jsr putcodepiece
                lda #<(voxelskyperspx+$00)
                sta CODEMODIFIER0
                lda #<(voxelskyperspx+$25)
                sta CODEMODIFIER2
                lda #>(voxelskyperspx+$00)
                sta CODEMODIFIER1
                sta CODEMODIFIER3
                lda #<(chunky4screen0b+$03)
                sta CODEMODIFIER4
                lda #>(chunky4screen0b+$03)
                sta CODEMODIFIER5
                ldx #$18
:               txs
                ldx #voxelputskyend-codefragments
                ldy #voxelputskyend-voxelputsky
                jsr putcodepiece                
                ldy #CODEMODIFIER0
                jsr zpadd74
                jsr zpadd74
                jsr inclinepntrex
                tsx
                dex
                bne :-

                ; voxel render code
                lda #<(voxelperspectivex+$00)
                sta CODEMODIFIER0
                lda #<(voxelperspectivex+$25)
                sta CODEMODIFIER2
                lda #>(voxelperspectivex+$00)
                sta CODEMODIFIER1
                sta CODEMODIFIER3
                lda #<voxelperspectivey
                sta CODEMODIFIER6
                lda #>voxelperspectivey
                sta CODEMODIFIER7
                lda #<(voxelcolourtable0+$80)
                sta CODEMODIFIER8
                ldx #$1a
:               txs
                ldx #voxelcalcscend-codefragments
                ldy #voxelcalcscend-voxelcalcscape
                jsr putcodepiece
                ldy #CODEMODIFIER0
                jsr zpadd74
                jsr zpadd74
                iny
                iny
                lda #$80
                jsr zpadd8to16bits
                dec CODEMODIFIER8
                dec CODEMODIFIER8
                tsx
                dex
                bne :-

                ldx #voxelputpreped-codefragments
                ldy #voxelputpreped-voxelputprep
                jsr putcodepiece
                
                lda #VOXELFILLTAB
                sta CODEMODIFIER0
                ldx #$1a
:               txs
                ldx #voxelput2pxled-codefragments
                ldy #voxelput2pxled-voxelput2pixls
                jsr putcodepiece
                inc CODEMODIFIER0
                ldy #CODEMODIFIER4
                jsr inclinepntrex
                tsx
                dex
                bne :-

                ldx #voxelrenderjle-codefragments
                ldy #voxelrenderjle-voxelrenderjmp
                jsr putcodepiece

                ; calculate voxel x-perspective table
                ldx #>voxelperspectivex
                ldy #$7f
                jsr calcperspxtabl

                ; calculate sky x-perspective table
                ldx #>voxelskyperspx
                ldy #$3f
                jsr calcperspxtabl

                ; build voxel y-perspective table
                lda #<voxelperspectivey
                sta POINTER+$00
                lda #>voxelperspectivey
                sta POINTER+$01
                lda #$40
                sta BUFFER+$00
                ldx #$19
genypersptable: stx POINTER+$03
                lda #$00
                sta POINTER+$02
                ldy #$80
:               lda POINTER+$03
                sta (POINTER+$00),y
                tya
                pha
                lda BUFFER+$00
                ldy #POINTER+$02
                jsr zpadd8to16bits
                pla
                tay
                dey
                bpl :-
                lda #$80
                jsr addtopointer
                dec BUFFER+$00
                dec BUFFER+$00
                dex
                bpl genypersptable

                ; build voxelheight to colour tables
                ldx #$00
gencolourtabls: txa
                asl
                bcc :++
                eor #%11111111
               ;sec
                adc #(BRIGHTEST-2) << 4
                bcc :+
                lda #%11111111
:               and #%11110000
                cmp #BRIGHTEST << 4
                bcs :++
                lda #BRIGHTEST << 4
                SKIPWORD
:               lda #BACKGROUND << 4
:               sta voxelcolourtable0,x
                lsr
                lsr
                lsr
                lsr
                sta voxelcolourtable1,x
                inx
                bne gencolourtabls

                ldx #$48
                jsr getsine; x move sine
                
                ldx #entersurface-tracks
                ldy #colourset2-coloursets
                jsr stopinterlude
                
voxelloop:      ldx BUFFER+$00
                lda sincostable,x
                adc #$34
                sta VOXELXPOSITION
                inc BUFFER+$00
                inc BUFFER+$00
                jmp voxelrendercode
aftvoxelrender: lda CURRCHUNKY4ADDR
                eor #<(((chunky4screen0b ^ chunky4screen0a) & $3fff) >> 6)
                sta CURRCHUNKY4ADDR
                ldx #surfacescenend-tracks
                cpx TRACKPOS+$0e
                bcs voxelloop

.endmacro; SURFACESCENE

.macro FRG_VOXELCODE

voxeldoublebpr: ; 1 time
                lda CODEMODIFIER0 | (CODEMODIFIER1 << 8)
                eor #>(chunky4screen0b ^ chunky4screen0a)
                tax
                eor #>(chunky4screen0b ^ chunky4screen1b)
                tay
voxeldoublbpre:

voxeldoublebuf: ; 25 times
                stx CODEMODIFIER0 | (CODEMODIFIER1 << 8)
                sty CODEMODIFIER2 | (CODEMODIFIER3 << 8)
voxeldoublebfe:

voxeldoublebwr: inx
                iny
voxeldoublebwe:

skyprepare:     ; 1 time
                lda VOXELXPOSITION
                and #%00111111
                tax
                eor #%10000000
                tay
                lda FRAMECOUNTER+$01
                and #%00111111; $00..$3f, the sky texture is 64x64 pixels
                clc
                adc #>voxelskytexture
skyprepareend:

voxnskyselfmod: ; 24 times (sky), 26 times (voxel)
                sty CODEMODIFIER0 | (CODEMODIFIER1 << 8); voxelskytexel0+$00
                sta CODEMODIFIER2 | (CODEMODIFIER3 << 8); voxelskytexel0+$01
                stx CODEMODIFIER4 | (CODEMODIFIER5 << 8); voxelskytexel1+$00
                sta CODEMODIFIER6 | (CODEMODIFIER7 << 8); voxelskytexel1+$01
                adc #CODEMODIFIER8; voxelperspectivey[numline] - voxelperspectivey[numline-1]
                cmp #CODEMODIFIER9; skytexture+$4000 or voxelmap+$4000
                bcc :+; wrapping check
                sbc #>$4000
                clc
:
voxnskyselfmde:

voxelprepare:   ; 1 time
                lda VOXELXPOSITION
                and #%01111111
                tax
                eor #%00000000; same opcodes as for skyprepare
                tay
                lda FRAMECOUNTER+$01
                and #%00111111; $00..$3f, the voxel map is 128x64 pixels
                clc
                adc #>voxelmap
voxelpreparend:

voxelprepsky:   ; 1 time
                ldx #$24
voxelprepskylp: txs
                lda #$1a
                sta VOXELCURRHITE0
                sta VOXELCURRHITE1
voxelprepskyend:

voxelputsky:    ; 24 times
                ; get x-offset into the texture according to the perspective in x
                ldy CODEMODIFIER0 | (CODEMODIFIER1 << 8),x; voxelskyperspx + (numline * 74) + 0, x = $00..$24, y = $00..$7f
                ; get texel at the texture line according to the perspective in y
voxelskytexel0 = *+$01
                lda a:00,y; skytexture+$80 + frmxoffs + ((voxelperspectivey[numline] + frmyoffs) * $0100) - frmxoffs and frmyoffs changed every frame
                ; get x-offset into the texture according to the perspective in x
                ldy CODEMODIFIER2 | (CODEMODIFIER3 << 8),x; voxelskyperspx + (numline * 74) + 37, x = $00..$24, y = $00..$7f
                ; get texel at the texture line according to the perspective in y
voxelskytexel1 = *+$01
                ora a:00,y; skytexture+$00 + frmxoffs + ((voxelperspectivey[numline] + frmyoffs) * $0100) - frmxoffs and frmyoffs changed every frame
                ; store the two pixels in the screen buffer
voxelputskybyt = *+$02
                sta CODEMODIFIER4 | (CODEMODIFIER5 << 8),x; chunky4screenline,x
voxelputskyend:

voxelcalcscape: ; 26 times
                ldy CODEMODIFIER0 | (CODEMODIFIER1 << 8),x; voxelperspectivex + (numlime*74) + 0,x
voxelmaptexel0 = *+$01
                ldx a:$00,y; voxelmap+lin49offs+frmxoffs+frmyoffs*256,y; frmxoffs and frmyoffs changed every frame
                ldy CODEMODIFIER6 | (CODEMODIFIER7 << 8),x; voxelperspectiveynumline*128,x; x = [$00..$7f], y = 0-24
                cpy VOXELCURRHITE0
                bcs :+
                lda voxelcolourtable0 | CODEMODIFIER8,x; voxelcolourtable0 + $80 - 2*numlime,x; %xxxx0000
                ora VOXELFILLTAB,y
                sta VOXELFILLTAB,y
                ldx VOXELCURRHITE0
                and #%11110000
                eor VOXELFILLTAB,x
                sta VOXELFILLTAB,x
                sty VOXELCURRHITE0
:               tsx

                ldy CODEMODIFIER2 | (CODEMODIFIER3 << 8),x; voxelperspectivex + (numlime*74) + 37,x
voxelmaptexel1 = *+$01
                ldx a:$00,y; voxelmap+lin49offs+frmxoffs+frmyoffs*256,y; frmxoffs and frmyoffs changed every frame
                ldy CODEMODIFIER6 | (CODEMODIFIER7 << 8),x; voxelperspectivey+numline*128,x; x = [$00..$7f], y = 0-24
                cpy VOXELCURRHITE1
                bcs :+
                lda voxelcolourtable1 | CODEMODIFIER8,x; voxelcolourtable1 + $80 - 2*numlime,x; %0000xxxx
                ora VOXELFILLTAB,y
                sta VOXELFILLTAB,y
                ldx VOXELCURRHITE1
                and #%00001111
                eor VOXELFILLTAB,x
                sta VOXELFILLTAB,x
                sty VOXELCURRHITE1
:               tsx
voxelcalcscend:

voxelputprep:   ; 1 time
                ldx VOXELCURRHITE0
                lda #BACKGROUND << 4
                eor VOXELFILLTAB,x
                sta VOXELFILLTAB,x
                ldx VOXELCURRHITE1
                lda #BACKGROUND
                eor VOXELFILLTAB,x
                sta VOXELFILLTAB,x
                lda #BACKGROUND     ; 2 commands because BACKGROUND | (BACKGROUND << 4) = $ff,
                ora #BACKGROUND << 4; which is also a code modifier
                ldy #$00
                tsx
voxelputpreped:

voxelput2pixls: ; 26 times
                eor CODEMODIFIER0; voxelfilltab+numline
                sty CODEMODIFIER0; voxelfilltab+numline
voxelputbyte = *+$02
                sta CODEMODIFIER4 | (CODEMODIFIER5 << 8),x; chunky4screenline,x
voxelput2pxled:

voxelrenderjmp: ; 1 time
                dex
                bmi :+
                jmp VOXELPREPSKY+(voxelprepskylp-voxelprepsky)
:               jmp aftvoxelrender; no rts because the stack pointer was altered
voxelrenderjle:
.endmacro; FRG_VOXELCODE


.segment "VOXELCOLOURTABLE0"
voxelcolourtable0:
.segment "VOXELCOLOURTABLE1"
voxelcolourtable1:
.segment "VOXELSKYPERSPX"
voxelskyperspx:
.segment "VOXELSKYTEXTURE"
voxelskytexture:
.segment "VOXELPERSPECTIVEX"
voxelperspectivex:
.segment "VOXELMAP"
voxelmap:
.segment "VOXELPERSPECTIVEY"
voxelperspectivey:
.segment "VOXELRENDERCODE"
voxelrendercode:
