
.define YOFFSET $20

OBJECTRENDERCODE = yrotrendercode+(yrotprepareend-yrotprepare)
BACKDROPRENDERCODE = OBJECTRENDERCODE+($19*(yrotputobjecte-yrotputobject))+(yrotgndskybrce-yrotgndskybrch)

.macro ARTEFACTSCENE

.ifdef NTSC_VERSION
                lda #$02                
.else
                lda #$00
.endif
                jsr startinterlude

                inc putcodesource; use upper code fragment page
                
                ; sky texture is already generated for the voxel routine and is re-used here
                
                ; generate ground texture
                ldx #>(yrotgroundtexture+$4000)
                ldy #>(yrotgroundtexture+$4000)
                jsr texgen64skygnd

                ; generate render code

               ;lda #<yrotrendercode
               ;sta POINTER+$00
                lda #>yrotrendercode
                sta POINTER+$01
                lda #<(chunky4screen1b+3+($17*$28))
                sta CODEMODIFIER5

                ldx #yrotprepareend-codefragments-$0100
                ldy #yrotprepareend-yrotprepare
                jsr putcodepiece

                lda #>(chunky4screen1b+3+($17*$28))
                sta CODEMODIFIER6
                lda #<(chunky4screen0b+3+($00*$28))
                sta CODEMODIFIER9
                lda #>(chunky4screen0b+3+($00*$28))
                sta CODEMODIFIER10
                ldx #$19
:               txs
                ldx #yrotputobjecte-codefragments-$0100
                ldy #yrotputobjecte-yrotputobject
                jsr putcodepiece
                lda CODEMODIFIER0; extra
                sec              ; nonsense
                sbc #$25         ; for a
                sta CODEMODIFIER0; better
                bcs :+           ; packing
                dec CODEMODIFIER1; result
:               ldy #CODEMODIFIER9
                jsr inclinepntrex
                lda CODEMODIFIER6
                eor #>(chunky4screen0b ^ chunky4screen1b)
                sta CODEMODIFIER6
                cmp #>(chunky4screen1b-$0400)
                lda CODEMODIFIER5
                bcc :+
                sbc #$28
                SKIPBYTE
:               sec
                sta CODEMODIFIER5
                lda CODEMODIFIER6
                sbc #$00
                sta CODEMODIFIER6                 
                tsx
                dex
                bne :---

                lda #<(yrotradiustable0+($19*$25))
                sta CODEMODIFIER0
                lda #>(yrotradiustable0+($19*$25))
                sta CODEMODIFIER1
                lda #<(chunky4screen1b+3+($0b*$28)); sky destination screen line
                sta CODEMODIFIER5
                
                ldx #yrotgndskybrce-codefragments-$0100
                ldy #yrotgndskybrce-yrotgndskybrch
                jsr putcodepiece

                lda #>(chunky4screen1b+3+($0b*$28))
                sta CODEMODIFIER6
                lda #<(chunky4screen0b+3+($0c*$28)); ground destination screen line
                sta CODEMODIFIER9
                lda #>(chunky4screen0b+3+($0c*$28))
                sta CODEMODIFIER10
                ldx #$1a
:               txs
                lda CODEMODIFIER1
                eor #>(yrotradiustable0 ^ yrotangletable0)
                sta CODEMODIFIER2
                eor #>(yrotangletable0 ^ yrotradiustable1)
                sta CODEMODIFIER3
                eor #>(yrotradiustable1 ^ yrotangletable1)
                sta CODEMODIFIER4
                eor #>(yrotangletable1 ^ yrotradiustable2)
                sta CODEMODIFIER7
                eor #>(yrotradiustable2 ^ yrotradiustable3)
                sta CODEMODIFIER8
                ldx #yrotputgndskye-codefragments-$0100
                ldy #yrotputgndskye-yrotputgndsky
                jsr putcodepiece
                lda CODEMODIFIER0
                sec
                sbc #$25
                sta CODEMODIFIER0
                bcs :+
                dec CODEMODIFIER1
:               ldy #CODEMODIFIER9
                jsr inclinepntrex
                lda CODEMODIFIER6
                eor #>(chunky4screen0b ^ chunky4screen1b)
                sta CODEMODIFIER6
                cmp #>(chunky4screen1b-$0400)
                lda CODEMODIFIER5
                bcc :+
                sbc #$28
                SKIPBYTE
:               sec
                sta CODEMODIFIER5
                lda CODEMODIFIER6
                sbc #$00
                sta CODEMODIFIER6
                tsx
                dex
                bne :---

                dec putcodesource; use lower code fragment page
                
                ldx #yrotrenderjmpe-codefragments
                ldy #yrotrenderjmpe-yrotrenderjmp
                jsr putcodepiece
                
                ; generate tables
                
                ; build offset table for skipping backdrop render code
                lda #<yrotbranchtable0+$80
                sta POINTER+$02
                lda #>yrotbranchtable0+$00
                sta POINTER+$01
                sta POINTER+$03
                lda #yrotputobjecte-yrotputobject
                sta BUFFER+$00
                lda #<(OBJECTRENDERCODE-$01)
                ldx #>(OBJECTRENDERCODE-$01)
                ldy #<yrotbranchtable0+$00; $00
                sty POINTER+$00
                jsr buildslopetbex
                lda #yrotputgndskye-yrotputgndsky
                sta BUFFER+$00
                lda #<(BACKDROPRENDERCODE-$01)
                ldx #>(BACKDROPRENDERCODE-$01)
                ldy #<yrotbranchtable1+$00
                jsr buildslopetbex

                ; calculate x-perspective table
                ldx #>yrotperspectivex
                ldy #$ff
                jsr calcperspxtabl

                ldy #<yrotangletable0
                sty POINTER+$00
                sty POINTER+$02
                lda #<-YOFFSET
                sta BUFFER+$05; y position
                lda #>yrotperspectivex
                sta POINTER+$01                
                lda #>yrotangletable0
                sta POINTER+$03
                ldx #$1a
genyrottables:  txs
                sty POINTER+$04
                sty POINTER+$06
                sty POINTER+$08
                sty POINTER+$0a
                sty POINTER+$0c
                eor #>(yrotangletable1 ^ yrotangletable0)
                sta POINTER+$05
                eor #>(yrotradiustable0 ^ yrotangletable1)
                sta POINTER+$07
                eor #>(yrotradiustable1 ^ yrotradiustable0)
                sta POINTER+$09
                eor #>(yrotradiustable2 ^ yrotradiustable1)
                sta POINTER+$0b
                eor #>(yrotradiustable3 ^ yrotradiustable2)
                sta POINTER+$0d
                lda BUFFER+$05
                pha
                jsr sqrs_8_16
                sta POINTER+$0f; hi-byte
                sty POINTER+$10; lo-byte
                pla
                clc
                adc perspectiveytable-$02,x; get perpective y diff value
                sta BUFFER+$05

                ldy #$24                
genyrottabline: sty POINTER+$11

                ; left pixels
                lda (POINTER+$00),y; get perspective x value
                pha
                jsr sqrs_8_16
                pha
                tya
                clc
                adc POINTER+$10; lo-byte
                tay
                pla
                adc POINTER+$0f; hi-byte
                jsr sqrtu_16_8
                sta (POINTER+$06),y
               ;clc
                adc #>(yrotgroundtexture - yrotskytexture)
                sta (POINTER+$0a),y

                ; find angle
                lda BUFFER+$05
                bpl :+
                eor #%11111111
:               tax; y coordinate
                pla; x coordinate
                php
                bpl :+
                eor #%11111111
:               jsr atnu_80_80_88
                ldy #$40; the textures are 64x64 pixels
                jsr mulu_8_8_16
                bit BUFFER+$05
                bpl :+
                eor #%00111111; the textures are 64x64 pixels
:               plp
                bpl :+
                eor #%00111111; the textures are 64x64 pixels
:               ldy POINTER+$11
                sta (POINTER+$02),y

                ; right pixels
                tya
                clc
                adc #$25
                tay
                lda (POINTER+$00),y; get perspective x value
                pha
                jsr sqrs_8_16
                pha
                tya
                clc
                adc POINTER+$10; lo-byte
                tay
                pla
                adc POINTER+$0f; hi-byte
                jsr sqrtu_16_8
                sta (POINTER+$08),y
               ;clc
                adc #>(yrotgroundtexture - yrotskytexture)
                sta (POINTER+$0c),y
                
                ; find angle
                lda BUFFER+$05
                bpl :+
                eor #%11111111
:               tax; y coordinate
                pla; x coordinate
                php
                bpl :+
                eor #%11111111
:               jsr atnu_80_80_88
                ldy #$40; the textures are 64x64 pixels
                jsr mulu_8_8_16
                bit BUFFER+$05
                bpl :+
                eor #%00111111; the textures are 64x64 pixels
:               plp
                bpl :+
                eor #%00111111; the textures are 64x64 pixels
:               ldy POINTER+$11
                sta (POINTER+$04),y
                
                dey
                bmi :+
                jmp genyrottabline

:               lda #$4a
                jsr addtopointer; POINTER+$00
                lda #$25
                jsr zpadd8to16bits; POINTER+$02
                tay
                lda POINTER+$03

                tsx
                dex
                beq :+
                jmp genyrottables

:               ldx #enterartefact-tracks
                ldy #colourset2-coloursets
                jsr stopinterlude

                ldx #$17
getyrotangles:  jsr getrandom
                sta yrotvertexangles,x
                dex
                bpl getyrotangles

aftyrotrender:  lda #$00
                ldx #$49
:               sta yrotypostable,x
                dex
                bpl :-
                sta POINTER+$00
                lda #$17
                sta BUFFER+$04; face count
                inc YROTANGLE
                
artefactloop:   ldx BUFFER+$04
                lda yrotvertexangles,x
                clc
                adc YROTANGLE
                tay
                bpl :+
                eor #%11111111
:               tax
                lda yrotytable,x
                sta BUFFER+$01; y1
                tya
                asl
                lda yrotxtable,y
                bcc :+
                tya
                eor #%11111111
                tay
                lda #$4b
                sec
                sbc yrotxtable,y
:               sta POINTER+$01; x1

                lda BUFFER+$04
                lsr
                bcs dontdrawface

:               lda POINTER+$01; x1
                sec
                sbc POINTER+$00; x0
                bcs :+
                ; swap vertices
                lda POINTER+$01; x1
                ldx POINTER+$00; x0
                stx POINTER+$01
                sta POINTER+$00
                lda BUFFER+$01; y1
                ldx BUFFER+$00; y0
                stx BUFFER+$01
                sta BUFFER+$00
                bcc :-
:               tax
                lda BUFFER+$01; y1
                sec
                sbc BUFFER+$00; y0
                php
                bcs :+
                eor #%11111111
               ;clc
                adc #$01
:               jsr divu_80_80_88
                plp
                bcs :+
                lda #$00
                sec
                sbc RESULT+$00
                sta RESULT+$00
                lda #$00
                sbc RESULT+$01
                sta RESULT+$01
:               ldx POINTER+$00; x0
                lda BUFFER+$00; y0
                ldy #$80
:               cmp yrotypostable+$00,x
                bcc :+
                sta yrotypostable+$00,x
:               pha
                tya
                clc
                adc RESULT+$00
                tay
                pla
                adc RESULT+$01
                cpx POINTER+$01; x1
                inx
                bcc :--

dontdrawface:   lda POINTER+$01; x1
                sta POINTER+$00; x0
                lda BUFFER+$01; y1
                sta BUFFER+$00; y0
                dec BUFFER+$04; face number
                bmi :+
                jmp artefactloop
                
:               ldx #surfacescenend-tracks
                cpx TRACKPOS+$0e
                bcs :+
                jmp yrotrendercode
:
.endmacro

.macro FRG_YROTCODE

yrotrenderjmp:  ; 1 time
                dex
                bmi :+
                jmp yrotrendercode+(yrotloop-yrotprepare)
:               jmp aftyrotrender
yrotrenderjmpe = *-$01

                ; * = codefragments+$0100

yrotprepare:    ; 1 time
                lda YROTANGLE; $00..$ff
                and #%00111111; the textures are 64x64
                sta POINTER+$02
                eor #%10000000
                sta POINTER+$00
                ldx #$24
yrotloop:       stx POINTER+$01
                txa
                asl
                tax
                ldy yrotypostable+$00,x
                lda yrotbranchtable1+$80,y
                pha
                lda yrotbranchtable1+$00,y
                pha
                tya
                clc
                eor #$3f; don't collide with the code modifiers
                adc #$d9; don't collide with the code modifiers
                tay
                lda yrotbranchtable0+$80,y
                pha
                lda yrotbranchtable0+$00,y
                pha
                
                lda yrotypostable+$00,x
                bne :+
                lda yrotypostable+$01,x
:               lsr
                clc
                eor #$3f; don't collide with the code modifiers
                adc #$cf; don't collide with the code modifiers
                asl
                asl
                asl
                asl
                sta POINTER+$03
                lda yrotypostable+$01,x
                bne :+
                lda yrotypostable+$00,x
:               lsr
                clc
                eor #$3f; don't collide with the code modifiers
                adc #$cf; don't collide with the code modifiers
                ora POINTER+$03
                ldx POINTER+$01
                ; the code overlaps here to save some bytes
yrotgndskybrch: ; 1 time
                rts
yrotprepareend:
yrotgndskybrce:
               
yrotputgndsky:  ; 26 times
                ; sky
                ldy CODEMODIFIER0 | (CODEMODIFIER1 << 8),x; yrotradiustable0+(numline*$25)
                sty POINTER+$01
                ldy CODEMODIFIER0 | (CODEMODIFIER2 << 8),x; yrotangletable0+(numline*$25), $00..$3f
                lda (POINTER+$00),y; read from texture line, [$00..$7f]
                ldy CODEMODIFIER0 | (CODEMODIFIER3 << 8),x; yrotradiustable1+(numline*$25)
                sty POINTER+$03
                ldy CODEMODIFIER0 | (CODEMODIFIER4 << 8),x; yrotangletable1+(numline*$25), $00..$3f
                ora (POINTER+$02),y; read from texture line, [$00..$7f]
                sta CODEMODIFIER5 | (CODEMODIFIER6 << 8),x; chunky4screenline,x
                ; ground
                ldy CODEMODIFIER0 | (CODEMODIFIER7 << 8),x; yrotradiustable2+(numline*$25)
                sty POINTER+$01
                ldy CODEMODIFIER0 | (CODEMODIFIER2 << 8),x; yrotangletable0+(numline*$25), $00..$3f
                lda (POINTER+$00),y; read from texture line, [$00..$7f]
                ldy CODEMODIFIER0 | (CODEMODIFIER8 << 8),x; yrotradiustable3+(numline*$25)
                sty POINTER+$03
                ldy CODEMODIFIER0 | (CODEMODIFIER4 << 8),x; yrotangletable1+(numline*$25), $00..$3f
                ora (POINTER+$02),y; read from texture line, [$00..$7f]
                
                ; the code overlaps here to save some bytes
yrotputobject:  ; 25 times
                sta CODEMODIFIER9 | (CODEMODIFIER10<< 8),x; chunky4screenline,x
yrotputgndskye:
                sta CODEMODIFIER5 | (CODEMODIFIER6 << 8),x; chunky4screenline,x
yrotputobjecte:
.endmacro; FRG_YROTCODE

.macro DAT_YROTXYTABLES

yrotxtable = tables+$0300
yrotytable = tables+$0400

.endmacro; DAT_YROTYTABLES

.segment "YROTYPOSTABLE"
yrotypostable:
.segment "YROTVERTEXANGLES"
yrotvertexangles:
.segment "YROTSKYTEXTURE"
yrotskytexture:
.segment "YROTSHADINGLEFT"
yrotshadingleft:
.segment "YROTSHADINGRIGHT"
yrotshadingright:
.segment "YROTBRANCHTABLE0"
yrotbranchtable0:
.segment "YROTBRANCHTABLE1"
yrotbranchtable1:
.segment "YROTGROUNDTEXTURE"
yrotgroundtexture:
.segment "YROTPERSPECTIVEX"
yrotperspectivex:
.segment "YROTANGLETABLE0"
yrotangletable0:
.segment "YROTANGLETABLE1"
yrotangletable1:
.segment "YROTRADIUSTABLE0"
yrotradiustable0:
.segment "YROTRADIUSTABLE1"
yrotradiustable1:
.segment "YROTRADIUSTABLE2"
yrotradiustable2:
.segment "YROTRADIUSTABLE3"
yrotradiustable3:
.segment "YROTRENDERCODE"
yrotrendercode:
