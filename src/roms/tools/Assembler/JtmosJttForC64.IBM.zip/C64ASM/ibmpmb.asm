ibmpview                lda #$0b
;
;       MB/IBMP viewer library (MultiBackground Color enchanced)
;
;       $0400-$07e8 -> Screen, program copy $0400-$07e8
;                      to $4400 automatically.
;       $d800-$dbe8 -> Colors.
;       $0f00-$0fc8 -> One $d021 for each line(y).
;
;
;       Bug found and fixed :
;
;               $dd00 should be changed by changing
;               only two first bits, the video bank specifier.
;
                        sta $d011
                        ;
                        lda #0
                        sta $d020
                        sta $d021
                        ldx #0
loop                    lda $0400,x
                        sta $4400,x
                        lda $0500,x
                        sta $4500,x
                        lda $0600,x
                        sta $4600,x
                        lda $0700,x
                        sta $4700,x
                        inx
                        bne loop
                        ;
                        sei
                        lda #<ibmpirq
                        ldx #>ibmpirq
                        sta $0314
                        stx $0315
                        lda #1
                        sta $d01a
                        sta $dc0d
                        lda #$3b
                        sta $d011
                        lda #$00
                        sta $d012
                        lda #0
                        sta ibmpcounter
                        sta ibmpcounter+1
                        sta ibmpcounter+2
                        sta ibmpcounter+3
                        cli
                        ;
                        rts

ibmpiupdate             nop
                        ;
ibmpdd00                lda #3
                        eor #1
                        sta ibmpora+1
                        lda $dd00
                        and #%11111100
ibmpora                 ora #0
                        sta $dd00
                        sta ibmpdd00+1
                        ;
ibmpd016                lda #$d8
                        eor #1
                        sta ibmpd016+1
                        sta $d016
                        ;
ibmpd018                lda #$19
                        sta $d018
                        ;
                        rts

ibmpilace               .byte $ff

ibmpirq                 lda ibmpilace
                        beq ibmpirql1
                        jsr ibmpiupdate
ibmpirql1               lda ibmpflash
                        beq ibmpirql2
                        jsr ibmpflashing
ibmpirql2               nop
                        jsr ibmptimer
;                        jsr playifavailable
                        ;
                        ; Produce multi-background colors with a rasterbar.
                        ;
                        lda #$33
                        sta ibmpirql4+1
                        ;
                        ldx #$00
ibmpirql4               lda #$33
                        ldy $0f00,x
ibmpirql5               cmp $d012
                        bne ibmpirql5
                        sty $d021
                        inc ibmpirql4+1
                        inx
                        cpx #200
                        bne ibmpirql4
                        ;
                        inc $d019
                        jmp $ea7e

ibmpcounter             .word 0,0

ibmptimer               lda ibmpcounter+0
                        clc
                        adc #1
                        sta ibmpcounter+0
                        lda ibmpcounter+1
                        adc #0
                        sta ibmpcounter+1
                        lda ibmpcounter+2
                        adc #0
                        sta ibmpcounter+2
                        lda ibmpcounter+3
                        adc #0
                        sta ibmpcounter+3
                        rts

ibmpflashing            lda ibmpcounter+0
                        lsr
                        lsr
                        lsr
                        lsr
                        and #31
                        tax
                        lda cols,x
                        sta $d020
                        rts
cols                    .byte $00,$09,$08,$0a
                        .byte $0f,$0a,$08,$09
                        .byte $00,$06,$0e,$03
                        .byte $0d,$03,$0e,$06
                        .byte $00,$0b,$0c,$0f
                        .byte $07,$0f,$0c,$0b
                        .byte $00,$06,$04,$0e
                        .byte $03,$0e,$04,$06

ibmpflash               .byte 0
