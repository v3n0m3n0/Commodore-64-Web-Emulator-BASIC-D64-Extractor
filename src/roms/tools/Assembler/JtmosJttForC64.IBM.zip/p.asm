;
;       "Modified"
;       Animation Player program
;       ------------------------        (C)1998 by Jari Tapio Tuominen,
;                                               all rights reserved.
;
;
;       Animation file description:
;
;               (Offset)
;               0x00            Start address(0x4000)
;               0x02            Background fillbyte (Usually,0x00 or 0xff)
;               0x03            Animation chunk
;
;       Codes:
;               0x53 = Seuraava kuva
;               0x54 = Warppi
;               0x56 = Monistus
;
;
                *=2061
mplay=$e042
           ; $E042 is just an offset to RTS opcode on the KERNEL image.
           ; Change it to $1003, what ever you like to.
playit          nop
                jsr stimer
                lda #$36        ; Setup $a000-$c000 as RAM
                sta 1
                lda #$3b
                sta $d011
                lda #$19
                sta $d018
                lda #$d8
                sta $d016
                lda #0
                sta $d020
                sta $d021
                lda #$bc
                ldx #$0f
                jsr setcolors
                jsr constbmp
again           jsr play
                dec looping
                beq outtahere
                jmp again
outtahere       nop
                ; Back to OS 8)
                lda #$37
                sta 1   ; Turn the lame basic ON again :�-)
                rts

constbmp        lda #<$2000
                ldx #>$2000
                sta $34
                stx $35
                ldy #0
constbmpl1      lda $4000
                sta ($34),y
                iny
                lda #0
                sta ($34),y
                iny
                bne constbmpl1
                inc $35
                ldx $35
                cpx #$40
                bne constbmpl1
                rts

setcolors       sta 2
                stx 3
                ldy #0
setloop         lda 2
                sta $0400,y
                sta $0500,y
                sta $0600,y
                sta $0700,y
                lda 3
                sta $d800,y
                sta $d900,y
                sta $da00,y
                sta $db00,y
                iny
                bne setloop
                rts

play            lda #<$4001
                ldx #>$4001
                sta $30
                stx $31
                ;
                ;*Next frame*
loop1           lda #<$2000
                ldx #>$2000
                sta $32
                stx $33
                ;
                ldy #0
                lda ($30),y
                cmp #$53
                bne n53
                iny
                lda ($30),y
                cmp #$53
                bne n53
                jmp thatsall
n53             nop
                ;
                jsr i30
                ;
                ; Start decoding to $2000
loop2           ldy #0
                lda ($30),y     ; WARPPI = 0x54
                cmp #$54
                bne n54
                jsr i30
                lda $32
                clc
                adc ($30),y
                sta $32
                lda $33
                adc #0
                sta $33
                lda $32
                clc
                adc ($30),y
                sta $32
                lda $33
                adc #0
                sta $33
                jsr i30
                jmp loop2
                ; MONISTUS = 0x56
n54             cmp #$56
                bne n56
                jsr i30
                lda ($30),y
                sta 2
                jsr i30
                lda ($30),y
                ldx #0
loop3           sta ($32),y                
                jsr i32
                sta ($32),y     ; Document this if you want blank lines!
                jsr i32
                inx
                cpx 2
                bne loop3
                jsr i30
                jmp loop2
n56             lda ($30),y
                cmp #$53
                beq looped1
                lda ($30),y
                sta ($32),y
                iny             ; Document this if you want blank lines!
                sta ($32),y     ; -''-
                jsr i30
                jsr i32
                jsr i32
                jmp loop2
looped1         lda #4
                jsr wait
                jmp loop1
                ;
thatsall        rts

i30             inc $30
                bne b30
                inc $31
b30             rts

i32             inc $32
                bne b32
                inc $33
b32             rts

filename        .text "anim"
                .byte 0

stimer          sei
                lda #<irq
                ldx #>irq
                sta $0314
                stx $0315
                lda #1
                sta $d01a
                sta $dc0d
                lda $d011
                and #$7f
                sta $d011
                lda #0
                sta $d012
                sta framer
                cli
                rts

irq             lda #255
                sta framer
                ;
                jsr mplay
                ;
                inc $d019
                jmp $ea31

wait            tax
waitl1          jsr wait1
                dex
                bne waitl1
                rts

wait1           lda #0
                sta framer
wait1l1         lda framer
                beq wait1l1
                rts

key             jsr $ffe4
                beq key
                sta k
                rts

looping         .byte 4 ; How many times should animation loop ?
k               .byte 0
framer          .byte 0
