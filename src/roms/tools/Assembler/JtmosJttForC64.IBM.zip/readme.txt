All right, this is the final version of my UNIQUE/JTT compiler for C=64,
my own programming language.

(C)1998-99 by Jari Tapio Tuominen, all rights reserved.
Use carefully, no warranty!

Last minute note:

It might be a good idea to get C64ASM
to compile the .ASM files into C=64 executable format[.PRG].
Btw, there will come out alot more exciting and powerful compiler
in near future, it'll truly change something in C=64 programming,
I hope :)


How to compile:

     COMPILE TO Commodore 64: (YOU NEED C64ASM from Balint Toth,
                               just use altavista to get it :)
        jlcomp test l: c64asm.lan

     COMPILE TO IBM PC: (YOU NEED NASM OR TASM)
        jlcomp test l: nasm386.lan

        or

        jlcomp test l: tasm386.lan

