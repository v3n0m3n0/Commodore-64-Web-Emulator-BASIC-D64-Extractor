/*
 * Copyright (C) 1998 Wolfgang Moser
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * Commodore CBM 1581 floppy disk copy util for PC's, DISKSCAN.C
 *
 * Wolfgang Moser <womo@mindless.com>
 *   http://www.gm.fh-koeln.de/~womo (up to September 1999)
 *
 *
 * Basic informations from Dan Fandrich <dan@fch.wimsey.bc.ca>.
 *   His readme of the cbmfs-0.3 driver for Linux explained me, what the
 *   difference between a DOS formatted 800 kb disk and a CBM 1581 disk is.
 *   (check: http://vanbc.wimsey.com/~danf/software/)
 *
 *
 * Basic implementations by Ciriaco Garc�a de Celis <ciri@gui.uva.es>
 *   His util 765Debug, Version 5.0 is great for learning dma based
 *   direct floppy disk controller programming.
 *   (check: ftp://ftp.gui.uva.es/pub/pc/2m/765d50sr.zip)
 *
 * Check out for his floppy disk utils 2M and 2MGUI, the last words
 * in improving floppy disk storage capacity.
 *   http://www.gui.uva.es/2m, ftp://ftp.gui.uva.es/pub/pc/2m
 *
 *
 * For additional informations to FDC programming check:
 *     http://developer.intel.com/design/periphrl/datashts/290468.htm
 *   and get the intel 82078 CHMOS Single-Chip Floppy Disk Controller
 *   PDF document:
 *     http://www.intel.nl/design/periphrl/datashts/29047403.pdf
 */


#include <stdlib.h>
#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include "..\src\central.h"

	// floppy disk controller NEC �PD765 compatible registers
#define FD_DATA	0x3F5	// FDC �PD765 data IO register
#define FD_STATUS	0x3F4	// FDC �PD765 main status register
#define FD_DOR		0x3F2	// FDC �PD765 digital output register
#define FD_DCR		0x3F7	// digital input / floppy control register


	// timer tick based timeout values
#define FDC_TIMEOUT	8	// ca.  440 ms ( 8/18.2 s)
#define OP_TIMEOUT	37	// ca. 2000 ms (37/18.2 s)

#define specifyCMD1		0xDF	// step rate and head unload time


	// some typedefs for reducing too much text
typedef	unsigned int	uint;
typedef	unsigned char	uint8;
typedef	unsigned short	uint16;
typedef	unsigned long	uint32;

typedef	union{
	struct{
		short	ST0;		// valid values: 0...255, -1 (FDC not responding)
		uint8	ST1;
		uint8	ST2;

		uint8	Cylinder;
		uint8	Side;		// physically, not Commodore logically
		uint8	Sector;
		uint8	BytesPS;	// bytes per sector description (divided by 256)
		}D;
	uint8 Status[8];		// the whole status word
	}resultString;


unsigned long int read_tsc(void){
	union{
		unsigned long int tsc;
		struct{
			signed short int l;
			signed short int h;
			} lh;
		}Llh;

	asm	pushf					// Save current interrupt flag
	asm	cli					// Disable interrupts

	// using system timer and ticks counter instead of rdtsc
	asm	mov	ax,	0x40
	asm	mov	es,	ax
	asm	mov	dx,	es:[0x6C]
		//	Llh.lh.h=peek(0x40, 0x6C);

	asm	mov	al,	0x00
	asm	out	0x43,	al		// Latch timer 0

	asm	in		al,	0x61	// Waste some time (waitstated)

	asm	in		al,	0x40	// Counter --> bx
	asm	mov	bl,	al		// LSB in BL

	asm	in		al,	0x61	// Waste some time (waitstated)

	asm	in		al,	0x40
	asm	mov	bh,	al		// MSB in BH
	asm	not	bx				// Need ascending counter

	asm	popf					// Restore interrupt flag


	asm   mov	cl,	15
	asm	mov	di,	bx    // If the MSB of the system timer
	asm	sar	di,	cl		// is set, then the second

	asm	and	dx,	di		// measured ticks counter value
	asm	not	di				// is selected, otherwise the

	asm	mov	ax,	0x40
	asm	mov	es,	ax
	asm	mov	cx,	es:[0x6C]
   		//	h=peek(0x40, 0x6C);
	asm	and	cx,	di		// first measured ticks counter
	asm	or		dx,	cx		// value is select as high word

	asm   mov	ax,	bx		// system timer value is low word

	Llh.lh.l=_BX;
	Llh.lh.h=_DX;

	return Llh.tsc;
	}

unsigned long int diff_TSC(unsigned long int lastTSC, unsigned long int newTSC){
	unsigned long int diff;

	diff=newTSC-lastTSC;
 	diff+=(diff&0x80000000L)>>15;	// undetected overflow fix
   return diff;
	}

static unsigned char bitrate, modulation;
void setDriveParameters(unsigned char BR, unsigned char MFMFM){
	bitrate=BR;			// 0 - 500, 1 - 300, 2 - 250, 3 - 125
   modulation=MFMFM;	// 0 - FM, 1 - MFM
	}

int waitUntilReady4Transfer(uint8 *STAT){	// time out after 440 ms
	int t,i=FDC_TIMEOUT;
	do{
		t=peekb(0x40, 0x6C);
		while(t==peekb(0x40, 0x6C)){
			if((*STAT=inportb(FD_STATUS))&0x80) return 1;
			}
		}while (i-->0);
	return 0;
	}

int inFDC(void){							// read byte from FDC data register
	uint8 status;
	return waitUntilReady4Transfer(&status)?inportb (FD_DATA):-1;
	}

void clearFDCresults(void){
	while((inportb(FD_STATUS)&0xC0)==0xC0){
		delay(2);
		inFDC();						// clear FDC data register,
		delay(2);					// get all return values
		}
   }

int outFDC(uint8 data){		// write byte to FDC data register
	uint8 status;

   do{
   	clearFDCresults();	// get old result bytes, if there are any
		if(!waitUntilReady4Transfer(&status)) return -2;	// FDC not responding (outFDC)
   	}while(status&0x40);
	outportb(FD_DATA, data);
	return 1;
	}

void prepareDMA (uint8 mode, uint16 bytes,
					  uint8 huge *DMAbuf){
	  /*
		*	Bitfields for DMA channel 0-3 mode register (port 0x0B):
		*	Bit(s)	Description
		*		7-6  transfer mode		5 direction
		*		  00 demand mode			  =0 address increment select
		*		  01 single mode			  =1 address decrement select
		*		  10 block mode
		*		  11 cascade mode
		*
		*	 3-2	operation				1-0	channel number
		*		00 verify operation		  00 channel 0 select
		*		01 write to memory		  01 channel 1 select
		*		10 read from memory       10 channel 2 select
		*		11 reserved               11 channel 3 select
		*/

	unsigned long	flat;
	unsigned short	page, offs;

		// normalize pointer
	flat= ((unsigned long)FP_SEG(DMAbuf)<<4)+FP_OFF(DMAbuf);
	page= flat>>16;
	offs= flat&0xFFFF;
		// decrement to highest ("array") index number
	bytes--;

#ifdef DISABLE_INTS
disable();
#endif
	outportb (0x81, page);			// DMA channel 2 address byte 2
	outportb (0x0B, mode);			// DMA channel 0-3 mode register
	outportb (0x0C, 0);				// DMA clear byte pointer flip-flop
	outportb (0x04, offs&0xFF);   // DMA channel 2 address byte 0
	outportb (0x04, offs>>8);     // DMA channel 2 address byte 1
	outportb (0x05, bytes&0xFF);	// DMA channel 2 word count byte 0
	outportb (0x05, bytes>>8);		// DMA channel 2 word count byte 1
	outportb (0x0A, 2);				// clear mask bit of DMA channel 2
#ifdef DISABLE_INTS
enable();
#endif
	}

void waitUntilInterrupt(void){	// time out after 2 seconds
	int t,i=OP_TIMEOUT;

	t=peekb(0x40, 0x6C);
	do if(t!=peekb(0x40, 0x6C)){
		t=peekb(0x40,0x6C);
		if(i--<0) break;
		}while(!(peekb(0x40,0x3E)&0x80));
	pokeb(0x40,0x3E,peekb(0x40,0x3E)&0x7F);
	}

void switchMotorOn(uint drive){
	int i;
			// 0040h:0040h - DISKETTE - MOTOR TURN-OFF TIMEOUT COUNT
	pokeb(0x40,0x40,0xFF);
			// 0040h:003Fh - DISKETTE - MOTOR STATUS
	if(((i=peekb(0x40,0x3F))&(1<<drive))==0){
		outportb(FD_DOR,(1<<(drive+4))|(4+8)|drive);
		pokeb(0x40,0x3F,i|(1<<drive));
		delay(1000);
		pokeb(0x40,0x40,0xFF);
		}
	}

void switchMotorOff(void){
			// 0040h:0040h - DISKETTE - MOTOR TURN-OFF TIMEOUT COUNT
	pokeb(0x40,0x40,55);
	}

void specifyDensity(void){
	outportb(FD_DCR, bitrate);				// select bitrate (disk density)
	if(outFDC(3)<0 ||					// specify command
		outFDC(specifyCMD1)<0 ||	// head unload time, step rate time
		outFDC(0x02)<0					// head load time, switch to DMA mode
		);
	}

void selectDrive(uint drive){
		// 0040h:0040h - DISKETTE - MOTOR TURN-OFF TIMEOUT COUNT
	pokeb(0x40,0x40,0xFF);
		// select drive, reset FDC, motor on
	outportb(FD_DOR,(1<<(drive+4))|(4+8)|drive);
	pokeb(0x40,0x3F,peekb(0x40,0x3F)|(1<<drive));

	specifyDensity();
	}

int senseInterruptStat(resultString *resStr){
	int res;

	for(res=0;res<8;res++) resStr->Status[res]=0;
	if(outFDC(8)>=0){				// sense interrupt status command
	   resStr->D.ST0=inFDC();
	   if(resStr->D.ST0>0){
		   res=inFDC();
		   if(res>0){
			   resStr->D.Cylinder=res;
			   return 1;
			   }
		   }
      }
	return 0;
	}

void resetDrive(uint drive){
	resultString RS;

	pokeb(0x40,0x3E,peekb(0x40,0x3E)&0x7F);		// clear interrupt bit

	outportb(FD_DOR,(1<<(drive+4))|drive|8);		// reset
	delay(2);
	outportb(FD_DOR,(1<<(drive+4))|drive|(8+4));	// finish reset

	waitUntilInterrupt();

	senseInterruptStat(&RS);
	}

int valid7ResultString(resultString *resStr){
	int i,res;

	resStr->D.ST0=inFDC();
	if(resStr->D.ST0<0) return 0;

	for(i=2;i<8;i++){
		res=inFDC();
		if(res<0){
			resStr->D.ST0=-1;
			return 0;
			}
		else resStr->Status[i]=res;
		}

	res=resStr->D.ST0&0xC0;
	return !res;
	}

void printResultString(resultString *resStr, uint8 huge *buf){
	int  str, t, bit;
	static char *sterr[2][8]={{
		"MA (Missing address mark)",
		"NW (Non writable: write protect error)",
		"ND (No data)",
		"",
		"OR (Overrun)",
		"DE (Data error)",
		"",
		"EN (End of cylinder)",
		},{
		"MD (Missing address mark in data field",
		"BC (Bad cylinder)",
		"SN (Scan not satisfied)",
		"SE (Scan equal hit)",
		"WC (Wrong Cylinder)",
		"DD (Data Error in Data Field)",
		"CM (Control Mark)",
		""}};


	if(resStr->D.ST0<0) sprintf((char*)buf, "[ST0 %4d]   FDC doesn't answer! ERROR!\n",resStr->D.ST0);
	else{
		sprintf((char*)buf, "[ST0 0x%02X] [ST1 0x%02X] [ST2 0x%02X] [Cyl %3d] "
				 "[Side %1d] [Sec %2d] [Byte %3d] : ",
				 resStr->D.ST0, resStr->D.ST1, resStr->D.ST2,
				 resStr->D.Cylinder, resStr->D.Side,
				 resStr->D.Sector, resStr->D.BytesPS);
		resStr->D.ST1&=0xB7;
		resStr->D.ST2&=0x7F;

		if(resStr->D.ST0&0xC0)	sprintf((char*)buf, "ERROR!\n");
		else							sprintf((char*)buf, "OK\n");

		for(str=2; str<=3; str++) for(bit=0, t=1; bit<8; bit++, t<<=1){
			if(resStr->Status[str]&t)
				sprintf((char*)buf, "ST%c(%c): %s\n",str+'0'-1,bit+'0',sterr[str-2][bit]);
			}
		}
	}

resultString *recalibrateDrive(uint drive, uint side){
	static resultString RS;
	int tries;

#ifdef USE_TSC
	printf("%20s","reaclibrateDrive");
	print_Tz_since();
#endif

	switchMotorOn(drive);			// set again timeout count

	resetDrive(drive);
//	resetDrive(drive);
	specifyDensity();

   RS.D.ST0=-2;						// default: FDC not responding
	for(tries=2;tries>0;tries--){
		if(outFDC(0x07)<0 ||			// recalibrate command
			outFDC((side<<2)|drive)<0
			)return &RS;

		waitUntilInterrupt();

		senseInterruptStat(&RS);
		if((RS.D.ST0&0xF0)==0x20)break;
		}
	return (tries>0)?NULL:&RS;
	}

resultString *seekToTrack(uint drive, uint track, uint side){
	static resultString RS;

#ifdef USE_TSC
	printf("%20s","seekToTrack");
	print_Tz_since();
#endif

	switchMotorOn(drive);			// set again timeout count

   RS.D.ST0=-2;						// default: FDC not responding
   if(outFDC(0x0F)<0 ||				// seek command
   	outFDC((side<<2)|drive)<0 ||
		outFDC(track)<0
		)return &RS;

	waitUntilInterrupt();

	senseInterruptStat(&RS);
	if(RS.D.ST0&0xC0){
		delay(750);
		senseInterruptStat(&RS);
		}
	return((RS.D.ST0&0xF0)==0x20)?NULL:&RS;
	}

resultString *readSectorID(uint drive, uint side,
									uint *rTrack, uint *rSide, uint *rSector, uint *rBytesPS){
	static resultString RS;

	switchMotorOn(drive);			// set again timeout count
   selectDrive(drive);

   RS.D.ST0=-2;						// default: FDC not responding
   if(outFDC(0x0A | (modulation<<6))<0 ||
		outFDC((side<<2)|drive)<0
		)return &RS;

	waitUntilInterrupt();

	if(valid7ResultString(&RS)){
		*rTrack  =RS.D.Cylinder;
		*rSide   =RS.D.Side;
		*rSector =RS.D.Sector;
		*rBytesPS=RS.D.BytesPS;
		return NULL;
		}
	else{
		*rTrack=*rSide=*rSector=*rBytesPS=0xFF;
		return &RS;
		}
	}

resultString *readRawTrack(uint drive, uint head,
									uint track, uint side,
									uint sector, uint BpS,
									uint8 huge *buffer){
	static resultString RS;

	switchMotorOn(drive);			// set again timeout count
   selectDrive(drive);

		// DMA mode: channel 2, write to memory,
		// address increment, single mode
	prepareDMA(0x46, 128u << BpS, buffer);


   RS.D.ST0=-2;						// default: FDC not responding
   if(outFDC (0x02|(modulation<<6))<0 ||			// Read a Track
		outFDC ((head<<2)|drive)<0 ||					// head (physical) & drive

		outFDC (track)<0 ||								// track (from ReadID)
		outFDC (side)<0 ||								// side (from ReadID)
		outFDC (sector)<0 ||								// sector to be read (1???)
		outFDC (BpS)<0 ||									// bps 6, 7 oder 8
		outFDC (1)<0 ||									// sectorsPerTrack
		outFDC (1)<0 ||									// readwriteGAP
		outFDC (128u)<0
		)return &RS;

	waitUntilInterrupt();

	return valid7ResultString(&RS)?NULL:&RS;
	}

#if 0
void LeerPista (unidad, mf_mfm, cilindro, cabezal, buffer, bytes, vunidad)
char      huge *buffer;
unsigned  *bytes;
{
  int      tsector;
  unsigned t;

  ventana (ABRIR, 23, 11, 58, 15, CL, CFL);
  clrscr();
  gotoxy (7, 2);
  if (sp) cputs("Leyendo pista cruda...");
    else cputs("Reading a raw track...");

  switch (TipoDrive(unidad)) {
    case 2:  if (vunidad==0) tsector = 7; else tsector = 6; break;
    case 5:  if (vunidad==3) tsector = 8;  /* sin break :-) */
    case 4:  if (vunidad==0) tsector = 7;
	     if ((vunidad==1) || (vunidad==2)) tsector = 6; break;
    case 1:
    case 3:
    default: tsector = 6; break;
    }

  for (t=0; t<SMAX; t+=2) {
    buffer[t]=0x5A; buffer[t+1]=0xA5;  /* "borrar" el buffer */
    }

  MotorOn (unidad);
  SeleccionarUnidad (unidad, vunidad);
  MotorOn (unidad);

  *bytes = 128u << tsector;  /* "sector" de 8K, 16K � 32K */

  PreparaDma (0x46, *bytes, buffer);

  outfdc (0x02 | mf_mfm << 6);     /* comando para leer pista */
  outfdc (cabezal << 2 | unidad);  /* byte 1 de dicho comando */
  outfdc (cilindro);
  outfdc (cabezal);
  outfdc (1);                      /* sector: cualquier valor valdr�a */
  outfdc (tsector);
  outfdc (1);                      /* 1 sector */
  outfdc (1);                      /* GAP para leer: poco importante */
  outfdc (128u);                    /* tama�o si tsector=0 */

  EsperarInt();                   /* esperar interrupci�n */

  ventana (CERRAR, 23, 11, 58, 15, 0, 0);

  Resultados (LEER, unidad, cabezal);
}


#endif

int main(int argc, char *argv[]){
	const char *BRStr[4]={"500","300","250","125/1000"};
	const char *MDStr[2]={"FM","MFM"};
   unsigned char BUF[33000L];

   unsigned char speed=0x00, MFM_FM=0x00;
   char *logfile, *flpp, *RawFN=NULL;
   uint i,f,b,t,s,rTr,rSd,rSc,rBs, lstSc, lstTr, lstSd, args=1, drive=0;
   FILE *fd, *frdata;
   unsigned long int startTSC, newTSC;
   resultString *res;

	for(t=1;t<argc;t++){
		if(argv[t]!=NULL){
			if((*argv[t]=='/' || *argv[t]=='-')){
				if(argv[t][2]=='\0'){		// arguments with no parameter
					switch(argv[t][1]){
// modulation=MFMFM;	// 0 - FM, 1 - MFM
						case 'f':		// select FM mode
						case 'F':
							MFM_FM|=0x01;
							break;
						case 'm':		// select MFM mode
						case 'M':
							MFM_FM|=0x02;
							break;
//	bitrate=BR;			// 0 - 500, 1 - 300, 2 - 250, 3 - 125
						case '1':		// select bitrate 125/1000
							speed|=0x08;
							break;
						case '2':		// select bitrate 250
							speed|=0x04;
							break;
						case '3':		// select bitrate 300
							speed|=0x02;
							break;
						case '5':		// select bitrate 500
							speed|=0x01;
							break;
						case 'd':		// Raw-Read data file
						case 'D':
                     if(argv[t][2]!=':' || argv[t][3]=='\0') args=0xffff;
							else RawFN=argv[t]+3;
							break;
						default:
							args=0xffff;
						}
					}
				else if(argv[t][2]==':'){	// arguments with parameter
					switch(argv[t][1]){
						case 'd':		// Raw-Read data file
						case 'D':
                     if(argv[t][3]!='\0'){
								RawFN=argv[t]+3;
                        break;
                     	}		// else break;!!!
						default:
							args=0xffff;
						}
					}
				else args=0xffff;
				}
			else{
				switch(args++){				// file name arguments
					case 1:
						flpp=argv[t];			// first non-parameter is the drive
						break;
					case 2:
						logfile=argv[t];		// second non-parameter is the logfile
						break;
               case 3:
						args=0xffff;
					}
				}
			}
		else args=0xffff;
		if(args>0x7fff) break;
		}

	if(MFM_FM<0x01 || MFM_FM>0x03) MFM_FM=0x02;	// select MFM, if no other parameters
	if(speed <0x01 || speed >0x0F) speed =0x0F;	// select all speeds, if no parameter

	printf(_1581COPY_version_ "\n");
   do{
	   if(args!=3 && args<0x8000){					// no image file needed
	      args=0xfffe;
		   printf("Error: Need the drive parameter and a filename for the logfile");
         break;
		   }
		   // convert and check flpp
	   if(flpp==NULL || flpp[1]!='\0'){
		   args=0xfffe;
         printf("Error: Floppy device parameter is wrong");
         break;
         }
	   else drive=*flpp-'0';
	   if((drive & ~0x01)!=0x00){		// only drives 0 and 1 are valid
		   args=0xfffe;
         printf("Error: Only floppy device parameter 0 and 1 are valid");
         break;
         }

      }while(0);
	if(args==0xfffe) printf("!\n\n");

	if(args>0x7fff){
		printf("DISKSCAN [/F][/M][/1][/2][/3][/5][/D:RAWFILE] DRIVE LOGFILE\n\n"
				 "DRIVE        - disk drive number 0 or 1\n"
				 "LOGFILE      - logfile file name\n"
				 "/M           - selects MFM modulation (default)\n"
				 "/F           - selects FM modulation\n"
				 "/1           - selects bitrate of 125 kbps or 1000 kbps (controller dependent)\n"
				 "/2           - selects bitrate of 250 kbps\n"
				 "/3           - selects bitrate of 300 kbps\n"
				 "/5           - selects bitrate of 500 kbps\n"
				 "/D:RAWFILE   - create a Raw-Mode-Read-Track dump file\n\n"
				 "Examples:      DISKSCAN /M /2 CBM_1581.DSC\n"
				 "               DISKSCAN /M /5 CMD_FD2M.DSC\n"
				 "               DISKSCAN /F /1 CPM_170K.DSC\n"
				 "               DISKSCAN /F /M /1 /2 /3 /5 UNKNOWN.DSC\n");
		return 0;
		}


	switchMotorOn(drive);

	fd=fopen(logfile,"w+b");
	if(fd==NULL){
		printf("File \"%s\" open error.\n",logfile);
		return 1;
		}
   if(RawFN!=NULL){
	   frdata=fopen(RawFN,"w+b");
	   if(frdata==NULL){
		   printf("File \"%s\" open error.\n",frdata);
		   return 1;
		   }
   	}

   for(f=0;f<2;f++){		// select FM and MFM
   	for(b=0;b<4;b++){ // select bitrates of 125/1000, 300, 250, 500 kbps
      	if(((1<<f)&MFM_FM) && ((1<<b)&speed)){
         	printf("Selecting modulation: %s and bitrate %s\n",MDStr[f],BRStr[b]);
				setDriveParameters(b, f);
				recalibrateDrive(drive,0);
            for(t=0;t<84;t++){
					seekToTrack(drive,t,0);
               for(s=0;s<2;s++){
               	printf("\rTrack %2d, side %d",t,s);
// Do the scan
						fprintf(fd,"Scanning: M %s,  BR %s kbps,  T %02u,  S %u ---------------\n",MDStr[f],BRStr[b],t,s);
                  lstSc=~0u;
						startTSC=read_tsc();
                  do{
                  	if(kbhit()){
				   	   	switch(getch()){
				  	   	      case 0x1B:
                           	recalibrateDrive(drive,0);
										switchMotorOff();
									   if(RawFN!=NULL) fclose(frdata);
									   fclose(fd);
                              printf("\nUser abort!\n");
										return 2;
				     	   		case 0x00:
										while(kbhit()) getch();	// eat up special combos
					         	}
                     	}
							res=readSectorID(drive,s,&rTr,&rSd,&rSc,&rBs);
                  	newTSC=read_tsc();
							if(res==NULL){
								fprintf(fd,"  Header found:  ticks: %10lu:  rTr:%2u:  rSd:%u:  rSc:%3u:  rBs:%3u\n",diff_TSC(startTSC, newTSC),rTr,rSd,rSc,rBs);
                        	// store header informations for possible raw-read
                        if(rSc<lstSc){
                        	lstSc=rSc;
                        	lstTr=rTr;
                           lstSd=rSd;
                        	}
                        }
                  	}while(diff_TSC(startTSC, newTSC)<0x50000L);	// search for 5/18 seconds
						// Do the raw read, if needed
                  if(RawFN!=NULL && lstSc!=~0u){
                  	for(i=0;i<sizeof(BUF);i++) BUF[i]=' ';
                     switch(b){	//	BRStr[4]={"500","300","250","125/1000"}
								case 0:	// 500
                        	i=7;
                           break;
								case 1:	// 300
								case 2:	// 250
                        	i=6;
                           break;
								case 3:	// 125/1000
                        	i=8;
                     	}
                     sprintf((char *)BUF,"RawRead: mod %3s, rate %8s, track %02u, side %1u, bytes %5u",
														 MDStr[f],BRStr[b],t,s,128u<<i);
//                     printf("RawRead: mod %3s, rate %8s, track %02u, side %1u, bytes %5u\n",
//														 MDStr[f],BRStr[b],t,s,128u<<i);
                     // Do Raw-Read to BUF+0x50
                     res=readRawTrack(drive,s,lstTr,lstSd,lstSc,i,BUF+0x50);
							if(res!=NULL){
                     	printf("  Error reading Raw-Track\n");
	                     sprintf((char *)BUF+0x40,"Error reading Raw-Track");
                        printResultString(res,BUF+0x80);
								}
                     // save up to 0x10*(((i+2)%3)+6)
                     i=(128u<<i)+0x10*(((i+2)%3)+6);
// printf("dumping 0x%04X bytes\n",i);
							if(fwrite(BUF,1,i,frdata)!=i){
                       	recalibrateDrive(drive,0);
								switchMotorOff();
							   fclose(frdata);
							   fclose(fd);
							   printf("File \"%s\" write error.\n",frdata);
								return 3;
								}
                  	}
               	}
            	}
				}
      	}
   	}
	recalibrateDrive(drive,0);
	switchMotorOff();
   if(RawFN!=NULL) fclose(frdata);
   fclose(fd);
	return 0;
	}

