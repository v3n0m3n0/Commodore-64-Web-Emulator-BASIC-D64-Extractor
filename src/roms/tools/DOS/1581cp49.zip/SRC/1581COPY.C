/*
 * Copyright (C) 1998 Wolfgang Moser
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING); if not, write to the
 * Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * Commodore CBM 1581 floppy disk copy util for PC's, 1581COPY.C
 *
 * Wolfgang Moser <womo@mindless.com>
 *   http://www.gm.fh-koeln.de/~womo (up to September 1999)
 *
 *
 * Basic informations from Dan Fandrich <dan@fch.wimsey.bc.ca>.
 *   His readme of the cbmfs-0.3 driver for Linux explained me, what the
 *   difference between a DOS formatted 800 kb disk and a CBM 1581 disk is.
 *   (check: http://vanbc.wimsey.com/~danf/software/)
 *
 *
 * Basic implementations by Ciriaco Garc�a de Celis <ciri@gui.uva.es>
 *   His util 765Debug, Version 5.0 is great for learning dma based
 *   direct floppy disk controller programming.
 *   (check: ftp://ftp.gui.uva.es/pub/pc/2m/765d50sr.zip)
 *
 * Check out for his floppy disk utils 2M and 2MGUI, the last words
 * in improving floppy disk storage capacity.
 *   http://www.gui.uva.es/2m, ftp://ftp.gui.uva.es/pub/pc/2m
 *
 *
 * For additional informations to FDC programming check:
 *     http://developer.intel.com/design/periphrl/datashts/290468.htm
 *   and get the intel 82078 CHMOS Single-Chip Floppy Disk Controller
 *   PDF document:
 *     http://www.intel.nl/design/periphrl/datashts/29047403.pdf
 */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "1581hlvl.h"

int main(int argc, char *argv[]){
	int i,res;
   uint8 t,s;	// track and side
   clock_t opStart;
	unsigned int args=1, earg=1, drive=0, format=0, writing=0,
	             MSecRead=0, tries=3, ileave=1, BAMcp=0, Multiple=0;
	xferM verify=0;
   unsigned char BAMmark[11];				// BAM copy track buffer (88 tracks)
	unsigned char buffer[TrBufSize];		// TrBufSize #defined in CENTRAL.H
	char *flpp=NULL, *file=NULL, *temp;
	FILE *fd;

	for(t=1;t<argc;t++){
		if(argv[t]!=NULL){
			if((*argv[t]=='/' || *argv[t]=='-')){
				if(argv[t][2]=='\0'){		// arguments with no parameter
					switch(argv[t][1]){
						case 'v':
						case 'V':
							verify=Verify;
							break;
						case 'f':
						case 'F':
							format=1;
							break;
						case 'm':
						case 'M':
							Multiple=1;
							break;
						case 'b':
						case 'B':
							BAMcp=1;
							break;
						case 'p':
						case 'P':
							MSecRead=1;
							break;
						default:
							args=0xffff;
						}
					}
				else if(argv[t][2]==':'){	// arguments with parameter
					switch(argv[t][1]){
						case 'f':
						case 'F':
							format=atoi(argv[t]+3);
							if(format<1 || format>2) args=0xffff;
							break;
						case 't':
						case 'T':
							tries=atoi(argv[t]+3);
							if(tries<1)	args=0xffff;
							break;
						case 'i':
						case 'I':
							ileave=atoi(argv[t]+3);
							if(ileave>9) args=0xffff;
							break;
						default:
							args=0xffff;
						}
					}
				else args=0xffff;
				}
			else{
         	earg++;
				switch(args++){				// file name arguments
					case 1:
						flpp=argv[t];
						break;
					case 2:
						file=argv[t];
					}
				}
			}
		else args=0xffff;
		if(args>3) break;
		}
	if(file!=NULL && file[0]!='\0' && file[1]==':' && file[2]=='\0') writing=1;

	if(writing){	// swap pointers
		temp=file;
		file=flpp;
		flpp=temp;
		}

   earg=(earg!=1);

	printf(_1581COPY_version_ "\n");
   do{
		   // convert and check flpp
	   if(flpp==NULL || flpp[1]!=':' || flpp[2]!='\0'){
		   args=0xfffe;
         if(earg) printf("Error: Floppy device parameter is wrong");
         break;
         }
		drive=*flpp-((*flpp>'Z')?'a':'A');
	   if((drive & ~0x01)!=0x00){		// only drives A and B are valid
		   args=0xfffe;
     	   if(earg) printf("Error: Only floppy device parameter A: and B: are valid");
        	break;
         }

	   if(!format || writing){
		   if(args!=3){
		      args=0xfffe;
            if(earg) printf("Error: Source and destination parameters are needed");
	         break;
            }
		   }
	   else if(args!=2){					// no image file needed
	      args=0xfffe;
		   if(earg) printf("Error: Formatting needs the floppy device parameter only");
         break;
		   }

      if(Multiple && writing){		// writing of multiple disks is not allowed
	      args=0xfffe;
         earg=1;
		   printf("Error: When using multiple disks, writing is not allowed");
         break;
   	   }
      if(verify && !writing && !format){
	      args=0xfffe;
         earg=1;
		   printf("Error: Verify cannot be used with read operations");
         break;
      	}
      }while(0);
	if(args==0xfffe && earg) printf("!\n\n");

	if(args>3){
		printf("1581COPY [/F[:x]][/V][/B][/M][/P][/I:n][/T:nnn] [SOURCE] DESTINATION\n\n"
				 "SOURCE       - select floppy drive A: or B: or image file name\n"
				 "DESTINATION  - select image file name or floppy drives A: or B:\n\n"
				 "/F[:x]       - format before writing, no source needed, if formatting only\n"
				 "    x        - select desired format (2 - CMD FD 2000, default: 1 - CBM 1581)\n"
				 "/V           - select verify mode\n\n"
				 "/B           - use BAM copy, only transfer tracks with allocated sectors\n"
				 "/M           - use multiple disks, when reading or formatting only\n"
				 "/P           - use \"read/write multiple sectors\" FDC feature\n"
				 "/I:n         - interleave for higher speed on slow FDCs (0...9, default 1)\n"
				 "/T:nnn       - number of retries (> 0, default 3)\n\n"
				 "Examples:      1581COPY      A: 1581IMG.D81\n"
				 "               1581COPY /F   A:\n"
				 "               1581COPY      TESTDISK.D81 B:\n"
				 "               1581COPY /F:2 NEWDISK.D2M  A:\n");
		return 0;
		}

	CBMrecalibrate(drive);

	printf("Using %d retries on each operation on drive %c:, interleave: %d, verify: %s\n\n", tries, 'A'+drive, ileave, verify?"on":"off");

	if(format){
   		// fill buffer with format pattern for verifying
		if(verify) for(args=0;args<sizeof(buffer);args++) buffer[args]=FDprm.Pattern;

		CBMpresetFDprm(drive,format-1);

		printf("Low-Level-Formatting ");
      switch(format){
      	case 1:
         	printf("CBM 1581");
            break;
         case 2:
         	printf("CMD FD2000");
            break;
         default:
         	printf("unknown???");
      	}
		printf(" disk in drive %c:\n\n", 'A'+drive);
// 		if(Multiple && !waitForDisk(drive, 0)){
 		if(!waitForDiskChng(drive, 0)){
				// user abort while waiting for the first disk
      	printf("User abort.\n");
			CBMrecalibrate(drive);
			switchMotorOff();
			return 2;
			}
      do{
      	opStart=clock();
		   for(t=1;t<=FDprm.Cylinders;t++) for(s=0;s<FDprm.Heads;s++){
			   res=CBMfmTrack(drive,t,s,tries);

			   if(!writing && verify && res>0){
					if(!MSecRead || !(res=CBMxferTrackMS(Verify,drive,t,s,buffer,ileave,tries))){
						res=CBMxferTrackSS(Verify,drive,t,s,buffer,ileave,tries);
            	   }
            	}

            if(res<0){
         	   printf("User abort.\n");
				   CBMrecalibrate(drive);
				   switchMotorOff();
				   return 2;
         	   }
			   }
		   if(!writing){
         	if(format==1){
			      printf("Writing 1581 default BAM to disk in drive %c:\n", 'A'+drive);

			      for(args=0;args<sizeof(buffer);args++) buffer[args]=0;
			      C1581createBAM(buffer);

			      if(!MSecRead || !(res=CBMxferTrackMS(Write|verify,drive,40,0,buffer,ileave,tries))){
					   res=CBMxferTrackSS(Write|verify,drive,40,0,buffer,ileave,tries);
                  }
               if(res<0){
         	      printf("User abort.\n");
				      CBMrecalibrate(drive);
				      switchMotorOff();
				      return 2;
         	      }
   				}
   			else{	// unsupported format, can't write a default BAM
            	printf("Writing a default BAM to this disk type is not supported yet.\n");
            	}
            }
			printf("Time needed for formatting the last disk: %ld ms\n\n",
					 (10000L*(long)(clock()-opStart))/182);
   		}while(Multiple && waitForDiskChng(drive, 1));
		}

	if(!format || writing){		// convert and check file, too
	   printf("Low-Level-%s 1581 disk in drive %c:\n\n", writing?"Writing":"Reading", 'A'+drive);
// 		if(Multiple && !waitForDisk(drive, 0)){
 		if(!waitForDiskChng(drive, 0)){
				// user abort while waiting for the first disk
      	printf("User abort.\n");
		   CBMrecalibrate(drive);
			switchMotorOff();
			return 2;
			}
   	do{
			// check source and destination formats
         do{
				if((res=CBMcheckDisk(drive))<FDUNKNW){
	            printf("\nWrong drive type detected, this is no 3,5\" floppy, aborting.\n");
				   CBMrecalibrate(drive);
			      switchMotorOff();
			      return 2;
            	}
            if(res>FDUNKNW){	// CBM media detected in disk drive
            	if(writing){	// search for compatible source image
						t=0;
                  s=1;
                  for(i=FDUNKNW;i<FDUNDEF;i++){
                  	temp=changeExtension(file,i);
			            fd=fopen(temp,"r+b");

/* file name extension generation check should be done!
                  if(file==NULL){	// new name cannot be generated
				      	printf("Filename extension generation error.\n");
							CBMrecalibrate(drive);
						   switchMotorOff();
				   	   return 1;
                  	}
*/
                     if(fd!=NULL){					// file found
                     	t=1;
         	            fseek(fd,0L,SEEK_END);
                        switch(ftell(fd)){
            	            case  819200L:			// CBM 1581
                              s=2;					// CBM compatible file found
               	            if(res==CBM1581) s=0;
                              break;
            	            case 1658880L:			// CMD FD2000
                              s=2;					// CBM compatible file found
               	            if(res==CMDFD2M) s=0;
            	            }
			               fseek(fd,0L,SEEK_SET);	// seek to Track 01;00
                        if(!s) break;	// let the file open
						      fclose(fd);
                        }
                  	}
                  if(!s){
                     file=temp;
							break;			// let the file open (match)
                     }
                  if(s==1){
                  	if(!t) printf("File \"%s\" open error.\n",file);
							else printf("No CBM compatible disk images found.");
						   CBMrecalibrate(drive);
					      switchMotorOff();
		   	         return 1;
                  	}
                 	printf("No matching disk and image media types found. ");
               	}
               else{				// change extension to default
                  file=changeExtension(file,res);
						if(file==NULL){	// new name cannot be generated
				      	printf("Filename extension generation error.\n");
							CBMrecalibrate(drive);
						   switchMotorOff();
				   	   return 1;
                  	}
			         if(Multiple){				// generate new filename, if needed
                     do{
		                  fd=fopen(file,"rb");
                           // if reading disk, file mustn't exist
					         if(fd==NULL) break;	// new filename found
					         fclose(fd);
               	         // generate new filename
					         file=buildInxName(file);
                        if(file==NULL){	// new name cannot be generated
				               printf("Filename generation error.\n");
							      CBMrecalibrate(drive);
						         switchMotorOff();
				   	         return 1;
                  	      }
            	         }while(1);
         	         }
	               fd=fopen(file,"w+b");
	               if(fd==NULL){
		               printf("File \"%s\" open error.\n",file);
		               return 1;
		               }
                  break;
               	}
            	}
            else printf("CBM incompatible disk media type detected. ");
            res=FDUNKNW;
         	}while(waitForDiskChng(drive, 1));
         if(res==FDUNKNW){	// user break;
					// user abort while waiting for a new disk
				CBMrecalibrate(drive);
			   switchMotorOff();
			   fclose(fd);
			   return 2;
            }

         printf("Transferring ");
         switch(res){
         	case CBM1581:
            	printf("CBM 1581");
               break;
            case CMDFD2M:
            	printf("CMD FD2000");
         	}
			printf(" disk from ");
         if(writing) printf("image \"%s\" to drive %c:\n",file,'A'+drive);
         else        printf("drive %c: to image \"%s\"\n",'A'+drive,file);

         // presetting disk parameter table
         CBMpresetFDprm(drive,res);

			opStart=clock();
         if(BAMcp){
         	if(res==CBM1581){
      	      printf("Reading BAM from source disk/image\n");
               if(writing){	// reading BAM from file
				      fseek(fd, 0x61800L, SEEK_SET);	// seek to Track 40;00
               	   // BAM copy is only supported for CBM 1581 compatible disks
                     // buffer length needed: 0x400
				      if(fread(buffer,1,0x400,fd)!=0x400){
					      printf("File reading error.");
					      CBMrecalibrate(drive);
					      switchMotorOff();
					      fclose(fd);
					      return 1;
					      }
				      fseek(fd, 0x0L, SEEK_SET);		// seek to Track 01;00
         	      }
               else{

				      if(!MSecRead || !(res=CBMxferTrackMS(Read,drive,40,0,buffer,ileave,tries))){
               	   res=CBMxferTrackSS(Read,drive,40,0,buffer,ileave,tries);
      	            }
			         if(res<=0){
         	         if(res<0) printf("User abort.\n");
                     else printf("Error while reading the BAM from disk.\n");
					      CBMrecalibrate(drive);
				         switchMotorOff();
				         fclose(fd);
				         return 2;
				         }
         	      }
               for(t=0;t<11;t++) BAMmark[t]=0;
         	      // Analyze buffer and get tracks to be copied
               for(t=0,args=0x110;t<40;t++,args+=6) if(buffer[args]!=0x28) BAMmark[t>>3]|=1<<(t&0x07);
               for(args=0x210;t<80;t++,args+=6) if(buffer[args]!=0x28) BAMmark[t>>3]|=1<<(t&0x07);
#if (MESSAGES >= 1)
               printf("Bitmask for BAM-Copy (80...01): 0x");
               for(t=9;t<9;t--) printf("%02X",BAMmark[t]);
               printf("\n");
#endif
   				}
				else{
            	printf("BAM copying of this disk type is not supported yet.\n");
               for(t=0;t<11;t++) BAMmark[t]=0xFF;
               }
      	   }

		   for(t=1;t<=FDprm.Cylinders;t++) for(s=0;s<FDprm.Heads;s++){
			   if(writing){
				   if(fread(buffer,1,FDprm.Sectors*(128u << FDprm.BpS),fd)!=
				   						FDprm.Sectors*(128u << FDprm.BpS)){
					   printf("File reading error.");
					   CBMrecalibrate(drive);
					   switchMotorOff();
					   fclose(fd);
					   return 1;
					   }
				   }
			   else{	// clear buffer, if there's a sector not readable,
					   // 0x00 is written into the image file
				   for(args=0;args<sizeof(buffer);args++) buffer[args]=0;
				   }
			   if(!BAMcp || BAMmark[(t-1)>>3]&(1<<((t-1)&0x07))){
#if (MESSAGES >= 1)
         	   if(BAMcp) printf("BAM copying track %2d\n",t);
#endif
					if(writing){
					   if(!MSecRead || !(res=CBMxferTrackMS(Write|verify,drive,t,s,buffer,ileave,tries))){
							res=CBMxferTrackSS(Write|verify,drive,t,s,buffer,ileave,tries);
            		   }
               	}
               else{
					   if(!MSecRead || !(res=CBMxferTrackMS(Read,drive,t,s,buffer,ileave,tries))){
							res=CBMxferTrackSS(Read,drive,t,s,buffer,ileave,tries);
            		   }
               	}
               if(res<0){
         	      printf("User abort.\n");
					   CBMrecalibrate(drive);
				      switchMotorOff();
				      if(!writing){
						   if(fwrite(buffer,1,FDprm.Sectors*(128u << FDprm.BpS),fd)!=
						   						 FDprm.Sectors*(128u << FDprm.BpS)){
						      printf("File writing error.");
						      }
					      }
				      fclose(fd);
				      return 2;
         	      }
   			   }

			   if(!writing){
				   if(fwrite(buffer,1,FDprm.Sectors*(128u << FDprm.BpS),fd)!=
				   						 FDprm.Sectors*(128u << FDprm.BpS)){
					   printf("File writing error.");
					   CBMrecalibrate(drive);
					   switchMotorOff();
					   fclose(fd);
					   return 1;
					   }
				   }
			   }
		   fclose(fd);
			printf("Time needed for transferring the last disk: %ld ms\n\n",
					 (10000L*(long)(clock()-opStart))/182);
   		}while(Multiple && waitForDiskChng(drive, 1));
		}
   CBMrecalibrate(drive);
	switchMotorOff();
	return 0;
/*
fderr:
	return 1;
abort:
error:
	return 2;
*/
	}

