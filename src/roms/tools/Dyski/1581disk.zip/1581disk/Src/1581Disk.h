#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <stdlib.h>

#include "fdrawcmd.h"       // from http://simonowen.com/fdrawcmd/fdrawcmd.h
