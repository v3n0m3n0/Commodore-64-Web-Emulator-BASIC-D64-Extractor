***********************************************************************
*                                                                     *
* iec.i -- definitions and iec.library base                           *
*                                                                     *
* Copyright (C) 1996 Fabrizio Farenga.  All rights reserved.          *
*                    Email: f.farenga@agora.stm.it                    *
*                                                                     *
***********************************************************************

   IFND  IEC_IECBASE
IEC_IECBASE SET 1


   IFND  EXEC_TYPES_I
   INCLUDE  "exec/types.i"
   ENDC   ; EXEC_TYPES_I

   IFND  EXEC_LISTS_I
   INCLUDE  "exec/lists.i"
   ENDC   ; EXEC_LISTS_I

   IFND  EXEC_LIBRARIES_I
   INCLUDE  "exec/libraries.i"
   ENDC   ; EXEC_LIBRARIES_I


;STATUS values for the last input/output operations.
ST_OK           EQU $00  ;OK
ST_READ_TIMEOUT EQU $02  ;Timeout reading
ST_TIMEOUT      EQU $03  ;Timeout
ST_EOF          EQU $40  ;End of file
ST_NOTPRESENT   EQU $80  ;Device not present
 
;Low-Level commands for the 1541
CMD_DATA        EQU $60
CMD_CLOSE       EQU $e0
CMD_OPEN        EQU $f0

;-----------------------------------------------------------------------
;
; library data structures
;
;-----------------------------------------------------------------------

;  Note that the library base begins with a library node

   STRUCTURE IECBase,LIB_SIZE
   ULONG   iec_SysLib
   ULONG   iec_DosLib
   ULONG   iec_SegList

   UBYTE   iec_ST		;Drive STATUS
   UBYTE   iec_pad
   LABEL   IECBase_SIZEOF


IEC_NAME   MACRO
      DC.B   'iec.library',0
      ENDM

   ENDC  ;IEC_IEC_I
