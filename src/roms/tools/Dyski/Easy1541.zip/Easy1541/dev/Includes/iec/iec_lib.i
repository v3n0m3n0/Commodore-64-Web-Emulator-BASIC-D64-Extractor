_LVOListen   EQU -30
_LVOUnListen EQU -36
_LVOTalk     EQU -42
_LVOUnTalk   EQU -48
_LVOSecond   EQU -54
_LVOTkSA     EQU -60
_LVOCIOut    EQU -66
_LVOACPtr    EQU -72
