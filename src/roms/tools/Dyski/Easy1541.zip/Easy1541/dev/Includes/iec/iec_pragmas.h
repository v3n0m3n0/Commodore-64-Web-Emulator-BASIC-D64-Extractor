#pragma libcall IECBase Listen 1e 001
#pragma libcall IECBase UnListen 24 0
#pragma libcall IECBase Talk 2a 001
#pragma libcall IECBase UnTalk 30 0
#pragma libcall IECBase Second 36 001
#pragma libcall IECBase TkSA 3c 001
#pragma libcall IECBase CIOut 42 001
#pragma libcall IECBase ACPtr 48 0
