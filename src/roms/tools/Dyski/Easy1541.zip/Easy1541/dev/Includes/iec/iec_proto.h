void Listen(UBYTE);
void UnListen(void);
void Talk(UBYTE);
void UnTalk(void);
void Second(UBYTE);
void TkSA(UBYTE);
void CIOut(UBYTE);
LONG ACPtr(void);
