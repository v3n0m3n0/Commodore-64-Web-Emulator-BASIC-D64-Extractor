using PaintDotNet.SystemLayer;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace PaintDotNet
{
    /// <summary>
    /// Provides a set of standard UnaryPixelOps.
    /// </summary>
    public sealed class UnaryPixelOps
    {
        private UnaryPixelOps()
        {
        }

        /// <summary>
        /// Passes through the given color value.
        /// result(color) = color
        /// </summary>
        [Serializable]
        public class Identity
            : UnaryPixelOp
        {
            public override ColorBgra Apply(ColorBgra color)
            {
                return color;
            }

            [CLSCompliant(false)]
            protected unsafe override void Apply(ColorBgra *dst, ColorBgra *src, int length)
            {
                Memory.Copy(dst, src, (ulong)length * (ulong)sizeof(ColorBgra));
            }

            [CLSCompliant(false)]
            protected unsafe override void Apply(ColorBgra *ptr, int length)
            {
                return;
            }
        }

        /// <summary>
        /// Always returns a constant color.
        /// </summary>
        [Serializable]
        public class Constant
            : UnaryPixelOp
        {
            private ColorBgra setColor;

            public override ColorBgra Apply(ColorBgra color)
            {
                return setColor;
            }

            [CLSCompliant(false)]
            protected unsafe override void Apply(ColorBgra *dst, ColorBgra *src, int length)
            {
                while (length > 0)
                {
                    *dst = setColor;
                    ++dst;
                    --length;
                }
            }

            [CLSCompliant(false)]
            protected unsafe override void Apply(ColorBgra *ptr, int length)
            {
                while (length > 0)
                {
                    *ptr = setColor;
                    ++ptr;
                    --length;
                }
            }

            public Constant(ColorBgra setColor)
            {
                this.setColor = setColor;
            }
        }

        /// <summary>
        /// Blends pixels with the specified constant color.
        /// </summary>
        [Serializable]
        public class BlendConstant
            : UnaryPixelOp
        {
            private ColorBgra blendColor;

            public override ColorBgra Apply(ColorBgra color)
            {
                int a = blendColor.A;
                int invA = 255 - a;

                int r = ((color.R * invA) + (blendColor.R * a)) / 256;
                int g = ((color.G * invA) + (blendColor.G * a)) / 256;
                int b = ((color.B * invA) + (blendColor.B * a)) / 256;
                byte a2 = ComputeAlpha(color.A, blendColor.A);

                return ColorBgra.FromBgra((byte)b, (byte)g, (byte)r, a2);
            }

            public BlendConstant(ColorBgra blendColor)
            {
                this.blendColor = blendColor;
            }
        }

        /// <summary>
        /// Used to set a given channel of a pixel to a given, predefined color.
        /// Useful if you want to set only the alpha value of a given region.
        /// </summary>
        [Serializable]
        public class SetChannel
            : UnaryPixelOp
        {
            private int channel;
            private byte setValue;

            public override ColorBgra Apply(ColorBgra color)
            {
                color[channel] = setValue;
                return color;
            }

            [CLSCompliant(false)]
            protected override unsafe void Apply(ColorBgra * dst, ColorBgra * src, int length)
            {
                while (length > 0)
                {
                    *dst = *src;
                    (*dst)[channel] = setValue;
                    ++dst;
                    ++src;
                    --length;
                }
            }

            [CLSCompliant(false)]
            protected override unsafe void Apply(ColorBgra * ptr, int length)
            {
                while (length > 0)
                {
                    (*ptr)[channel] = setValue;
                    ++ptr;
                    --length;
                }
            }


            public SetChannel(int channel, byte setValue)
            {
                this.channel = channel;
                this.setValue = setValue;
            }
        }

        /// <summary>
        /// Specialization of SetChannel that sets the alpha channel.
        /// </summary>
        /// <remarks>This class depends on the system being litte-endian with the alpha channel 
        /// occupying the 8 most-significant-bits of a ColorBgra instance.
        /// By the way, we use addition instead of bitwise-OR because an addition can be
        /// perform very fast (0.5 cycles) on a Pentium 4.</remarks>
        [Serializable]
        public class SetAlphaChannel
            : UnaryPixelOp
        {
            private UInt32 addValue;

            public override ColorBgra Apply(ColorBgra color)
            {
                return ColorBgra.FromUInt32((color.Bgra & 0x00ffffff) + addValue);
            }

            [CLSCompliant(false)]
            protected override unsafe void Apply(ColorBgra * dst, ColorBgra * src, int length)
            {
                while (length > 0)
                {
                    dst->Bgra = (src->Bgra & 0x00ffffff) + addValue;
                    ++dst;
                    ++src;
                    --length;
                }
            }

            [CLSCompliant(false)]
            protected override unsafe void Apply(ColorBgra * ptr, int length)
            {
                while (length > 0)
                {
                    ptr->Bgra = (ptr->Bgra & 0x00ffffff) + addValue;
                    ++ptr;
                    --length;
                }
            }

            public SetAlphaChannel(byte alphaValue)
            {
                addValue = (uint)alphaValue << 24;
            }
        }

        /// <summary>
        /// Specialization of SetAlphaChannel that always sets alpha to 255.
        /// </summary>
        [Serializable]
        public class SetAlphaChannelTo255
            : UnaryPixelOp
        {
            public override ColorBgra Apply(ColorBgra color)
            {
                return ColorBgra.FromUInt32(color.Bgra | 0xff000000);
            }

            [CLSCompliant(false)]
            protected override unsafe void Apply(ColorBgra * dst, ColorBgra * src, int length)
            {
                while (length > 0)
                {
                    dst->Bgra = src->Bgra | 0xff000000;
                    ++dst;
                    ++src;
                    --length;
                }
            }

            [CLSCompliant(false)]
            protected override unsafe void Apply(ColorBgra * ptr, int length)
            {
                while (length > 0)
                {
                    ptr->Bgra |= 0xff000000;
                    ++ptr;
                    --length;
                }
            }
        }

        /// <summary>
        /// Inverts a pixel's color, and passes through the alpha component.
        /// </summary>
        [Serializable]
        public class Invert
            : UnaryPixelOp
        {
            public override ColorBgra Apply(ColorBgra color)
            {
                return ColorBgra.FromBgra((byte)(255 - color.B), (byte)(255 - color.G), (byte)(255 - color.R), color.A);
            }
        }

        /// <summary>
        /// If the color is within the red tolerance, remove it
        /// </summary>
        [Serializable]
        public class RedEyeRemove
            : UnaryPixelOp
        {
            private int tolerence;
            private double setSaturation;

            public RedEyeRemove(int tol, int sat)
            {
                tolerence = tol;
                setSaturation = (double)sat / 100;
            }

            public override ColorBgra Apply(ColorBgra color)
            {
                // The higher the saturation, the more red it is
                int saturation = GetSaturation(color);
                // The higher the difference between the other colors, the more red it is
                int difference = color.R - Math.Max(color.B,color.G);

                // If it is within tolerence, and the saturation is high
                if ((difference > tolerence) && (saturation > 100)) 
                {
                    double i = 255.0 * color.GetIntensity();
                    byte ib = (byte)(i * setSaturation); // adjust the red color for user inputted saturation
                    return ColorBgra.FromBgra((byte)color.B,(byte)color.G, ib, color.A);
                }
                else
                {
                    return color;
                }
            }

            //Saturation formula from RgbColor.cs, public HsvColor ToHsv()
            private int GetSaturation(ColorBgra color)
            {
                double min;
                double max;
                double delta;

                double r = (double) color.R / 255;
                double g = (double) color.G / 255;
                double b = (double) color.B / 255;

                double s;

                min = Math.Min(Math.Min(r, g), b);
                max = Math.Max(Math.Max(r, g), b);
                delta = max - min;

                if (max == 0 || delta == 0) 
                {
                    // R, G, and B must be 0, or all the same.
                    // In this case, S is 0, and H is undefined.
                    // Using H = 0 is as good as any...
                    s = 0;
                } 
                else
                {
                    s = delta / max;
                }

                return (int)(s * 255);
            }               
        }

        /// <summary>
        /// Inverts a pixel's color and its alpha component.
        /// </summary>
        [Serializable]
        public class InvertWithAlpha
            : UnaryPixelOp
        {
            public override ColorBgra Apply(ColorBgra color)
            {
                return ColorBgra.FromBgra((byte)(255 - color.B), (byte)(255 - color.G), (byte)(255 - color.R), (byte)(255 - color.A));
            }
        }

        /// <summary>
        /// Averages the input color's red, green, and blue channels. The alpha component
        /// is unaffected.
        /// </summary>
        [Serializable]
        public class AverageChannels
            : UnaryPixelOp
        {
            public override ColorBgra Apply(ColorBgra color)
            {
                byte average = (byte)(((int)color.R + (int)color.G + (int)color.B) / 3);
                return ColorBgra.FromBgra(average, average, average, color.A);
            }
        }

        [Serializable]
        public class Desaturate
            : UnaryPixelOp
        {
            // These numbers taken from http://www.codeproject.com/cs/media/csharpgraphicfilters11.asp
            public override ColorBgra Apply(ColorBgra color)
            {
                byte i = color.GetIntensityByte();
                return ColorBgra.FromBgra(i, i, i, color.A);
            }

            [CLSCompliant(false)]
            protected unsafe override void Apply(ColorBgra * ptr, int length)
            {
                while (length > 0)
                {
                    byte i = ptr->GetIntensityByte();

                    ptr->R = i;
                    ptr->G = i;
                    ptr->B = i;

                    ++ptr;
                    --length;
                }
            }

            [CLSCompliant(false)]
            protected unsafe override void Apply(ColorBgra * dst, ColorBgra * src, int length)
            {
                while (length > 0)
                {
                    byte i = src->GetIntensityByte();

                    dst->B = i;
                    dst->G = i;
                    dst->R = i;
                    dst->A = src->A;

                    ++dst;
                    ++src;
                    --length;
                }
            }
        }

        [Serializable]
        public class Level
            : UnaryPixelOp, ICloneable
        {

            private ColorBgra colorInLow;
            public ColorBgra ColorInLow 
            {
                get 
                {
                    return colorInLow; 
                }

                set 
                {
                    if (value.R == 255) 
                    {
                        value.R = 254;
                    }
                    if (value.G == 255)
                    {
                        value.G = 254;
                    }
                    if (value.B == 255)
                    {
                        value.B = 254;
                    }
                    if (colorInHigh.R < value.R + 1) 
                    {
                        colorInHigh.R = (byte)(value.R + 1);
                    }
                    if (colorInHigh.G < value.G + 1) 
                    {
                        colorInHigh.G = (byte)(value.R + 1);
                    }
                    if (colorInHigh.B < value.B + 1) 
                    {
                        colorInHigh.B = (byte)(value.R + 1);
                    }
                    colorInLow = value;
                    UpdateLookupTable();
                }
            }

            private ColorBgra colorInHigh;
            public ColorBgra ColorInHigh 
            {
                get 
                {
                    return colorInHigh;
                }

                set 
                {
                    if (value.R == 0) 
                    {
                        value.R = 1;
                    }
                    if (value.G == 0)
                    { 
                        value.G = 1;
                    }
                    if (value.B == 0)
                    {
                        value.B = 1;
                    }
                    if (colorInLow.R > value.R - 1) 
                    {
                        colorInLow.R = (byte)(value.R - 1);
                    }
                    if (colorInLow.G > value.G - 1) 
                    {
                        colorInLow.G = (byte)(value.R - 1);
                    }
                    if (colorInLow.B > value.B - 1) 
                    {
                        colorInLow.B = (byte)(value.R - 1);
                    }
                    colorInHigh = value;
                    UpdateLookupTable();
                }
            }

            private ColorBgra colorOutLow;
            public ColorBgra ColorOutLow 
            {
                get 
                {
                    return colorOutLow;
                }
                set 
                {
                    if (value.R == 255) 
                    {
                        value.R = 254;
                    }
                    if (value.G == 255)
                    {
                        value.G = 254;
                    }
                    if (value.B == 255)
                    {
                        value.B = 254;
                    }
                    if (colorOutHigh.R < value.R + 1) 
                    {
                        colorOutHigh.R = (byte)(value.R + 1);
                    }
                    if (colorOutHigh.G < value.G + 1) 
                    {
                        colorOutHigh.G = (byte)(value.G + 1);
                    }
                    if (colorOutHigh.B < value.B + 1) 
                    {
                        colorOutHigh.B = (byte)(value.B + 1);
                    }
                    colorOutLow = value;
                    UpdateLookupTable();
                }
            }

            private ColorBgra colorOutHigh;
            public ColorBgra ColorOutHigh 
            {
                get 
                {
                    return colorOutHigh;
                }
                set 
                {
                    if (value.R == 0) 
                    {
                        value.R = 1;
                    }
                    if (value.G == 0)
                    { 
                        value.G = 1;
                    }
                    if (value.B == 0)
                    {
                        value.B = 1;
                    }
                    if (colorOutLow.R > value.R - 1) 
                    {
                        colorOutLow.R = (byte)(value.R - 1);
                    }
                    if (colorOutLow.G > value.G - 1) 
                    {
                        colorOutLow.G = (byte)(value.G - 1);
                    }
                    if (colorOutLow.B > value.B - 1) 
                    {
                        colorOutLow.B = (byte)(value.B - 1);
                    }
                    colorOutHigh = value;
                    UpdateLookupTable();
                }       
            }               
                        
            private float [] gamma = new float[3];
            public float GetGamma(int index) 
            {               
                if (index < 0 || index >= 3) 
                {
                    throw new ArgumentOutOfRangeException("index", index, "Index must be between 0 and 2");
                }
                return gamma[index];
            }

            public void SetGamma(int index, float val) 
            {
                if (index < 0 || index >= 3) 
                {
                    throw new ArgumentOutOfRangeException("index", index, "Index must be between 0 and 2");
                }
                gamma[index] = Utility.Clamp(val, 0.1f, 10.0f);
                UpdateLookupTable();
            }

            byte [] lookupR;
            byte [] lookupG;
            byte [] lookupB;
            byte [] lookupA;
            public bool isValid = true;

            public static Level AutoFromLoMdHi(ColorBgra lo, ColorBgra md, ColorBgra hi) 
            {
                float [] gamma = new float[3];

                for (int i = 0; i < 3; i++)
                {
                    if (lo[i] < md[i] && md[i] < hi[i])
                    {
                        gamma[i] = (float)Utility.Clamp(Math.Log(0.5, (float)(md[i] - lo[i]) / (float)(hi[i] - lo[i])), 0.1, 10.0);
                    }
                    else
                    {
                        gamma[i] = 1.0f;
                    }
                }

                return new Level(lo, hi, gamma, ColorBgra.FromColor(Color.Black), ColorBgra.FromColor(Color.White));
            }

            private void UpdateLookupTable() 
            {
                lookupB = new byte[256];
                lookupG = new byte[256];
                lookupR = new byte[256];
                lookupA = new byte[256];

                for (int i = 0; i < 3; i++) 
                {
                    if (colorOutHigh[i] < colorOutLow[i] ||
                        colorInHigh[i] <= colorInLow[i] ||
                        gamma[i] < 0)
                    {
                        isValid = false;
                        return;
                    }

                    for (int j = 0; j < 256; j++) 
                    {
                        ColorBgra col = Apply(j, j, j);
                        lookupR[j] = col.R;
                        lookupG[j] = col.G;
                        lookupB[j] = col.B;
                        lookupA[j] = (byte)j; // TODO: if this is the identity function, why do we even have this lookup table?
                    }
                }
            }

            public Level() 
                : this(ColorBgra.FromColor(Color.Black),
                       ColorBgra.FromColor(Color.White),
                       new float []{1, 1, 1},
                       ColorBgra.FromColor(Color.Black),
                       ColorBgra.FromColor(Color.White))
            {
            }

            public Level(ColorBgra in_lo, ColorBgra in_hi, float [] gamma, ColorBgra out_lo, ColorBgra out_hi)
            {
                colorInLow = in_lo;
                colorInHigh = in_hi;
                colorOutLow = out_lo;
                colorOutHigh = out_hi;

                if (gamma.Length != 3) 
                {
                    throw new ArgumentException("gamma", "gamma must be a float[3]");
                }

                this.gamma = gamma;
                UpdateLookupTable();
            }

            public ColorBgra Apply(float r, float g, float b) 
            {
                ColorBgra ret = new ColorBgra();
                float [] input = new float[]{b, g, r};

                for (int i = 0; i < 3; i++) 
                {
                    float v = (input[i] - colorInLow[i]);
                    if (v < 0)
                    {
                        ret[i] = colorOutLow[i];
                    }
                    else if (v + colorInLow[i] >= colorInHigh[i])
                    {
                        ret[i] = colorOutHigh[i];
                    }
                    else
                    {
                        ret[i] = (byte)Utility.Clamp(
                            colorOutLow[i] + (colorOutHigh[i] - colorOutLow[i]) * Math.Pow(v / (colorInHigh[i] - colorInLow[i]), gamma[i]),
                            0.0f,
                            255.0f);
                    }
                }
                return ret;
            }

            public void UnApply(ColorBgra after, float [] before, float [] slopes) 
            {
                if (before.Length != 3) 
                {
                    throw new ArgumentException("before must be a float[3]", "before");
                }

                if (slopes.Length != 3) 
                {
                    throw new ArgumentException("slopes must be a float[3]", "slopes");
                }

                for (int i = 0; i < 3; i++) 
                {
                    before[i] = colorInLow[i] + (colorInHigh[i] - colorInLow[i]) *
                        (float)Math.Pow((float)(after[i] - colorOutLow[i]) / (colorOutHigh[i] - colorOutLow[i]), 1 / gamma[i]);

                    slopes[i] = (float)(colorInHigh[i] - colorInLow[i]) / ((colorOutHigh[i] - colorOutLow[i]) * gamma[i]) *
                        (float)Math.Pow((float)(after[i] - colorOutLow[i]) / (colorOutHigh[i] - colorOutLow[i]), 1 / gamma[i] - 1);

                    if (float.IsInfinity(slopes[i]) || float.IsNaN(slopes[i])) 
                    {
                        slopes[i] = 0;
                    }
                }
            }

            public override ColorBgra Apply(ColorBgra color)
            {
                ColorBgra ret = new ColorBgra();
            
                ret.R = lookupR[color.R];
                ret.G = lookupG[color.G];
                ret.B = lookupB[color.B];
                ret.A = lookupA[color.A];

                return ret;
            }

            public object Clone()
            {
                return new Level(colorInLow, colorInHigh, (float[])gamma.Clone(), colorOutLow, colorOutHigh);
            }
        }

        [Serializable]
        public class HueSaturationLightness
            : UnaryPixelOp
        {
            private int hueDelta;
            private int satFactor;
            private UnaryPixelOp blendOp;

            public HueSaturationLightness(int hueDelta, int satDelta, int lightness)
            {
                this.hueDelta = hueDelta;
                this.satFactor = (satDelta * 1024) / 100;

                if (lightness == 0)
                {
                    blendOp = new UnaryPixelOps.Identity();
                }
                else
                if (lightness > 0)
                {
                    blendOp = new UnaryPixelOps.BlendConstant(ColorBgra.FromBgra(255, 255, 255, (byte)((lightness * 255) / 100)));
                }
                else // if (lightness < 0)
                {
                    blendOp = new UnaryPixelOps.BlendConstant(ColorBgra.FromBgra(0, 0, 0, (byte)((-lightness * 255) / 100)));
                }
            }

            public override ColorBgra Apply(ColorBgra color)
            {
                HsvColor hsvColor = HsvColor.FromColor(color.ToColor());
                int hue = hsvColor.Hue;
                int sat = hsvColor.Saturation;

                hue += hueDelta;

                sat = sat * satFactor / 1024;

                if (sat > 100)
                {
                    sat = 100;
                }

                while (hue < 0)
                {
                    hue += 360;
                }
                        
                while (hue > 360)
                {
                    hue -= 360;
                }

                sat = Utility.ClampToByte(sat);

                hsvColor.Hue = hue;
                hsvColor.Saturation = sat;

                ColorBgra newColor = ColorBgra.FromColor(hsvColor.ToColor());
                newColor.A = color.A;
                newColor = blendOp.Apply(newColor);
                
                return newColor;
            }
        }
    }
}
