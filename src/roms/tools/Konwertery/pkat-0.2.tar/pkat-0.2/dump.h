// (C)1997 Christian Janoff

#ifndef _DUMP_H
#define _DUMP_H

int pet2isoexact(int);

#endif // _DUMP_H

