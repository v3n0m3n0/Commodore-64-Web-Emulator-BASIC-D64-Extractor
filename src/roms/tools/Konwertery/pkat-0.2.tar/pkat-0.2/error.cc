// (C)1997 Christian Janoff
// ERROR.CC

#include <iostream.h>
#include <stdlib.h>

void internal_error(int error_number)
{
 cerr << "*** Internal error #" << error_number << "." << endl
      << "*** Please contact the author!" << endl
      << "*** Exiting." << endl;
 exit(1);
}

void file_error(int error)
{
 switch (error) {
		 case 1: cerr << "Can't open file." << endl;
		         break;
		 case 2: cerr << "Unexpected end of file." << endl;
			 break;
                 case 3: cerr << "File exists." << endl;
			 break;
		}
 exit(0);
}
