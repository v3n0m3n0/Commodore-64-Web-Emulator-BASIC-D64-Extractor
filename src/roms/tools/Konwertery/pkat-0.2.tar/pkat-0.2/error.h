// (C)1997 Christian Janoff

#ifndef _ERROR_H
#define _ERROR_H

void internal_error(int);
void file_error(int);

#endif // _ERROR_H

