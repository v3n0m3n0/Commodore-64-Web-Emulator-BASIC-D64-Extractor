// (C)1997 Christian Janoff

#ifndef _FILE_H
#define _FILE_H

enum { READ =ios::bin|ios::in|ios::nocreate,
       WRITE=ios::bin|ios::out               };

#endif // _FILE_H
