// (C)1997 Christian Janoff
#ifndef _PKSTRING_H
#define _PKSTRING_H

class pkstring
{
  public:
	                 pkstring(void);
	                 pkstring(pkstring const &);
	                 pkstring(char *);
                         ~pkstring(void);

	            void conv2basename(void);
	            void conv2pathname(void);
                   char* string(void);
            unsigned int len(void);
	             int has_suffix(char *);
		     int has_prefix(char *);
                    void remove_first(unsigned int);
		     int is(char *);
		     int remove_suffix(char *);
		     int remove_prefix(char *);
	       pkstring& operator+ (pkstring&);
	       pkstring& operator+ (char *);
	       pkstring& operator+ (char);
	       pkstring& operator= (pkstring const &);
	       pkstring& operator= (char *);
    	           char& operator[](unsigned int);
               friend ostream& operator<< (ostream& o, const pkstring&);
  private:     char * content;
	       int pkstring::remove_prefix_or_suffix(char *prefix_or_suffix, int suffix);
};

#endif
