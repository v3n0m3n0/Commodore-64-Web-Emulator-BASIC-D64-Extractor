# Microsoft Developer Studio Project File - Name="TargetD64" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=TargetD64 - Win32 Trace
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "TargetD64.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "TargetD64.mak" CFG="TargetD64 - Win32 Trace"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "TargetD64 - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "TargetD64 - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE "TargetD64 - Win32 Trace" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /MT /W3 /GR /GX /O1 /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /FD /c
# ADD BASE RSC /l 0x407 /d "NDEBUG"
# ADD RSC /l 0x407 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386 /nodefaultlib:"library"
# SUBTRACT LINK32 /pdb:none

!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /MTd /W3 /Gm /GR /GX /ZI /Od /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR /FD /c
# ADD BASE RSC /l 0x407 /d "_DEBUG"
# ADD RSC /l 0x407 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /nodefaultlib:"library" /pdbtype:sept
# SUBTRACT LINK32 /pdb:none

!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "TargetD6"
# PROP BASE Intermediate_Dir "TargetD6"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Trace"
# PROP Intermediate_Dir "Trace"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GR /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /FR /YX /FD /c
# ADD CPP /nologo /MT /W3 /GR /GX /O1 /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /FD /c
# ADD BASE RSC /l 0x407 /d "_DEBUG"
# ADD RSC /l 0x407 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:no /debug /machine:I386 /nodefaultlib:"libcmt.lib" /pdbtype:sept
# SUBTRACT LINK32 /pdb:none

!ENDIF 

# Begin Target

# Name "TargetD64 - Win32 Release"
# Name "TargetD64 - Win32 Debug"
# Name "TargetD64 - Win32 Trace"
# Begin Group "src"

# PROP Default_Filter ""
# Begin Group "win32"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src\win32\GUI.cpp
# ADD CPP /I "src"
# End Source File
# Begin Source File

SOURCE=.\src\win32\GUI.h
# End Source File
# Begin Source File

SOURCE=.\src\win32\StdAfx.cpp
# End Source File
# Begin Source File

SOURCE=.\src\win32\TargetD64.ico
# End Source File
# Begin Source File

SOURCE=.\src\win32\TargetD64.rc
# End Source File
# End Group
# Begin Group "linux"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src\linux\GUI.cpp
# PROP Exclude_From_Build 1
# End Source File
# Begin Source File

SOURCE=.\src\linux\GUI.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\src\Application.h
# End Source File
# Begin Source File

SOURCE=.\src\Archive.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\Archive.h
# End Source File
# Begin Source File

SOURCE=.\src\C64Archive.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\C64Archive.h
# End Source File
# Begin Source File

SOURCE=.\src\DiskImage.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\DiskImage.h
# End Source File
# Begin Source File

SOURCE=.\src\Exception.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\Exception.h
# End Source File
# Begin Source File

SOURCE=.\src\HostArchive.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\HostArchive.h
# End Source File
# Begin Source File

SOURCE=.\src\Image.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\Image.h
# End Source File
# Begin Source File

SOURCE=.\src\LynxImage.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\LynxImage.h
# End Source File
# Begin Source File

SOURCE=.\src\MultiPart.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\MultiPart.h
# End Source File
# Begin Source File

SOURCE=.\src\Options.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\Options.h
# End Source File
# Begin Source File

SOURCE=.\src\Profile.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\Profile.h
# End Source File
# Begin Source File

SOURCE=.\src\TapeImage.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\TapeImage.h
# End Source File
# Begin Source File

SOURCE=.\src\TargetD64.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /I "src\win32"
# End Source File
# Begin Source File

SOURCE=.\src\TargetD64.h
# End Source File
# Begin Source File

SOURCE=.\src\Tracing.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\Tracing.h
# End Source File
# Begin Source File

SOURCE=.\src\ZlibAdapter.cpp
# ADD CPP /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib"
# End Source File
# Begin Source File

SOURCE=.\src\ZlibAdapter.h
# End Source File
# End Group
# Begin Group "src_foreign"

# PROP Default_Filter ""
# Begin Group "lha"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src_foreign\lha\crcio.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\dhuf.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\extract.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\header.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\huf.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\intrface.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\larc.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\lharc.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\lharc.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\lhext.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\maketbl.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\shuf.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\slide.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\slidehuf.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\lha\util.c
# End Source File
# End Group
# Begin Group "VICE"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src_foreign\VICE\c1541.cpp
# ADD CPP /I "src"
# End Source File
# Begin Source File

SOURCE=.\src_foreign\VICE\vdrive.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\VICE\zipcode.cpp
# ADD CPP /I "src"
# End Source File
# Begin Source File

SOURCE=.\src_foreign\VICE\zipcode.h
# End Source File
# End Group
# Begin Group "zlib"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\src_foreign\zlib\adler32.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\crc32.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\gzio.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\infblock.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\infblock.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\infcodes.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\infcodes.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\inffast.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\inffast.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\inffixed.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\inflate.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\inftrees.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\inftrees.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\infutil.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\infutil.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\unzip.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\unzip.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\zconf.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\zlib.h
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\zutil.c
# End Source File
# Begin Source File

SOURCE=.\src_foreign\zlib\zutil.h
# End Source File
# End Group
# End Group
# End Target
# End Project
