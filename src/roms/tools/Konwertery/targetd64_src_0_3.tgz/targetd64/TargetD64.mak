# Microsoft Developer Studio Generated NMAKE File, Based on TargetD64.dsp
!IF "$(CFG)" == ""
CFG=TargetD64 - Win32 Trace
!MESSAGE No configuration specified. Defaulting to TargetD64 - Win32 Trace.
!ENDIF 

!IF "$(CFG)" != "TargetD64 - Win32 Release" && "$(CFG)" != "TargetD64 - Win32 Debug" && "$(CFG)" != "TargetD64 - Win32 Trace"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "TargetD64.mak" CFG="TargetD64 - Win32 Trace"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "TargetD64 - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "TargetD64 - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE "TargetD64 - Win32 Trace" (based on "Win32 (x86) Console Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\TargetD64.exe"


CLEAN :
	-@erase "$(INTDIR)\adler32.obj"
	-@erase "$(INTDIR)\Archive.obj"
	-@erase "$(INTDIR)\c1541.obj"
	-@erase "$(INTDIR)\C64Archive.obj"
	-@erase "$(INTDIR)\crc32.obj"
	-@erase "$(INTDIR)\crcio.obj"
	-@erase "$(INTDIR)\dhuf.obj"
	-@erase "$(INTDIR)\DiskImage.obj"
	-@erase "$(INTDIR)\Exception.obj"
	-@erase "$(INTDIR)\extract.obj"
	-@erase "$(INTDIR)\GUI.obj"
	-@erase "$(INTDIR)\gzio.obj"
	-@erase "$(INTDIR)\header.obj"
	-@erase "$(INTDIR)\HostArchive.obj"
	-@erase "$(INTDIR)\huf.obj"
	-@erase "$(INTDIR)\Image.obj"
	-@erase "$(INTDIR)\infblock.obj"
	-@erase "$(INTDIR)\infcodes.obj"
	-@erase "$(INTDIR)\inffast.obj"
	-@erase "$(INTDIR)\inflate.obj"
	-@erase "$(INTDIR)\inftrees.obj"
	-@erase "$(INTDIR)\infutil.obj"
	-@erase "$(INTDIR)\larc.obj"
	-@erase "$(INTDIR)\lharc.obj"
	-@erase "$(INTDIR)\lhext.obj"
	-@erase "$(INTDIR)\LynxImage.obj"
	-@erase "$(INTDIR)\maketbl.obj"
	-@erase "$(INTDIR)\MultiPart.obj"
	-@erase "$(INTDIR)\Options.obj"
	-@erase "$(INTDIR)\Profile.obj"
	-@erase "$(INTDIR)\shuf.obj"
	-@erase "$(INTDIR)\slide.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\TapeImage.obj"
	-@erase "$(INTDIR)\TargetD64.obj"
	-@erase "$(INTDIR)\TargetD64.res"
	-@erase "$(INTDIR)\Tracing.obj"
	-@erase "$(INTDIR)\unzip.obj"
	-@erase "$(INTDIR)\util.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\zipcode.obj"
	-@erase "$(INTDIR)\ZlibAdapter.obj"
	-@erase "$(INTDIR)\zutil.obj"
	-@erase "$(OUTDIR)\TargetD64.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MT /W3 /GR /GX /O1 /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

RSC=rc.exe
RSC_PROJ=/l 0x407 /fo"$(INTDIR)\TargetD64.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TargetD64.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:no /pdb:"$(OUTDIR)\TargetD64.pdb" /machine:I386 /nodefaultlib:"library" /out:"$(OUTDIR)\TargetD64.exe" 
LINK32_OBJS= \
	"$(INTDIR)\GUI.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\Archive.obj" \
	"$(INTDIR)\C64Archive.obj" \
	"$(INTDIR)\DiskImage.obj" \
	"$(INTDIR)\Exception.obj" \
	"$(INTDIR)\HostArchive.obj" \
	"$(INTDIR)\Image.obj" \
	"$(INTDIR)\LynxImage.obj" \
	"$(INTDIR)\MultiPart.obj" \
	"$(INTDIR)\Options.obj" \
	"$(INTDIR)\Profile.obj" \
	"$(INTDIR)\TapeImage.obj" \
	"$(INTDIR)\TargetD64.obj" \
	"$(INTDIR)\Tracing.obj" \
	"$(INTDIR)\ZlibAdapter.obj" \
	"$(INTDIR)\crcio.obj" \
	"$(INTDIR)\dhuf.obj" \
	"$(INTDIR)\extract.obj" \
	"$(INTDIR)\header.obj" \
	"$(INTDIR)\huf.obj" \
	"$(INTDIR)\larc.obj" \
	"$(INTDIR)\lharc.obj" \
	"$(INTDIR)\lhext.obj" \
	"$(INTDIR)\maketbl.obj" \
	"$(INTDIR)\shuf.obj" \
	"$(INTDIR)\slide.obj" \
	"$(INTDIR)\util.obj" \
	"$(INTDIR)\c1541.obj" \
	"$(INTDIR)\zipcode.obj" \
	"$(INTDIR)\adler32.obj" \
	"$(INTDIR)\crc32.obj" \
	"$(INTDIR)\gzio.obj" \
	"$(INTDIR)\infblock.obj" \
	"$(INTDIR)\infcodes.obj" \
	"$(INTDIR)\inffast.obj" \
	"$(INTDIR)\inflate.obj" \
	"$(INTDIR)\inftrees.obj" \
	"$(INTDIR)\infutil.obj" \
	"$(INTDIR)\unzip.obj" \
	"$(INTDIR)\zutil.obj" \
	"$(INTDIR)\TargetD64.res"

"$(OUTDIR)\TargetD64.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\TargetD64.exe" "$(OUTDIR)\TargetD64.bsc"


CLEAN :
	-@erase "$(INTDIR)\adler32.obj"
	-@erase "$(INTDIR)\adler32.sbr"
	-@erase "$(INTDIR)\Archive.obj"
	-@erase "$(INTDIR)\Archive.sbr"
	-@erase "$(INTDIR)\c1541.obj"
	-@erase "$(INTDIR)\c1541.sbr"
	-@erase "$(INTDIR)\C64Archive.obj"
	-@erase "$(INTDIR)\C64Archive.sbr"
	-@erase "$(INTDIR)\crc32.obj"
	-@erase "$(INTDIR)\crc32.sbr"
	-@erase "$(INTDIR)\crcio.obj"
	-@erase "$(INTDIR)\crcio.sbr"
	-@erase "$(INTDIR)\dhuf.obj"
	-@erase "$(INTDIR)\dhuf.sbr"
	-@erase "$(INTDIR)\DiskImage.obj"
	-@erase "$(INTDIR)\DiskImage.sbr"
	-@erase "$(INTDIR)\Exception.obj"
	-@erase "$(INTDIR)\Exception.sbr"
	-@erase "$(INTDIR)\extract.obj"
	-@erase "$(INTDIR)\extract.sbr"
	-@erase "$(INTDIR)\GUI.obj"
	-@erase "$(INTDIR)\GUI.sbr"
	-@erase "$(INTDIR)\gzio.obj"
	-@erase "$(INTDIR)\gzio.sbr"
	-@erase "$(INTDIR)\header.obj"
	-@erase "$(INTDIR)\header.sbr"
	-@erase "$(INTDIR)\HostArchive.obj"
	-@erase "$(INTDIR)\HostArchive.sbr"
	-@erase "$(INTDIR)\huf.obj"
	-@erase "$(INTDIR)\huf.sbr"
	-@erase "$(INTDIR)\Image.obj"
	-@erase "$(INTDIR)\Image.sbr"
	-@erase "$(INTDIR)\infblock.obj"
	-@erase "$(INTDIR)\infblock.sbr"
	-@erase "$(INTDIR)\infcodes.obj"
	-@erase "$(INTDIR)\infcodes.sbr"
	-@erase "$(INTDIR)\inffast.obj"
	-@erase "$(INTDIR)\inffast.sbr"
	-@erase "$(INTDIR)\inflate.obj"
	-@erase "$(INTDIR)\inflate.sbr"
	-@erase "$(INTDIR)\inftrees.obj"
	-@erase "$(INTDIR)\inftrees.sbr"
	-@erase "$(INTDIR)\infutil.obj"
	-@erase "$(INTDIR)\infutil.sbr"
	-@erase "$(INTDIR)\larc.obj"
	-@erase "$(INTDIR)\larc.sbr"
	-@erase "$(INTDIR)\lharc.obj"
	-@erase "$(INTDIR)\lharc.sbr"
	-@erase "$(INTDIR)\lhext.obj"
	-@erase "$(INTDIR)\lhext.sbr"
	-@erase "$(INTDIR)\LynxImage.obj"
	-@erase "$(INTDIR)\LynxImage.sbr"
	-@erase "$(INTDIR)\maketbl.obj"
	-@erase "$(INTDIR)\maketbl.sbr"
	-@erase "$(INTDIR)\MultiPart.obj"
	-@erase "$(INTDIR)\MultiPart.sbr"
	-@erase "$(INTDIR)\Options.obj"
	-@erase "$(INTDIR)\Options.sbr"
	-@erase "$(INTDIR)\Profile.obj"
	-@erase "$(INTDIR)\Profile.sbr"
	-@erase "$(INTDIR)\shuf.obj"
	-@erase "$(INTDIR)\shuf.sbr"
	-@erase "$(INTDIR)\slide.obj"
	-@erase "$(INTDIR)\slide.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\TapeImage.obj"
	-@erase "$(INTDIR)\TapeImage.sbr"
	-@erase "$(INTDIR)\TargetD64.obj"
	-@erase "$(INTDIR)\TargetD64.res"
	-@erase "$(INTDIR)\TargetD64.sbr"
	-@erase "$(INTDIR)\Tracing.obj"
	-@erase "$(INTDIR)\Tracing.sbr"
	-@erase "$(INTDIR)\unzip.obj"
	-@erase "$(INTDIR)\unzip.sbr"
	-@erase "$(INTDIR)\util.obj"
	-@erase "$(INTDIR)\util.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\zipcode.obj"
	-@erase "$(INTDIR)\zipcode.sbr"
	-@erase "$(INTDIR)\ZlibAdapter.obj"
	-@erase "$(INTDIR)\ZlibAdapter.sbr"
	-@erase "$(INTDIR)\zutil.obj"
	-@erase "$(INTDIR)\zutil.sbr"
	-@erase "$(OUTDIR)\TargetD64.bsc"
	-@erase "$(OUTDIR)\TargetD64.exe"
	-@erase "$(OUTDIR)\TargetD64.ilk"
	-@erase "$(OUTDIR)\TargetD64.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

RSC=rc.exe
RSC_PROJ=/l 0x407 /fo"$(INTDIR)\TargetD64.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TargetD64.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\GUI.sbr" \
	"$(INTDIR)\StdAfx.sbr" \
	"$(INTDIR)\Archive.sbr" \
	"$(INTDIR)\C64Archive.sbr" \
	"$(INTDIR)\DiskImage.sbr" \
	"$(INTDIR)\Exception.sbr" \
	"$(INTDIR)\HostArchive.sbr" \
	"$(INTDIR)\Image.sbr" \
	"$(INTDIR)\LynxImage.sbr" \
	"$(INTDIR)\MultiPart.sbr" \
	"$(INTDIR)\Options.sbr" \
	"$(INTDIR)\Profile.sbr" \
	"$(INTDIR)\TapeImage.sbr" \
	"$(INTDIR)\TargetD64.sbr" \
	"$(INTDIR)\Tracing.sbr" \
	"$(INTDIR)\ZlibAdapter.sbr" \
	"$(INTDIR)\crcio.sbr" \
	"$(INTDIR)\dhuf.sbr" \
	"$(INTDIR)\extract.sbr" \
	"$(INTDIR)\header.sbr" \
	"$(INTDIR)\huf.sbr" \
	"$(INTDIR)\larc.sbr" \
	"$(INTDIR)\lharc.sbr" \
	"$(INTDIR)\lhext.sbr" \
	"$(INTDIR)\maketbl.sbr" \
	"$(INTDIR)\shuf.sbr" \
	"$(INTDIR)\slide.sbr" \
	"$(INTDIR)\util.sbr" \
	"$(INTDIR)\c1541.sbr" \
	"$(INTDIR)\zipcode.sbr" \
	"$(INTDIR)\adler32.sbr" \
	"$(INTDIR)\crc32.sbr" \
	"$(INTDIR)\gzio.sbr" \
	"$(INTDIR)\infblock.sbr" \
	"$(INTDIR)\infcodes.sbr" \
	"$(INTDIR)\inffast.sbr" \
	"$(INTDIR)\inflate.sbr" \
	"$(INTDIR)\inftrees.sbr" \
	"$(INTDIR)\infutil.sbr" \
	"$(INTDIR)\unzip.sbr" \
	"$(INTDIR)\zutil.sbr"

"$(OUTDIR)\TargetD64.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:yes /pdb:"$(OUTDIR)\TargetD64.pdb" /debug /machine:I386 /nodefaultlib:"library" /out:"$(OUTDIR)\TargetD64.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\GUI.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\Archive.obj" \
	"$(INTDIR)\C64Archive.obj" \
	"$(INTDIR)\DiskImage.obj" \
	"$(INTDIR)\Exception.obj" \
	"$(INTDIR)\HostArchive.obj" \
	"$(INTDIR)\Image.obj" \
	"$(INTDIR)\LynxImage.obj" \
	"$(INTDIR)\MultiPart.obj" \
	"$(INTDIR)\Options.obj" \
	"$(INTDIR)\Profile.obj" \
	"$(INTDIR)\TapeImage.obj" \
	"$(INTDIR)\TargetD64.obj" \
	"$(INTDIR)\Tracing.obj" \
	"$(INTDIR)\ZlibAdapter.obj" \
	"$(INTDIR)\crcio.obj" \
	"$(INTDIR)\dhuf.obj" \
	"$(INTDIR)\extract.obj" \
	"$(INTDIR)\header.obj" \
	"$(INTDIR)\huf.obj" \
	"$(INTDIR)\larc.obj" \
	"$(INTDIR)\lharc.obj" \
	"$(INTDIR)\lhext.obj" \
	"$(INTDIR)\maketbl.obj" \
	"$(INTDIR)\shuf.obj" \
	"$(INTDIR)\slide.obj" \
	"$(INTDIR)\util.obj" \
	"$(INTDIR)\c1541.obj" \
	"$(INTDIR)\zipcode.obj" \
	"$(INTDIR)\adler32.obj" \
	"$(INTDIR)\crc32.obj" \
	"$(INTDIR)\gzio.obj" \
	"$(INTDIR)\infblock.obj" \
	"$(INTDIR)\infcodes.obj" \
	"$(INTDIR)\inffast.obj" \
	"$(INTDIR)\inflate.obj" \
	"$(INTDIR)\inftrees.obj" \
	"$(INTDIR)\infutil.obj" \
	"$(INTDIR)\unzip.obj" \
	"$(INTDIR)\zutil.obj" \
	"$(INTDIR)\TargetD64.res"

"$(OUTDIR)\TargetD64.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

OUTDIR=.\Trace
INTDIR=.\Trace
# Begin Custom Macros
OutDir=.\Trace
# End Custom Macros

ALL : "$(OUTDIR)\TargetD64.exe"


CLEAN :
	-@erase "$(INTDIR)\adler32.obj"
	-@erase "$(INTDIR)\Archive.obj"
	-@erase "$(INTDIR)\c1541.obj"
	-@erase "$(INTDIR)\C64Archive.obj"
	-@erase "$(INTDIR)\crc32.obj"
	-@erase "$(INTDIR)\crcio.obj"
	-@erase "$(INTDIR)\dhuf.obj"
	-@erase "$(INTDIR)\DiskImage.obj"
	-@erase "$(INTDIR)\Exception.obj"
	-@erase "$(INTDIR)\extract.obj"
	-@erase "$(INTDIR)\GUI.obj"
	-@erase "$(INTDIR)\gzio.obj"
	-@erase "$(INTDIR)\header.obj"
	-@erase "$(INTDIR)\HostArchive.obj"
	-@erase "$(INTDIR)\huf.obj"
	-@erase "$(INTDIR)\Image.obj"
	-@erase "$(INTDIR)\infblock.obj"
	-@erase "$(INTDIR)\infcodes.obj"
	-@erase "$(INTDIR)\inffast.obj"
	-@erase "$(INTDIR)\inflate.obj"
	-@erase "$(INTDIR)\inftrees.obj"
	-@erase "$(INTDIR)\infutil.obj"
	-@erase "$(INTDIR)\larc.obj"
	-@erase "$(INTDIR)\lharc.obj"
	-@erase "$(INTDIR)\lhext.obj"
	-@erase "$(INTDIR)\LynxImage.obj"
	-@erase "$(INTDIR)\maketbl.obj"
	-@erase "$(INTDIR)\MultiPart.obj"
	-@erase "$(INTDIR)\Options.obj"
	-@erase "$(INTDIR)\Profile.obj"
	-@erase "$(INTDIR)\shuf.obj"
	-@erase "$(INTDIR)\slide.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\TapeImage.obj"
	-@erase "$(INTDIR)\TargetD64.obj"
	-@erase "$(INTDIR)\TargetD64.res"
	-@erase "$(INTDIR)\Tracing.obj"
	-@erase "$(INTDIR)\unzip.obj"
	-@erase "$(INTDIR)\util.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\zipcode.obj"
	-@erase "$(INTDIR)\ZlibAdapter.obj"
	-@erase "$(INTDIR)\zutil.obj"
	-@erase "$(OUTDIR)\TargetD64.exe"
	-@erase "$(OUTDIR)\TargetD64.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MT /W3 /GR /GX /O1 /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

RSC=rc.exe
RSC_PROJ=/l 0x407 /fo"$(INTDIR)\TargetD64.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TargetD64.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /incremental:no /pdb:"$(OUTDIR)\TargetD64.pdb" /debug /machine:I386 /nodefaultlib:"libcmt.lib" /out:"$(OUTDIR)\TargetD64.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\GUI.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\Archive.obj" \
	"$(INTDIR)\C64Archive.obj" \
	"$(INTDIR)\DiskImage.obj" \
	"$(INTDIR)\Exception.obj" \
	"$(INTDIR)\HostArchive.obj" \
	"$(INTDIR)\Image.obj" \
	"$(INTDIR)\LynxImage.obj" \
	"$(INTDIR)\MultiPart.obj" \
	"$(INTDIR)\Options.obj" \
	"$(INTDIR)\Profile.obj" \
	"$(INTDIR)\TapeImage.obj" \
	"$(INTDIR)\TargetD64.obj" \
	"$(INTDIR)\Tracing.obj" \
	"$(INTDIR)\ZlibAdapter.obj" \
	"$(INTDIR)\crcio.obj" \
	"$(INTDIR)\dhuf.obj" \
	"$(INTDIR)\extract.obj" \
	"$(INTDIR)\header.obj" \
	"$(INTDIR)\huf.obj" \
	"$(INTDIR)\larc.obj" \
	"$(INTDIR)\lharc.obj" \
	"$(INTDIR)\lhext.obj" \
	"$(INTDIR)\maketbl.obj" \
	"$(INTDIR)\shuf.obj" \
	"$(INTDIR)\slide.obj" \
	"$(INTDIR)\util.obj" \
	"$(INTDIR)\c1541.obj" \
	"$(INTDIR)\zipcode.obj" \
	"$(INTDIR)\adler32.obj" \
	"$(INTDIR)\crc32.obj" \
	"$(INTDIR)\gzio.obj" \
	"$(INTDIR)\infblock.obj" \
	"$(INTDIR)\infcodes.obj" \
	"$(INTDIR)\inffast.obj" \
	"$(INTDIR)\inflate.obj" \
	"$(INTDIR)\inftrees.obj" \
	"$(INTDIR)\infutil.obj" \
	"$(INTDIR)\unzip.obj" \
	"$(INTDIR)\zutil.obj" \
	"$(INTDIR)\TargetD64.res"

"$(OUTDIR)\TargetD64.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("TargetD64.dep")
!INCLUDE "TargetD64.dep"
!ELSE 
!MESSAGE Warning: cannot find "TargetD64.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "TargetD64 - Win32 Release" || "$(CFG)" == "TargetD64 - Win32 Debug" || "$(CFG)" == "TargetD64 - Win32 Trace"
SOURCE=.\src\win32\GUI.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\GUI.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\GUI.obj"	"$(INTDIR)\GUI.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\GUI.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\win32\StdAfx.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\StdAfx.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\StdAfx.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src\win32\TargetD64.rc

"$(INTDIR)\TargetD64.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\src\linux\GUI.cpp
SOURCE=.\src\Archive.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Archive.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Archive.obj"	"$(INTDIR)\Archive.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Archive.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\C64Archive.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\C64Archive.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\C64Archive.obj"	"$(INTDIR)\C64Archive.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\C64Archive.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\DiskImage.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\DiskImage.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\DiskImage.obj"	"$(INTDIR)\DiskImage.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\DiskImage.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\Exception.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Exception.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Exception.obj"	"$(INTDIR)\Exception.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Exception.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\HostArchive.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\HostArchive.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\HostArchive.obj"	"$(INTDIR)\HostArchive.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\HostArchive.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\Image.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Image.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Image.obj"	"$(INTDIR)\Image.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Image.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\LynxImage.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\LynxImage.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\LynxImage.obj"	"$(INTDIR)\LynxImage.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\LynxImage.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\MultiPart.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\MultiPart.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\MultiPart.obj"	"$(INTDIR)\MultiPart.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\MultiPart.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\Options.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Options.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Options.obj"	"$(INTDIR)\Options.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Options.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\Profile.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Profile.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Profile.obj"	"$(INTDIR)\Profile.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Profile.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\TapeImage.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\TapeImage.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\TapeImage.obj"	"$(INTDIR)\TapeImage.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\TapeImage.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\TargetD64.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /I "src\win32" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\TargetD64.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /I "src\win32" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\TargetD64.obj"	"$(INTDIR)\TargetD64.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /I "src\win32" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\TargetD64.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\Tracing.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Tracing.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Tracing.obj"	"$(INTDIR)\Tracing.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\Tracing.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src\ZlibAdapter.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ZlibAdapter.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ZlibAdapter.obj"	"$(INTDIR)\ZlibAdapter.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src_foreign\lha" /I "src_foreign\VICE" /I "src_foreign\zlib" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\ZlibAdapter.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src_foreign\lha\crcio.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\crcio.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\crcio.obj"	"$(INTDIR)\crcio.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\crcio.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\dhuf.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\dhuf.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\dhuf.obj"	"$(INTDIR)\dhuf.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\dhuf.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\extract.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\extract.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\extract.obj"	"$(INTDIR)\extract.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\extract.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\header.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\header.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\header.obj"	"$(INTDIR)\header.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\header.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\huf.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\huf.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\huf.obj"	"$(INTDIR)\huf.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\huf.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\larc.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\larc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\larc.obj"	"$(INTDIR)\larc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\larc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\lharc.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\lharc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\lharc.obj"	"$(INTDIR)\lharc.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\lharc.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\lhext.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\lhext.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\lhext.obj"	"$(INTDIR)\lhext.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\lhext.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\maketbl.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\maketbl.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\maketbl.obj"	"$(INTDIR)\maketbl.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\maketbl.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\shuf.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\shuf.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\shuf.obj"	"$(INTDIR)\shuf.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\shuf.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\slide.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\slide.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\slide.obj"	"$(INTDIR)\slide.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\slide.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\lha\util.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\util.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\util.obj"	"$(INTDIR)\util.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\util.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\VICE\c1541.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\c1541.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\c1541.obj"	"$(INTDIR)\c1541.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\c1541.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src_foreign\VICE\zipcode.cpp

!IF  "$(CFG)" == "TargetD64 - Win32 Release"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src" /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\zipcode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"

CPP_SWITCHES=/nologo /MTd /W3 /Gm /GR /GX /ZI /Od /I "src" /D "_DEBUG" /D "TD64_MODIFIED" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "_WINDOWS" /FR"$(INTDIR)\\" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\zipcode.obj"	"$(INTDIR)\zipcode.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"

CPP_SWITCHES=/nologo /MT /W3 /GR /GX /O1 /I "src" /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "TD64_MODIFIED" /D "_WINDOWS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\zipcode.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\src_foreign\zlib\adler32.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\adler32.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\adler32.obj"	"$(INTDIR)\adler32.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\adler32.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\crc32.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\crc32.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\crc32.obj"	"$(INTDIR)\crc32.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\crc32.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\gzio.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\gzio.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\gzio.obj"	"$(INTDIR)\gzio.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\gzio.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\infblock.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\infblock.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\infblock.obj"	"$(INTDIR)\infblock.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\infblock.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\infcodes.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\infcodes.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\infcodes.obj"	"$(INTDIR)\infcodes.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\infcodes.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\inffast.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\inffast.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\inffast.obj"	"$(INTDIR)\inffast.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\inffast.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\inflate.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\inflate.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\inflate.obj"	"$(INTDIR)\inflate.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\inflate.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\inftrees.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\inftrees.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\inftrees.obj"	"$(INTDIR)\inftrees.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\inftrees.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\infutil.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\infutil.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\infutil.obj"	"$(INTDIR)\infutil.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\infutil.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\unzip.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\unzip.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\unzip.obj"	"$(INTDIR)\unzip.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\unzip.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\src_foreign\zlib\zutil.c

!IF  "$(CFG)" == "TargetD64 - Win32 Release"


"$(INTDIR)\zutil.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Debug"


"$(INTDIR)\zutil.obj"	"$(INTDIR)\zutil.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "TargetD64 - Win32 Trace"


"$(INTDIR)\zutil.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 


!ENDIF 

