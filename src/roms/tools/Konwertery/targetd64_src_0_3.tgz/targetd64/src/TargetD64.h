//////////////////////////////////////////////////////////////////////
//TargetD64 - C64 archive related conversion tool and emulator frontend
//////////////////////////////////////////////////////////////////////
//Copyright (C) 1998, 1999  Karlheinz Langguth klangguth@netscape.net
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//////////////////////////////////////////////////////////////////////

//avoid multiple include of header file
#ifndef _TARGETD64_HEADER
#define _TARGETD64_HEADER


//version and location definitions
#define VERSION  "TargetD64 V0.3 18.10.99"
#define HOMEPAGE "TargetD64 homepage at\nhttp://skyscraper.fortunecity.com/quadra/251/targetd64.html\n"
#define MAIL     "Contact the author by mailto:klangguth@netscape.net\n"


//options used by TD64
//first is option string, second is argument follows flag
const pair<string, bool> OPT_HELP((string)"h", false);
const pair<string, bool> OPT_TRACE((string)"d", false);
const pair<string, bool> OPT_TRACE_FILE((string)"t", true);
const pair<string, bool> OPT_NO_CLEANUP((string)"n", false);
const pair<string, bool> OPT_CONVERT_ONLY((string)"c", true);
const pair<string, bool> OPT_VERSION((string)"v", false);
const pair<string, bool> OPT_KEEP_FILENAME((string)"k", false);
const pair<string, bool> OPT_FILENAME(OP_STD_ARG, false);

//profile entries used by TD64
//first is section, second is entry
const pair<string, string> PRO_ENV_TMPDIR(string("Environment"), string("TmpDir"));
const pair<string, string> PRO_OPT_NOCLEANUP(string("Options"), string("NoCleanup"));
const pair<string, string> PRO_OPT_KEEP(string("Options"), string("KeepOriginalFilename"));
const pair<string, string> PRO_OPT_TRACE(string("Options"), string("Trace"));
const pair<string, string> PRO_OPT_TRACE_FILENAME(string("Options"), string("TraceFilename"));
const pair<string, string> PRO_OPT_CONVERTONLY(string("Options"), string("ConvertOnlyDirectory"));
const pair<string, string> PRO_GENERIC_ARCHIVES(string("GenericArchives"), string("ExtCmdCombi"));
const pair<string, string> PRO_EMULATOR_CMD(string("Emulator"), string("Cmd"));

#endif
