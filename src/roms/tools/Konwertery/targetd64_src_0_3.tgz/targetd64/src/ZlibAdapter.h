//////////////////////////////////////////////////////////////////////
//TargetD64 - C64 archive related conversion tool and emulator frontend
//////////////////////////////////////////////////////////////////////
//Copyright (C) 1998, 1999  Karlheinz Langguth klangguth@netscape.net
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//////////////////////////////////////////////////////////////////////

#ifndef _ZLIB_ADAPTER_HEADER
#define _ZLIB_ADAPTER_HEADER

//Gunzip a gnu zipped file
//P1 I: name of gnuzipped file
//P2 I: directory to extract file into
void Gunzip(const string& gzipFilename, const string& extractDir)
	throw (CFException);

//Unzip a pkzipped file
//P1 I: name of pkzipped file
//P2 I: directory to extract file into
void Unzip(const string& zipFilename, const string& extractDir)
	throw (CFException);

#endif
