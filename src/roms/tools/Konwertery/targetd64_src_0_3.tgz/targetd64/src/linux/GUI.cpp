//////////////////////////////////////////////////////////////////////
//TargetD64 - C64 archive related conversion tool and emulator frontend
//////////////////////////////////////////////////////////////////////
//Copyright (C) 1998, 1999  Karlheinz Langguth klangguth@netscape.net
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
//COMPILE SWITCHES
// _MSC_VER
// indicates MS compiler
// _DEBUG
// for debug version which activates ASSERT and TRACE
// TD64_MODIFIED
// marks changes in foreign sources to fit into TargetD64
// must be set everywhere because also used for header files
// NO_GUI
// Compile TD64 as a pure console application (as it has been intended)
// Well, Win32 user force you to implement a GUI ;-)

#ifndef NO_GUI

#include <stdlib.h>

#include <string>

using namespace std;

#include "GUI.h"

int InitGUI(void)
{
	return 0;
}


const string strWarning =
"GUI not YET available! For now use one of those:\n\n\
1. Drag&Drop from filemanager (kfm) to TargetD64 shortcut icon on desktop.\n\
2. targetd64 as shell command.\n\
\nFor details consult manual.\n\
\n\
Have fun,\n\
Karlheinz Langguth";

//bringing up a window with a simple button is as ugly for X11
//as it would be for the Win-API
//I will not do such a thing without Motif or Qt
void StartGUI(void)
{
	system(((string)"xmessage -center \"" + strWarning + "\"").c_str());
}

#endif
