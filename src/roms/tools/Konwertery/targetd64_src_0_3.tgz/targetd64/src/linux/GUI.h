#ifndef NO_GUI

#ifndef _GUI_HEADER
#define _GUI_HEADER

//initialize the GUI
int InitGUI(void);

//startup the GUI
void StartGUI(void);

#endif

#endif
