//////////////////////////////////////////////////////////////////////
//TargetD64 - C64 archive related conversion tool and emulator frontend
//////////////////////////////////////////////////////////////////////
//Copyright (C) 1998, 1999  Karlheinz Langguth klangguth@netscape.net
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
//COMPILE SWITCHES
// _MSC_VER
// indicates MS compiler
// _DEBUG
// for debug version which activates ASSERT and TRACE
// TD64_MODIFIED
// marks changes in foreign sources to fit into TargetD64
// must be set everywhere because also used for header files
// NO_GUI
// Compile TD64 as a pure console application (as it has been intended)
// Well, Win32 user force you to implement a GUI ;-)

#ifndef NO_GUI

#ifdef _MSC_VER
#pragma warning(disable:4786) //identifier truncation warning
#endif

#include "stdafx.h"

#include <string>

using namespace std;

#include "GUI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

int InitGUI(void)
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	return nRetCode;
}


const string strWarning =
"GUI not YET available! For now use one of those:\n\n\
1. Drag&Drop from Explorer to TargetD64 shortcut icon on desktop.\n\
2. SendTo menu item from Explorer (right mouse button).\n\
3. targetd64 from DOS command line.\n\
\nFor details consult manual.\n\
\n\
Have fun,\n\
Karlheinz Langguth";

void StartGUI(void)
{
	AfxMessageBox(strWarning.c_str());
}

#endif
