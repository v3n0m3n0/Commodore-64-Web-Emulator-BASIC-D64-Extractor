SID Factory 0.05d
-----------------

The editor is not yet completely finished, but in a pretty good operating state.

The worktunes in this archive are made with both Driver 5 and Driver 6. Please not that
the worktune with Driver 6 is in an older version of the driver, where the property byte
in the instrument is a little different than in Driver 6.02d. Read the docs, they should 
explain how the driver works. I lost my memorystick today, where there were some Driver 6.02 
worktunes on, so I cannot include any.

Hope you like it.

Regards,
Thomas Egeskov Petersen

