
;--------------------------------------------------

; Constanten

RLEsrc	= $50					;
RLEdest	= $52
RLElength	= $54

;--------------------------------------------------		

RLEdepack														
							ldy #$00		; Y blijft de hele routine op 0
						
						
depack					
							jsr RLEread
							tax
							and #$c0
							cmp #$c0
							bne noRLE
							
							txa
							sec
							sbc #$c0					
							tax			
							
							jsr RLEread
RLEloop							

							sta (RLEdest),y
							inc RLEdest
							bne noINChigh
							inc RLEdest + 1
noINChigh							
				
							dex
							bne RLEloop
							
							lda RLEsrc
							cmp RLElength
							bne depack 
							
							lda RLEsrc + 1
							cmp RLElength + 1
							bne depack 
							rts																									
							
noRLE
							txa
							sta (RLEdest),y
							inc RLEdest
							bne depack  
							inc RLEdest + 1
							jmp depack
							
RLEread						
							lda (RLEsrc),y
							inc RLEsrc
							bne noINChighR
							inc RLEsrc + 1
noINChighR							
							rts			
